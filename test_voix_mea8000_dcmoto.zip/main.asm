* =============================================================================
* TEST VOIX MEA8000 - pour l'auteur de DCMOTO
*
* Joue en boucle les 12 phrases de Spacecraft sur le MEA8000 (meme methode
* que le jeu : arret, hauteur, 2 trames d'avance, puis une trame de 4 octets
* toutes les 30,72 ms, cadencee par le balayage), pendant qu'une barre avance
* d'une case a CHAQUE image (50 par seconde) et qu'un compteur d'images tourne.
*
* Sur une vraie machine la barre ne s'arrete jamais. Sous DCMOTO, elle se
* fige au debut de chaque phrase : c'est le ralentissement observe dans le jeu.
* Le programme mesure aussi, en temps emule, la duree de chaque phrase en
* images et le temps CPU libre par image (s'il baisse, c'est le 6809 emule
* qui est retenu ; s'il ne baisse pas, l'arret vient de l'emulateur lui-meme).
*
* Assemblage : -D TO8 (TO8, ports $E7xx) ou rien (MO6, ports $A7xx).
* =============================================================================
 IFDEF TO8
IO       equ  $E700
SCR      equ  $4000                    ; ecran forme/couleur (mode TO7)
SEL      equ  $E7C3                    ; bit 0 : 1 = forme, 0 = couleur
COLTXT   equ  $C7                      ; (octet couleur : voir CouleurTxt)
         org  $6300
 ELSE
IO       equ  $A700
SCR      equ  $0000                    ; ecran forme/couleur (mode MO5)
SEL      equ  $A7C0
COLTXT   equ  $70
         org  $2300
 ENDC
SYS1     equ  IO+$E7                   ; lecture bit 7 : faisceau dans l'ecran utile
VMODE    equ  IO+$DC
VPAGE    equ  IO+$DD
MEA_D    equ  IO+$FE
MEA_C    equ  IO+$FF
MEA_STOP equ  $1A
NPHR     equ  12

Start
        orcc  #$50
        lds   #Start
        clr   VMODE                    ; mode 40 colonnes, page 0
        lda   #$04                     ; cadre bleu
        sta   VPAGE
        lda   #MEA_STOP
        sta   MEA_C
        jsr   Cls
        ldu   #T0
        jsr   Line
        ldu   #T0b
        jsr   Line
        jsr   Nl
        ldu   #T1
        jsr   Line
        ldu   #T2
        jsr   Line
        ldu   #T3
        jsr   Line
        lda   #10                      ; resultats a partir de la ligne 10
        sta   res_row
        clr   meth
        jsr   ShowMeth

* --- boucle principale : une image a chaque descente du bit 7 de SYS1 ---
        clr   phr
        ldd   #150                     ; 3 s de silence avant la 1re phrase
        std   wait_t
Loop    ldx   #0                       ; temps libre : tours de boucle jusqu'a
@w1     leax  1,x                      ; l'image suivante
        tst   SYS1
        bpl   @w1                      ; attend l'ecran utile...
@w2     leax  1,x
        tst   SYS1
        bmi   @w2                      ; ...puis sa fin : une image
        stx   free
        ldd   frame
        addd  #1
        std   frame
        jsr   Bar                      ; barre + compteur d'images
        jsr   VoiceTick
        tst   vo_on                    ; mesures pendant la phrase
        beq   @idle
        ldd   free
        cmpd  fmin
        bhs   >
        std   fmin
!       bra   Loop
@idle   tst   playing                  ; phrase finie : resultat
        beq   @base
        clr   playing
        jsr   Report
@base   ldd   free                     ; temps libre de reference (silence)
        std   fbase
        ldd   wait_t
        subd  #1
        std   wait_t
        bne   Loop
        ldd   #100                     ; phrase suivante, puis 2 s de silence
        std   wait_t
        lda   phr
        jsr   VoicePlay
        ldd   frame
        std   f_start
        ldd   #$FFFF
        std   fmin
        lda   #1
        sta   playing
        bra   Loop

* Report : une ligne par phrase (images mesurees / attendues, temps libre)
Report
        lda   res_row
        sta   row
        clr   col
        ldu   #TR1
        jsr   Str
        lda   phr
        jsr   Dec2
        lda   #' '
        jsr   Chr
        lda   #'T'
        tst   meth
        beq   >
        lda   #'R'
!       jsr   Chr
        ldu   #TR2
        jsr   Str
        ldd   frame                    ; duree en images (temps emule)
        subd  f_start
        jsr   Hex4
        ldu   #TR3
        jsr   Str
        ldd   expect
        jsr   Hex4
        ldu   #TR4
        jsr   Str
        ldd   fmin
        jsr   Hex4
        lda   #'/'
        jsr   Chr
        ldd   fbase
        jsr   Hex4
        lda   #' '
        tst   stuck
        beq   >
        lda   #'!'                     ; REQ jamais revenu
!       jsr   Chr
        clr   stuck
        inc   res_row
        lda   res_row
        cmpa  #10+NPHR
        blo   >
        lda   #10
        sta   res_row
!       lda   phr
        inca
        cmpa  #NPHR
        blo   >
        com   meth                     ; 12 phrases faites : autre methode
        jsr   ShowMeth
        clra
!       sta   phr
        rts

ShowMeth
        lda   #6
        sta   row
        clr   col
        ldu   #TMT
        tst   meth
        beq   >
        ldu   #TMR
!       jmp   Str

* Bar : case pleine qui avance d'une colonne par image (ligne 7) et
* compteur d'images en hexa (ligne 8)
Bar
        lda   SEL
        ora   #1
        sta   SEL
        ldb   bar_c                    ; efface l'ancienne case
        clra
        addd  #SCR+7*320
        tfr   d,x
        lda   #8
@e      clr   ,x
        leax  40,x
        deca
        bne   @e
        ldb   bar_c
        incb
        cmpb  #40
        blo   >
        clrb
!       stb   bar_c
        clra
        addd  #SCR+7*320
        tfr   d,x
        lda   #8
        ldb   #$FF
@f      stb   ,x
        leax  40,x
        deca
        bne   @f
        lda   #8
        sta   row
        clr   col
        ldu   #TF
        jsr   Str
        ldd   frame
        jmp   Hex4

* --- voix : comme le moteur (sans baisser la musique) ---
VoicePlay                              ; A = phrase
        lsla
        ldx   #VoiceOffsets
        ldd   a,x
        addd  #VoiceData
        tfr   d,x
        lda   #MEA_STOP
        sta   MEA_C
        jsr   VoiceDly
        lda   ,x+
        sta   MEA_D
        jsr   VoiceDly
        lda   ,x+                      ; nombre de trames
        pshs  a
        suba  #2                       ; images attendues = (trames-2) * 1,536
        ldb   #197                     ; (197/128)
        mul
        lslb
        rola
        tfr   a,b
        clra
        std   expect
        puls  a
        suba  #2
        sta   vo_left
        jsr   VoiceFrame
        jsr   VoiceFrame
        stx   vo_ptr
        ldd   #-3072-250
        std   vo_acc
        clr   vo_wait
        lda   #1
        sta   vo_on
        rts

VoiceTick                              ; a chaque image
        tst   vo_on
        beq   @rts
        tst   meth
        beq   @tim
        lda   MEA_C                    ; methode R : trame quand REQ = 1
        bmi   @req                     ; (bit 7 de l'etat du MEA8000)
        inc   vo_wait                  ; REQ jamais a 1 pendant 1 s :
        lda   vo_wait                  ; phrase abandonnee (notee !)
        cmpa  #50
        blo   @rts
        clr   vo_on
        inc   stuck
        rts
@req    clr   vo_wait
        bra   @send
@tim    ldd   vo_acc
        addd  #1997
        std   vo_acc
        bmi   @rts
        subd  #3072
        std   vo_acc
@send   ldx   vo_ptr
        jsr   VoiceFrame
        stx   vo_ptr
        dec   vo_left
        bne   @rts
        clr   vo_on
@rts    rts

VoiceFrame
        ldb   #4
@b      lda   ,x+
        sta   MEA_D
        jsr   VoiceDly
        decb
        bne   @b
        rts
VoiceDly
        pshs  b
        ldb   #20
@d      decb
        bne   @d
        puls  b,pc

* --- texte 40 colonnes (police 3x5) ---
Cls     lda   SEL
        anda  #$FE                     ; couleurs
        sta   SEL
        ldx   #SCR
        lda   #COLTXT
@c      sta   ,x+
        cmpx  #SCR+8000
        blo   @c
        lda   SEL
        ora   #1
        sta   SEL
        ldx   #SCR
@f      clr   ,x+
        cmpx  #SCR+8000
        blo   @f
        clr   row
        clr   col
        rts
Line    bsr   Str
Nl      clr   col
        inc   row
        rts
Str     lda   ,u+
        beq   @r
        bsr   Chr
        bra   Str
@r      rts
Hex4    pshs  b
        bsr   Hex
        puls  a
Hex     pshs  a
        lsra
        lsra
        lsra
        lsra
        bsr   Hex1
        puls  a
Hex1    anda  #$0F
        adda  #'0'
        cmpa  #'9'
        bls   Chr
        adda  #7
        bra   Chr
Dec2    clrb                           ; A (0-99) en decimal
@t      cmpa  #10
        blo   >
        suba  #10
        incb
        bra   @t
!       pshs  a
        tfr   b,a
        bsr   Hex1
        puls  a
        bra   Hex1
Chr     pshs  a,b,x,y,u
        ldb   col
        cmpb  #40
        bhs   @out
        suba  #32
        ldb   #5
        mul
        ldy   #Font
        leay  d,y
        lda   SEL
        ora   #1
        sta   SEL
        lda   row                      ; X = SCR + row*320 + col + 40
        ldb   #160
        mul
        lslb
        rola
        addb  col
        adca  #0
        addd  #SCR+40
        tfr   d,x
        lda   #5
        sta   cn
@l      ldb   ,y+
        clra
        bitb  #4
        beq   >
        ora   #$C0
!       bitb  #2
        beq   >
        ora   #$30
!       bitb  #1
        beq   >
        ora   #$0C
!       sta   ,x
        leax  40,x
        dec   cn
        bne   @l
        inc   col
@out    puls  a,b,x,y,u,pc

 IFDEF TO8
T0      fcc   "TEST VOIX MEA8000 - TO8 (E7FE/E7FF)"
 ELSE
T0      fcc   "TEST VOIX MEA8000 - MO6 (A7FE/A7FF)"
 ENDC
        fcb   0
T0b     fcc   "12 PHRASES DE SPACECRAFT EN BOUCLE"
        fcb   0
T1      fcc   "LA BARRE AVANCE D'UNE CASE PAR IMAGE."
        fcb   0
T2      fcc   "VRAIE MACHINE : ELLE NE S'ARRETE JAMAIS."
        fcb   0
T3      fcc   "SI ELLE SE FIGE A CHAQUE PHRASE : LAG."
        fcb   0
TMT     fcc   "METHODE T: TRAME TOUTES LES 30.72 MS    "
        fcb   0
TMR     fcc   "METHODE R: TRAME QUAND REQ VAUT 1       "
        fcb   0
TF      fcc   "IMAGES "
        fcb   0
TR1     fcc   "PHR "
        fcb   0
TR2     fcc   " IMG "
        fcb   0
TR3     fcc   "/"
        fcb   0
TR4     fcc   " LIBRE "
        fcb   0

frame   fdb   0
free    fdb   0
fmin    fdb   0
fbase   fdb   0
f_start fdb   0
expect  fdb   0
wait_t  fdb   0
phr     fcb   0
meth    fcb   0
playing fcb   0
res_row fcb   0
bar_c   fcb   0
row     fcb   0
col     fcb   0
cn      fcb   0
vo_on   fcb   0
vo_wait fcb   0
stuck   fcb   0
vo_left fcb   0
vo_ptr  fdb   0
vo_acc  fdb   0

        INCLUDE "font.asm"
        INCLUDE "voice-index.asm"
        INCLUDE "voice-data.asm"
