* Test voix - secteur d'amorcage MO6 ou TO8 (-D TO8) : lit NSECT secteurs
* (piste 0, secteur 2...) a l'adresse LOAD et y saute.
 IFDEF TO8
BASE    equ   $60
LOAD    equ   $6300
DKCO    equ   $E004
VPG     equ   $E7DD
 ELSE
BASE    equ   $20
LOAD    equ   $2300
DKCO    equ   $A004
VPG     equ   $A7DD
 ENDC
        org   LOAD-$100
        orcc  #$50
        lds   #LOAD
        lda   #BASE
        tfr   a,dp
        ldd   #LOAD
        std   <$4F
        clr   <$49
        clr   <$4A
        clr   <$4B
        lda   #2
        sta   <$4C
        lda   #NSECT
        sta   LOAD-$82
@rd     lda   #4
        sta   LOAD-$81
@try    lda   #2
        sta   <$48
        jsr   DKCO
        bcc   @ok
        dec   LOAD-$81
        bne   @try
@err    lda   #$01
        sta   VPG
        bra   @err
@ok     inc   <$4F
        inc   <$4C
        lda   <$4C
        cmpa  #17
        blo   >
        lda   #1
        sta   <$4C
        inc   <$4B
!       dec   LOAD-$82
        bne   @rd
        jmp   LOAD
