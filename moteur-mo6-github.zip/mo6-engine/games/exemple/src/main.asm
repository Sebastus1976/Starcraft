* =============================================================================
* Exemple minimal pour le moteur MO6 : un vaisseau qui se deplace (manette ou
* fleches) sur un fond noir, une petite musique, un texte. Tout tient dans la
* memoire programme : pas de page de donnees.
* =============================================================================
        INCLUDE "mo6.inc"

        org   $2300
Start
        lds   #$2300
        jsr   HwInit
        ldx   #PalBlack
        jsr   SetPal
        jsr   SoundInit
        jsr   VoiceInit
        jsr   ScreenInit               ; pages 2 et 3 noires, dessin en page 2
        ldx   #Pal
        jsr   SetPal
        ldx   #Song
        jsr   MusicPlay
        lda   #76
        sta   px
        lda   #100
        sta   py

Loop    jsr   ScreenBegin              ; efface l'image precedente de ce tampon
        jsr   ReadInput
        lda   in_dir
        ldb   px
        bita  #J_LEFT
        beq   >
        subb  #2
!       bita  #J_RIGHT
        beq   >
        addb  #2
!       cmpb  #160-Ship_W              ; (non signe : sous 0 = tres grand)
        bls   >
        ldb   px
!       stb   px
        ldb   py
        bita  #J_UP
        beq   >
        subb  #3
!       bita  #J_DOWN
        beq   >
        addb  #3
!       cmpb  #200-Ship_H
        bls   >
        ldb   py
!       stb   py
        tst   in_fire                  ; tir : bruitage
        beq   >
        lda   #SFX_SHOT
        jsr   SfxPlay
!       ldx   #SCR+4*40+12
        ldu   #Hello
        lda   #$11
        jsr   DrawText
        ldu   #SprShip
        lda   px
        ldb   py
        jsr   DrawSpr
        lda   #2                       ; 25 images par seconde
        jsr   ScreenEnd
        bra   Loop

px      fcb   0
py      fcb   0
Hello   fcc   "MOTEUR MO6"
        fcb   0
Pal     fdb   $0000,$FF0F,$0A00,$100B,$AE01,$A10D,$5506,$1102
        fdb   $A801,$0100,$2100,$6402,$0003,$4505,$2901,$B103
* morceau : 3 voies (note MIDI, duree en images ; $FF = boucle)
Song    fdb   SongMel,SongBass,SongPad
SongMel fcb   $45,12,$48,12,$4C,12,$48,12,$FF
SongBass fcb  $2D,24,$28,24,$FF
SongPad fcb   0,48,$FF
VoiceOffsets                           ; pas de voix dans cet exemple
VoiceData

        INCLUDE "hw.asm"
        INCLUDE "screen.asm"
        INCLUDE "text.asm"
        INCLUDE "amadeus.asm"
        INCLUDE "mea8000.asm"
        INCLUDE "font.asm"
        INCLUDE "digits.asm"
        INCLUDE "gen-sprites.asm"
