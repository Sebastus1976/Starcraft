# Spacecraft – démo jouable MO6

Démo du shoot'em up *Spacecraft* (jeu TO8 sur moteur wide-dot), refaite sur le moteur MO6 avec les mêmes graphismes, musiques et voix.

**Contenu :**

- écran titre comme sur TO8 : PRESS START qui clignote, option des voix (touche V ou haut/bas), en alternance avec l'écran HOW TO PLAY ; sans rien toucher, une démo se joue seule (30 s) ;
- histoire de Stan avant chaque partie (tir pour passer) ;
- 4 niveaux, comme la disquette démo du TO8 : décor qui défile (étoiles, planètes dont le halo change de couleur à chaque niveau), bandeaux de cockpit ;
- dans chaque niveau, 18 escadrilles et des météorites, avec les vitesses et la cadence du TO8 (début de niveau plus calme), puis le boss ;
- combos, STRIKE et les 3 capsules du TO8 (vie, canon jusqu'à 3, tir en éventail de 5 pendant 18 s) ;
- boss, puis game over avec meilleur score.

**Commandes :** manette 1 ou flèches, bouton ou ESPACE pour tirer.

**Disquette :**

| Emplacement | Contenu |
|---|---|
| piste 0 | programme |
| piste 4 | page de données (sprites, décor, musiques, voix) |
| piste 8 | image titre |
| piste 12 | image titre sans PRESS START |
| piste 16 | écrans HOW TO PLAY et histoire (compressés), en page 7 |

Construction : `./build.sh`. Pour les essais : `DEFS="-D GODMODE" ./build.sh` (pas de perte de vies), `-D QUICK` (boss après une escadrille, 2 impacts), `-D SHOWFPS` (images par tour affichées dans le bandeau), `-D FANTEST` (tir en éventail dès le départ).
