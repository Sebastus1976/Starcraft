#!/bin/sh
# Spacecraft MO6 : images -> donnees, assemblage, disquette (.fd + .sd)
#   ./build.sh                  jeu complet (16 etapes) -> build/spacecraft_mo6.fd/.sd
#   DEFS="-D DEMO_DISK" ./build.sh   demo (4 etapes)         -> build/spacecraft_mo6_demo.fd/.sd
set -e
cd "$(dirname "$0")"
E=$(cd ../../engine && pwd)
T=$(cd ../../tools && pwd)
LWASM=${LWASM:-$(command -v lwasm || echo "$T/lwasm")}
A=assets
mkdir -p build
python3 $T/mo6gfx.py sprites src/gen-sprites.asm \
  Ship=$A/sprites/ship-1.png Ship2=$A/sprites/ship-2.png Shot=$A/sprites/shot.png \
  EShot=$A/sprites/eshot.png Small=$A/sprites/small-1.png Esc=$A/sprites/esc-1.png \
  Chef=$A/sprites/chef-1.png Boss=$A/sprites/boss-1.png Met1=$A/sprites/met-1.png \
  Met2=$A/sprites/met-2.png Met3=$A/sprites/met-3.png Expl1=$A/sprites/expl-1.png \
  Expl2=$A/sprites/expl-2.png Expl3=$A/sprites/expl-3.png
python3 $T/mo6gfx.py sprites src/gen-caps.asm \
  Life=$A/sprites/life-1.png Canon=$A/sprites/canon-1.png Multi=$A/sprites/multi-1.png
python3 $T/mo6gfx.py tiles Lv1 $A/level1/level1.tiles.png $A/level1/level1.stm src/gen-tiles.asm
python3 $T/mo6gfx.py bands src/gen-bands.asm $A/band-top.png $A/band-bot.png
python3 $T/mo6gfx.py palette src/gen-pal.asm PalGame=$A/palettes/game.png PalTitle=$A/palettes/title.png PalStory=$A/palettes/story.png
python3 $T/mo6gfx.py page $A/title.png build/title.bin
python3 $T/mo6gfx.py page $A/title-off.png build/title-off.bin
cd src
$LWASM -f raw -o ../build/data.bin --symbol-dump=../build/data.sym -l../build/data.lst data.asm
[ $(stat -c%s ../build/data.bin) -le 16384 ] || { echo "donnees trop grosses"; exit 1; }
$LWASM -f raw -o ../build/extra.bin --symbol-dump=../build/extra.sym extra.asm
[ $(stat -c%s ../build/extra.bin) -le 16384 ] || { echo "ecrans trop gros"; exit 1; }
$LWASM -f raw $DEFS -I$E -I../build -o ../build/main.bin -l../build/main.lst main.asm
N=$(( ($(stat -c%s ../build/main.bin)+255)/256 ))
[ $N -le 61 ] || { echo "programme trop gros ($N secteurs)"; exit 1; }
$LWASM -f raw -D NSECT=$N -o ../build/boot.bin $E/boot.asm
cd ..
OUT=spacecraft_mo6
case "$DEFS" in *DEMO_DISK*) OUT=spacecraft_mo6_demo;; esac
python3 $T/mkdisk.py build/boot.bin build/$OUT.fd build/main.bin@0:2 \
  build/data.bin@4:1 build/title.bin@8:1 build/title-off.bin@12:1 build/extra.bin@16:1
echo "programme $(stat -c%s build/main.bin) octets, donnees $(stat -c%s build/data.bin) octets"
