#!/usr/bin/env python3
"""Spacecraft MO6 - edition physique : livret CD 8 pages, jaquette arriere du
boitier CD, etiquettes de disquette HERMA 70 x 67,7 mm.

Images a 300 dpi, PDF aux dimensions exactes (fond perdu 3 mm + traits de
coupe sur les planches A4).

  python3 print/gen-print.py [dossier de sortie]

Captures d'ecran dans print/captures (gameplay : banc d'essai tools/emu),
images (logo, vaisseaux, portrait de Stan) dans print/resources.
"""
import sys
import random
import importlib.util
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.pagesizes import A4, landscape

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RES = HERE / 'resources'
CAPS = HERE / 'captures'
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'build/print'

OUT.mkdir(parents=True, exist_ok=True)
DPI = 300
PX = DPI / 25.4                      # pixels par mm
BLEED = 3

F = '/usr/share/fonts/opentype/inter/'
def font(name, pt):
    return ImageFont.truetype(F + name, int(pt * DPI / 72))
H_BLACK = 'InterDisplay-Black.otf'
H_BOLD = 'InterDisplay-ExtraBold.otf'
T_REG = 'Inter-Regular.otf'
T_SEMI = 'Inter-SemiBold.otf'
T_BOLD = 'Inter-Bold.otf'

YELLOW = (247, 200, 66)
ORANGE = (240, 130, 30)
CYAN = (90, 210, 235)
GREY = (150, 150, 165)
WHITE = (238, 238, 242)
BG = (6, 6, 12)


def px(v):
    return int(round(v * PX))


# ---------------------------------------------------------------- ressources
def load_sprites():
    """Vaisseaux de la planche de l'auteur (deja decoupes, fond transparent)."""
    return {p.stem[5:]: Image.open(p).convert('RGBA') for p in RES.glob('ship_*.png')}


def game_png(path):
    """PNG du jeu (index k = couleur k-1, 0 = transparent) -> RGBA."""
    im = Image.open(path)
    pal = im.getpalette()
    w, h = im.size
    o = Image.new('RGBA', (w, h))
    for y in range(h):
        for x in range(w):
            i = im.getpixel((x, y))
            if i:
                o.putpixel((x, y), tuple(pal[3 * i:3 * i + 3]) + (255,))
    return o


def to8(img, w_mm):
    """Image TO8 (points doubles en largeur) agrandie sans lissage."""
    w = px(w_mm)
    h = int(w * img.height / img.width)
    return img.resize((w, h), Image.NEAREST)


def pixel_scale(img, w_mm, wide=2):
    """Sprite du jeu : un point TO8 = 2 de large pour 1 de haut."""
    base = img.resize((img.width * wide, img.height), Image.NEAREST)
    return to8(base, w_mm)


def logo_rgba():
    lg = Image.open(RES / 'intro-sans-texte.png').convert('RGB').crop((0, 4, 320, 52))
    o = Image.new('RGBA', lg.size)
    for y in range(lg.height):
        for x in range(lg.width):
            r, g, b = lg.getpixel((x, y))
            o.putpixel((x, y), (r, g, b, 0 if r + g + b < 140 else 255))
    return o


def cap(name):
    return Image.open(CAPS / name).convert('RGB')


# ---------------------------------------------------------------- decor
def starfield(w, h, seed=1, density=0.00009):
    im = Image.new('RGB', (w, h), BG)
    d = ImageDraw.Draw(im)
    rnd = random.Random(seed)
    for _ in range(int(w * h * density)):
        x, y = rnd.randrange(w), rnd.randrange(h)
        c = rnd.choice([(255, 255, 255), (190, 205, 255), (140, 150, 185)])
        s = rnd.choice([2, 3, 3, 4, 5])
        d.rectangle([x, y, x + s, y + s], fill=c)
    return im


def hud_bar(d, x0, y0, x1, h):
    """Bandeau facon tableau de bord du jeu."""
    d.rectangle([x0, y0, x1, y0 + h], fill=(70, 70, 82))
    d.rectangle([x0, y0 + 2, x1, y0 + 5], fill=(130, 130, 145))
    d.rectangle([x0, y0 + h - 4, x1, y0 + h], fill=(25, 25, 32))
    for x in range(x0 + 20, x1, 60):
        d.rectangle([x, y0 + 10, x + 4, y0 + h - 10], fill=(25, 25, 32))


def text_block(d, xy, text, fnt, fill, width, leading=1.32, para=0.55):
    """Texte justifie a gauche avec retours a la ligne ; renvoie y final."""
    x, y = xy
    lh = int(fnt.size * leading)
    for p in text.split('\n'):
        if not p.strip():
            y += int(lh * para)
            continue
        words = p.split(' ')
        line = ''
        for wd in words:
            t = (line + ' ' + wd).strip()
            if d.textlength(t, font=fnt) <= width:
                line = t
            else:
                d.text((x, y), line, font=fnt, fill=fill)
                y += lh
                line = wd
        if line:
            d.text((x, y), line, font=fnt, fill=fill)
            y += lh
        y += int(lh * (para - 0.25))
    return y


def heading(d, x, y, text, size=17, fill=YELLOW, spacing=0.06):
    f = font(H_BLACK, size)
    cx = x
    for ch in text:
        d.text((cx, y), ch, font=f, fill=fill)
        cx += d.textlength(ch, font=f) + f.size * spacing
    d.rectangle([x, y + int(f.size * 1.18), x + px(14), y + int(f.size * 1.18) + 6], fill=ORANGE)
    return y + int(f.size * 1.55)


def framed(page, img, x, y, border=CYAN):
    d = ImageDraw.Draw(page)
    d.rectangle([x - 6, y - 6, x + img.width + 5, y + img.height + 5], fill=border)
    d.rectangle([x - 3, y - 3, x + img.width + 2, y + img.height + 2], fill=BG)
    page.paste(img, (x, y))


def paste_rgba(page, img, x, y):
    page.paste(img, (int(x), int(y)), img)


# ---------------------------------------------------------------- pages livret
S = 120 + 2 * BLEED                  # page avec fond perdu (mm)
M = BLEED + 7                        # marge de lecture


def new_page(seed):
    page = starfield(px(S), px(S), seed)
    return page, ImageDraw.Draw(page)


def page_cover():
    page, d = new_page(11)
    art = Image.open(RES / 'intro-sans-texte.png').convert('RGB')
    w = px(S)
    aw = px(120 - 4)                         # dans la zone de coupe, avec une petite marge
    a = art.resize((aw, int(aw * art.height / art.width)), Image.NEAREST)
    top = px(BLEED + 6.5)
    page.paste(a, ((w - aw) // 2, top))
    # bords de l'image fondus dans le ciel de la page
    for side in (0, 1):
        g = Image.new('L', (px(6), a.height))
        gd = ImageDraw.Draw(g)
        for xx in range(g.width):
            v = int(255 * (1 - xx / g.width)) if side == 0 else int(255 * xx / g.width)
            gd.line([(xx, 0), (xx, g.height)], fill=v)
        xpos = (w - aw) // 2 if side == 0 else (w + aw) // 2 - g.width
        page.paste(Image.new('RGB', g.size, BG), (xpos, top), g)
    # fondu vers le noir en bas de l'image
    grad = Image.new('L', (w, px(22)))
    for yy in range(grad.height):
        ImageDraw.Draw(grad).line([(0, yy), (w, yy)], fill=int(255 * yy / grad.height))
    page.paste(Image.new('RGB', grad.size, BG), (0, top + a.height - grad.height), grad)
    page.paste(Image.new('RGB', (w, top), BG), (0, 0))
    hud_bar(d, 0, 0, w, px(BLEED + 5))
    y = top + a.height + px(1)
    f1 = font(H_BLACK, 13)
    t = 'SHOOT THEM UP SPATIAL'
    d.text(((w - d.textlength(t, font=f1)) / 2, y), t, font=f1, fill=WHITE)
    y += px(7)
    f2 = font(T_SEMI, 8.5)
    for t, c in (('THOMSON MO6  —  128 KO', CYAN),
                 ('CARTE SON AMADEUS  ·  SYNTHÉ VOCAL MEA8000 EN OPTION', GREY)):
        d.text(((w - d.textlength(t, font=f2)) / 2, y), t, font=f2, fill=c)
        y += px(4.6)
    f3 = font(H_BOLD, 8)
    t = 'RETROWORLD GAMING'
    d.text(((w - d.textlength(t, font=f3)) / 2, px(S - BLEED - 10.5)), t, font=f3, fill=ORANGE)
    hud_bar(d, 0, px(S) - px(BLEED + 5), w, px(BLEED + 5))
    return page


STAN = RES / 'stan.png'


def stan_rgba(w):
    """Portrait de Stan (fond magenta retire), w pixels de large."""
    im = Image.open(STAN).convert('RGBA')
    px_ = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px_[x, y]
            if r > 180 and b > 160 and g < 90:
                px_[x, y] = (0, 0, 0, 0)
    return im.resize((w, w), Image.NEAREST)


def text_flow(d, xy, text, fnt, fill, width_at, leading=1.3, para=0.5):
    """Comme text_block, largeur selon la hauteur (texte autour d'une image)."""
    x, y = xy
    lh = int(fnt.size * leading)
    for p in text.split('\n'):
        line = ''
        for wd in p.split(' '):
            t = (line + ' ' + wd).strip()
            if d.textlength(t, font=fnt) <= width_at(y):
                line = t
            else:
                d.text((x, y), line, font=fnt, fill=fill)
                y += lh
                line = wd
        if line:
            d.text((x, y), line, font=fnt, fill=fill)
            y += lh
        y += int(lh * (para - 0.25))
    return y


def page_story(sp):
    page, d = new_page(12)
    x, w = px(M), px(S - 2 * M)
    y = heading(d, x, px(M), 'HISTOIRE')
    pw = px(36)
    st = stan_rgba(pw)
    sx, sy = px(S - M) - pw, px(M)
    framed(page, Image.new('RGB', (pw, pw), BG), sx, sy)
    paste_rgba(page, st, sx, sy)
    f = font(H_BOLD, 10.5)
    d.text((x, y), 'L’Assaut de la Flotte Noire', font=f, fill=CYAN)
    y += int(f.size * 1.5)
    story = (
        "L’astronaute Stan pilotait son vaisseau de combat, le Space Craft, lorsqu’une "
        "alarme retentit dans le cockpit.\n"
        "« Attention ! De nombreux vaisseaux ennemis approchent ! »\n"
        "Stan regarda son radar et pâlit. Des dizaines de points rouges apparaissaient "
        "à l’écran. Une immense flotte ennemie avançait vers la planète Arcadia.\n"
        "Sans perdre une seconde, il activa ses canons laser et fonça vers les "
        "envahisseurs. Les premiers chasseurs ouvrirent le feu, transformant l’espace en "
        "un véritable champ de bataille. Les rayons lumineux traversaient le vide dans "
        "toutes les directions.\n"
        "Grâce à son habileté, Stan esquivait les tirs tout en ripostant. Un premier "
        "vaisseau ennemi explosa, puis un deuxième, puis un troisième. Mais la flotte "
        "continuait d’avancer.\n"
        "« Ils sont trop nombreux ! » s’exclama-t-il.")
    bottom = sy + pw + px(3)
    y = text_flow(d, (x, y), story, font(T_REG, 8.1), WHITE,
                  lambda yy: w - pw - px(4) if yy < bottom else w)
    y += px(1.5)
    d.text((x, y), 'À vous de l’aider à sauver Arcadia !', font=font(T_BOLD, 9), fill=YELLOW)
    t = cap('story.png')                     # l'ecran d'histoire du jeu
    tw = px(40)
    t = t.resize((tw, int(tw * 200 / 320)), Image.NEAREST)
    framed(page, t, px(S - M) - tw - 2, px(S - M) - t.height - 2)
    return page


def page_controls():
    page, d = new_page(13)
    x, w = px(M), px(S - 2 * M)
    y = heading(d, x, px(M), 'CHARGEMENT')
    y = text_block(d, (x, y),
                   "Matériel : Thomson MO6 (128 Ko) et la carte son Amadeus. Le "
                   "synthétiseur vocal MEA8000 est facultatif.\n"
                   "Insérez la disquette, allumez l'ordinateur et choisissez « 1 BASIC 128 » "
                   "dans le menu : le jeu démarre tout seul. Avec un lecteur SDDRIVE, "
                   "choisissez le fichier SPACECRAFT_MO6.SD.",
                   font(T_REG, 8.4), WHITE, w)
    y += px(2)
    y = heading(d, x, y, 'COMMANDES')
    rows = [('MANETTE / FLÈCHES', 'déplacer le vaisseau dans les 4 directions'),
            ('BOUTON / ESPACE', 'tirer'),
            ('ÉCRAN TITRE', 'tir ou une touche : l\u2019histoire de Stan, puis la partie'),
            ('SANS TOUCHER À RIEN', 'écran d\u2019aide HOW TO PLAY, puis démo (tir : retour)'),
            ('V  ou  HAUT / BAS', 'voix MEA8000 : VOICE ON / VOICE OFF')]
    fk, fv = font(T_BOLD, 8), font(T_REG, 8.2)
    for k, v in rows:
        d.rectangle([x, y + px(0.6), x + px(1.4), y + px(3.4)], fill=ORANGE)
        d.text((x + px(3), y), k, font=fk, fill=CYAN)
        y += px(4.0)
        d.text((x + px(3), y), v, font=fv, fill=WHITE)
        y += px(5.6)
    t = cap('title.png')
    t = t.resize((px(36), int(px(36) * 200 / 320)), Image.NEAREST)
    framed(page, t, px(S - M) - t.width - 2, px(S - M) - t.height - 2)
    return page


def page_bonus():
    page, d = new_page(14)
    x, w = px(M), px(S - 2 * M)
    y = heading(d, x, px(M), 'LES CAPSULES')
    y = text_block(d, (x, y),
                   "Les Bombers lâchent toujours une capsule en explosant, les autres "
                   "ennemis de temps en temps. Elles roulent vers le bas de l'écran : "
                   "passez dessus pour les ramasser.",
                   font(T_REG, 8.4), WHITE, w)
    y += px(2)
    items = [('life-1.png', 'VIE', 'une vie de plus (9 au maximum)', (60, 200, 90)),
             ('canon-1.png', 'CANON', 'un canon de plus, jusqu’à 3 tirs en parallèle', (230, 60, 50)),
             ('multi-1.png', 'MULTI-TIR', 'tir en éventail dans 5 directions pendant environ 20 s', YELLOW)]
    for f, k, v, c in items:
        im = pixel_scale(game_png(ROOT / 'assets/sprites' / f), 16)
        paste_rgba(page, im, x, y + px(1))
        tx = x + im.width + px(4)
        d.text((tx, y), k, font=font(T_BOLD, 9), fill=c)
        text_block(d, (tx, y + px(4.4)), v, font(T_REG, 8.2), WHITE, w - (tx - x))
        y += max(im.height, px(13)) + px(5)
    y = text_block(d, (x, y),
                   "Touché par un ennemi, un tir ou une météorite, vous perdez une vie "
                   "et un canon. Vous redevenez intouchable pendant quelques instants.",
                   font(T_REG, 8.0), GREY, w)
    return page


def page_enemies(sp):
    page, d = new_page(15)
    x, w = px(M), px(S - 2 * M)
    y = heading(d, x, px(M), 'L’ENNEMI')
    ents = [('small', 'DRONE', '50 pts', 'Arrive en escadrilles et file en S.'),
            ('esc', 'FIGHTER', '80 pts', 'Escorte rapide, elle vous tire dessus.'),
            ('chef', 'BOMBER', '150 pts', 'Chef d’escadrille : 3 impacts. Lâche une capsule.'),
            ('boss', 'MOTHERSHIP', '2000 pts', 'Le vaisseau-mère de fin de secteur. Il lance ses drones.')]
    col = px(26)
    for key, n, pts, txt in ents:
        im = sp[key]
        tw = px(22) if key != 'boss' else px(25)
        s = im.resize((tw, int(tw * im.height / im.width)), Image.NEAREST)
        if s.height > px(16):
            s = im.resize((int(px(16) * im.width / im.height), px(16)), Image.NEAREST)
        paste_rgba(page, s, x + (col - s.width) // 2, y + (px(16) - s.height) // 2)
        tx = x + col + px(2)
        d.text((tx, y), n, font=font(T_BOLD, 9.5), fill=YELLOW)
        d.text((tx + d.textlength(n + '  ', font=font(T_BOLD, 9.5)), y + px(0.4)), pts,
               font=font(T_SEMI, 8.2), fill=CYAN)
        text_block(d, (tx, y + px(4.8)), txt, font(T_REG, 8.0), WHITE, w - col - px(2))
        y += px(20)
    met = pixel_scale(game_png(ROOT / 'assets/sprites/met-1.png'), 9)
    paste_rgba(page, met, x + (col - met.width) // 2, y)
    d.text((x + col + px(2), y), 'MÉTÉORITES', font=font(T_BOLD, 9.5), fill=YELLOW)
    d.text((x + col + px(2) + d.textlength('MÉTÉORITES  ', font=font(T_BOLD, 9.5)), y + px(0.4)),
           '20 pts', font=font(T_SEMI, 8.2), fill=CYAN)
    text_block(d, (x + col + px(2), y + px(4.8)), 'Destructibles, mais mortelles au contact.',
               font(T_REG, 8.0), WHITE, w - col - px(2))
    return page


def page_combos():
    page, d = new_page(16)
    x, w = px(M), px(S - 2 * M)
    y = heading(d, x, px(M), 'COMBOS & STRIKE')
    y = text_block(d, (x, y),
                   "Abattez les ennemis coup sur coup, à moins d’une seconde "
                   "d’intervalle : chaque destruction de la série rapporte 50 points "
                   "de plus par ennemi enchaîné.",
                   font(T_REG, 8.4), WHITE, w)
    for k, v in (('2', 'DOUBLE !'), ('3', 'TRIPLE !'), ('4', 'COMBO !'), ('5+', 'SUPER COMBO !')):
        d.text((x + px(2), y), 'x' + k, font=font(H_BLACK, 10), fill=ORANGE)
        d.text((x + px(14), y + px(0.5)), v, font=font(T_BOLD, 9), fill=WHITE)
        y += px(5.2)
    y += px(1.5)
    y = text_block(d, (x, y),
                   "STRIKE ! Détruisez une escadrille entière avant qu’elle ne "
                   "quitte l’écran : +500 points.",
                   font(T_SEMI, 8.4), YELLOW, w)
    sw = px(51)
    a = cap('combo.png').resize((sw, int(sw * 200 / 320)), Image.NEAREST)
    b = cap('strike.png').resize((sw, int(sw * 200 / 320)), Image.NEAREST)
    yy = y + px(5)
    framed(page, a, x + 3, yy)
    framed(page, b, px(S - M) - b.width - 3, yy)
    return page


def page_journey():
    page, d = new_page(17)
    x, w = px(M), px(S - 2 * M)
    y = heading(d, x, px(M), 'LE VOYAGE')
    y = text_block(d, (x, y),
                   "Seize secteurs, chacun gardé par son vaisseau-mère. Quand l’alerte "
                   "WARNING retentit, tenez bon : il n’explose qu’après une longue "
                   "série d’impacts. Au bout du seizième secteur, un générique "
                   "salue votre victoire.",
                   font(T_REG, 8.4), WHITE, w)
    sw = px(S - 2 * M) // 2 - px(2)
    a = cap('warning.png').resize((sw, int(sw * 200 / 320)), Image.NEAREST)
    b = cap('boss.png').resize((sw, int(sw * 200 / 320)), Image.NEAREST)
    framed(page, a, x + 3, y + px(1))
    framed(page, b, px(S - M) - b.width - 3, y + px(1))
    y += a.height + px(6)
    y = heading(d, x, y, 'LE SON', size=14)
    text_block(d, (x, y),
               "Musiques et bruitages sur la carte Amadeus (YM2413 et SN76489). Avec un "
               "synthétiseur vocal MEA8000, une voix annonce combos, alertes et "
               "victoires ; sans synthétiseur, choisissez VOICE OFF à l’écran titre.",
               font(T_REG, 8.0), WHITE, w)
    return page


def page_credits():
    page, d = new_page(18)
    w = px(S)
    logo = logo_rgba()
    lw = px(92)
    lg = logo.resize((lw, int(lw * logo.height / logo.width)), Image.NEAREST)
    paste_rgba(page, lg, (w - lw) // 2, px(M + 4))
    y = px(M + 4) + lg.height + px(8)
    blocks = [('UN JEU', 'RETROWORLD GAMING'),
              ('POUR', 'THOMSON MO6'),
              ('SON', 'CARTE AMADEUS  ·  MEA8000'),
              ('MOTEUR', 'MOTEUR MO6  ·  D’APRÈS LA VERSION TO8'),
              ('VAISSEAUX ET ÉCRAN TITRE', 'RETROWORLD GAMING')]
    for k, v in blocks:
        f1, f2 = font(T_SEMI, 7.2), font(H_BOLD, 10)
        d.text(((w - d.textlength(k, font=f1)) / 2, y), k, font=f1, fill=CYAN)
        y += px(3.8)
        d.text(((w - d.textlength(v, font=f2)) / 2, y), v, font=f2, fill=WHITE)
        y += px(7.2)
    f = font(T_REG, 7.2)
    t = '© 2026 Retroworld Gaming'
    d.text(((w - d.textlength(t, font=f)) / 2, px(S - M - 4)), t, font=f, fill=GREY)
    hud_bar(d, 0, px(S) - px(BLEED + 5), w, px(BLEED + 5))
    return page


# ---------------------------------------------------------------- jaquette arriere
def tray_inlay(sp):
    """Jaquette arriere du boitier CD : 151 x 118 mm (tranches de 6,5 mm)."""
    W, H, SP = 151, 118, 6.5
    im = starfield(px(W + 2 * BLEED), px(H + 2 * BLEED), 21)
    d = ImageDraw.Draw(im)
    ox, oy = px(BLEED), px(BLEED)
    # tranches
    for sx in (0, W - SP):
        x0 = ox + px(sx)
        d.rectangle([x0, 0, x0 + px(SP), im.height], fill=(18, 18, 26))
        t = 'SPACECRAFT   ·   THOMSON MO6   ·   RETROWORLD GAMING'
        f = font(H_BOLD, 9)
        tw = int(d.textlength(t, font=f))
        tim = Image.new('RGBA', (tw + 20, f.size + 20), (0, 0, 0, 0))
        ImageDraw.Draw(tim).text((10, 0), t, font=f, fill=YELLOW)
        tim = tim.rotate(90 if sx == 0 else -90, expand=True)
        im.paste(tim, (x0 + (px(SP) - tim.width) // 2, oy + (px(H) - tim.height) // 2), tim)
    # face arriere
    x0 = ox + px(SP + 6)
    x1 = ox + px(W - SP - 6)
    w = x1 - x0
    logo = logo_rgba()
    lw = px(78)
    lg = logo.resize((lw, int(lw * logo.height / logo.width)), Image.NEAREST)
    paste_rgba(im, lg, x0 + (w - lw) // 2, oy + px(5))
    y = oy + px(5) + lg.height + px(3)
    y = text_block(d, (x0, y),
                   "La Flotte Noire fonce vers la planète Arcadia ! Aux commandes du "
                   "SPACE CRAFT, aidez l’astronaute Stan à traverser seize secteurs, "
                   "à détruire les escadrilles et à abattre chaque vaisseau-mère !",
                   font(T_SEMI, 8.6), WHITE, w)
    sw = (w - px(8)) // 3
    shots = ['play.png', 'strike.png', 'boss.png']
    y += px(2)
    for i, f in enumerate(shots):
        s = cap(f).resize((sw, int(sw * 200 / 320)), Image.NEAREST)
        framed(im, s, x0 + 3 + i * (sw + px(4)), y)
    y += int(sw * 200 / 320) + px(5)
    feats = ['16 secteurs en défilement vertical',
             'Escadrilles en S, Bombers et vaisseaux-mères',
             'Capsules : vie, canons, tir en éventail',
             'Combos et STRIKE, voix sur MEA8000 (option)',
             'Musiques originales sur carte Amadeus',
             'Écran d’aide, histoire de Stan et mode démo']
    fb = font(T_REG, 8.4)
    for i, t in enumerate(feats):
        cx, cy = x0 + px(2), y + i * px(4.9)
        d.rectangle([cx, cy + px(0.9), cx + px(1.2), cy + px(3.1)], fill=ORANGE)
        d.text((cx + px(3), cy), t, font=fb, fill=WHITE)
    y += len(feats) * px(4.9) + px(3)
    # encart materiel
    d.rectangle([x0, y, x1, y + px(10)], outline=CYAN, width=4)
    ft = font(T_SEMI, 7.4)
    t1 = 'THOMSON MO6  ·  128 KO  ·  DISQUETTE 3"1/2 OU SDDRIVE'
    t2 = 'CARTE SON AMADEUS REQUISE  ·  SYNTHÉ VOCAL MEA8000 FACULTATIF  ·  MANETTE CONSEILLÉE'
    d.text((x0 + (w - d.textlength(t1, font=ft)) / 2, y + px(1.3)), t1, font=ft, fill=CYAN)
    d.text((x0 + (w - d.textlength(t2, font=ft)) / 2, y + px(5.4)), t2, font=ft, fill=WHITE)
    f3 = font(H_BOLD, 8)
    t = 'RETROWORLD GAMING  ·  2026'
    d.text((x0 + (w - d.textlength(t, font=f3)) / 2, oy + px(H - 7)), t, font=f3, fill=ORANGE)
    return im, (W, H, SP)


# ---------------------------------------------------------------- etiquette disquette
def floppy_label(sp):
    W, H = 70, 67.7
    im = starfield(px(W), px(H), 31, density=0.0005)
    d = ImageDraw.Draw(im)
    hud_bar(d, 0, 0, im.width, px(4))
    logo = logo_rgba()
    lw = px(W - 8)
    lg = logo.resize((lw, int(lw * logo.height / logo.width)), Image.NEAREST)
    paste_rgba(im, lg, (im.width - lw) // 2, px(6))
    ship = sp['ship']
    s = ship.resize((px(19), int(px(19) * ship.height / ship.width)), Image.NEAREST)
    boss = sp['boss']
    b = boss.resize((px(24), int(px(24) * boss.height / boss.width)), Image.NEAREST)
    paste_rgba(im, b, im.width - b.width - px(4), px(19))
    paste_rgba(im, s, px(6), px(27))
    y = px(47)
    for t, f, c in (('THOMSON MO6  —  128 KO', font(T_BOLD, 7.4), CYAN),
                    ('CARTE SON AMADEUS  ·  MEA8000 EN OPTION', font(T_SEMI, 6.2), WHITE),
                    ('DISQUETTE DE JEU  ·  3"1/2 DD', font(T_SEMI, 6.2), GREY)):
        d.text(((im.width - d.textlength(t, font=f)) / 2, y), t, font=f, fill=c)
        y += px(4.1)
    f = font(H_BOLD, 7)
    t = 'RETROWORLD GAMING  ·  2026'
    d.text(((im.width - d.textlength(t, font=f)) / 2, px(H - 5.5)), t, font=f, fill=ORANGE)
    return im, (W, H)


# ---------------------------------------------------------------- PDF
def crop_marks(c, x, y, w, h, l=5 * mm, off=1.5 * mm):
    c.setLineWidth(0.25)
    c.setStrokeColorRGB(0, 0, 0)
    for (px_, py_) in ((x, y), (x + w, y), (x, y + h), (x + w, y + h)):
        sx = -1 if px_ == x else 1
        sy = -1 if py_ == y else 1
        c.line(px_ + sx * off, py_, px_ + sx * (off + l), py_)
        c.line(px_, py_ + sy * off, px_, py_ + sy * (off + l))


def save_png(img, name):
    p = OUT / name
    img.save(p, dpi=(DPI, DPI))
    return p


def main():
    sp = load_sprites()
    pages = [page_cover(), page_story(sp), page_controls(), page_bonus(),
             page_enemies(sp), page_combos(), page_journey(), page_credits()]
    files = [save_png(p, 'livret_page%d.png' % (i + 1)) for i, p in enumerate(pages)]

    # livret page par page (120 x 120 + fond perdu)
    c = canvas.Canvas(str(OUT / 'Spacecraft_MO6_livret_CD_pages.pdf'), pagesize=(S * mm, S * mm))
    for f in files:
        c.drawImage(str(f), 0, 0, S * mm, S * mm)
        c.showPage()
    c.save()

    # imposition A4 paysage, recto verso (bord court) : 2 feuilles plieees
    # feuille 1 : recto 8|1, verso 2|7 ; feuille 2 : recto 6|3, verso 4|5
    order = [(8, 1), (2, 7), (6, 3), (4, 5)]
    pw, ph = landscape(A4)
    c = canvas.Canvas(str(OUT / 'Spacecraft_MO6_livret_CD_impression_A4.pdf'), pagesize=(pw, ph))
    tw, th = 240 * mm, 120 * mm
    x0, y0 = (pw - tw) / 2, (ph - th) / 2
    for i, (l, r) in enumerate(order):
        # chaque page avec son fond perdu, rognee au pli
        for k, n in enumerate((l, r)):
            img = Image.open(files[n - 1])
            b = px(BLEED)
            box = (b, 0, img.width, img.height) if k == 1 else (0, 0, img.width - b, img.height)
            part = img.crop(box)
            tmp = OUT / ('_imp_%d_%d.png' % (i, k))
            part.save(tmp, dpi=(DPI, DPI))
            wmm = part.width / PX
            xx = x0 + (120 * mm if k == 1 else -BLEED * mm)
            c.drawImage(str(tmp), xx, y0 - BLEED * mm, wmm * mm, S * mm)
            tmp.unlink()
        crop_marks(c, x0, y0, tw, th)
        c.setLineWidth(0.25)
        c.line(pw / 2, y0 + th + 1.5 * mm, pw / 2, y0 + th + 6 * mm)   # repere de pli
        c.line(pw / 2, y0 - 1.5 * mm, pw / 2, y0 - 6 * mm)
        c.setFont('Helvetica', 7)
        c.drawString(10 * mm, 8 * mm, 'Spacecraft MO6 - livret CD - feuille %d %s - imprimer recto verso '
                     '(retourner sur le bord court), 100 %%, sans ajustement'
                     % (i // 2 + 1, 'recto' if i % 2 == 0 else 'verso'))
        c.showPage()
    c.save()

    # jaquette arriere
    tray, (W, H, SP) = tray_inlay(sp)
    tf = save_png(tray, 'jaquette_arriere.png')
    pw, ph = A4
    c = canvas.Canvas(str(OUT / 'Spacecraft_MO6_jaquette_arriere_CD.pdf'), pagesize=(pw, ph))
    x0, y0 = (pw - W * mm) / 2, (ph - H * mm) / 2
    c.drawImage(str(tf), x0 - BLEED * mm, y0 - BLEED * mm, (W + 2 * BLEED) * mm, (H + 2 * BLEED) * mm)
    crop_marks(c, x0, y0, W * mm, H * mm)
    c.setLineWidth(0.25)
    for sx in (SP, W - SP):                                      # plis des tranches
        c.line(x0 + sx * mm, y0 + H * mm + 1.5 * mm, x0 + sx * mm, y0 + H * mm + 6 * mm)
        c.line(x0 + sx * mm, y0 - 1.5 * mm, x0 + sx * mm, y0 - 6 * mm)
    c.setFont('Helvetica', 7)
    c.drawString(10 * mm, 8 * mm, 'Spacecraft MO6 - jaquette arriere du boitier CD 151 x 118 mm '
                 '(tranches 6,5 mm) - imprimer a 100 %, sans ajustement')
    c.showPage()
    # couverture seule (12 x 12) sur la meme planche, pour qui n'imprime pas le livret
    c.drawImage(str(files[0]), (pw - S * mm) / 2, (ph - S * mm) / 2, S * mm, S * mm)
    crop_marks(c, (pw - 120 * mm) / 2, (ph - 120 * mm) / 2, 120 * mm, 120 * mm)
    c.drawString(10 * mm, 8 * mm, 'Spacecraft MO6 - jaquette avant 120 x 120 mm (couverture seule)')
    c.showPage()
    c.save()

    # etiquettes HERMA 70 x 67,7 mm, 8 par planche A4 portrait (modele HERMA
    # "70x67-7-8st") : 2 colonnes x 4 rangees, marge gauche 25 mm, 20 mm entre
    # les colonnes, marge haute 13,04 mm, rangees de 67,73 mm sans espace
    lab, (W, H) = floppy_label(sp)
    lf = save_png(lab, 'etiquette_disquette.png')
    c = canvas.Canvas(str(OUT / 'Spacecraft_MO6_etiquettes_HERMA_70x67.pdf'), pagesize=A4)
    TW = 25.4 / 1440                                    # twip -> mm
    left, gap, top, rowh = 1417 * TW, 1134 * TW, 739 * TW, 3840 * TW
    for r_ in range(4):
        for k in range(2):
            x = left + k * (W + gap)
            y = 297 - top - (r_ + 1) * rowh
            c.drawImage(str(lf), x * mm, y * mm, W * mm, rowh * mm)
    c.showPage()
    c.save()
    print('ok')


if __name__ == '__main__':
    main()
