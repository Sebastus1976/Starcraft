* genere par tools/mo6gfx.py palette
PalGame_WHITE equ $11
PalGame
        fdb   $0000,$FF0F,$0A00,$100B,$AE01,$A10D,$5506,$1102
        fdb   $3E00,$0100,$1200,$3601,$0001,$2105,$1700,$6101
PalTitle_WHITE equ $FF
PalTitle
        fdb   $0000,$9B02,$7B01,$6901,$3A01,$3403,$2302,$1301
        fdb   $1101,$1101,$0001,$0000,$0000,$0000,$0000,$9B08
PalStory_WHITE equ $BB
PalStory
        fdb   $0000,$9908,$7E02,$5704,$3302,$2202,$1101,$1100
        fdb   $0000,$0000,$0000,$DD0D,$AE01,$A10D,$3E00,$1102
