* =============================================================================
* Spacecraft MO6 - page des ecrans (page 7, vue en $B000-$EFFF quand on la
* decompresse) : ecran d'information et histoire de Stan, en RLE (images du
* jeu TO8, tools/gen-info.py et tools/gen-story.py)
* =============================================================================
        org   $B000
        INCLUDE "info-rle.asm"
        INCLUDE "story-rle.asm"
ExtraEnd
