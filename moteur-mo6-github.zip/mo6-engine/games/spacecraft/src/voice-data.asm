* genere par tools/gen-voice.py : voix originales (espeak-ng -> MEA8000)
VoiceData
* DOUBLE : "double!" (14 trames)
        fcb   $26,$0E,$B9,$B4,$95,$46,$BD,$B2,$AD,$C7,$BD,$B2,$AE,$47,$BD,$B2
        fcb   $AF,$5E,$BD,$B2,$AE,$DE,$B9,$B0,$7C,$DD,$05,$90,$54,$58,$B9,$8E
        fcb   $7C,$5D,$F9,$CD,$84,$DE,$FD,$CC,$7C,$DF,$FD,$CB,$74,$5E,$F9,$CA
        fcb   $73,$40,$E9,$CA,$72,$C0,$E9,$CA,$70,$50
* TRIPLE : "triple!" (16 trames)
        fcb   $26,$10,$55,$B5,$95,$50,$55,$B6,$9C,$D0,$E1,$71,$52,$43,$F9,$93
        fcb   $64,$C3,$FD,$B7,$76,$43,$FD,$B8,$76,$C2,$FD,$B7,$6E,$DF,$E9,$B5
        fcb   $6D,$DE,$01,$91,$B0,$50,$55,$B8,$D4,$50,$F5,$AD,$84,$55,$FD,$CC
        fcb   $84,$C0,$FD,$CB,$7C,$40,$FD,$CA,$73,$C0,$ED,$CB,$73,$C0,$ED,$CB
        fcb   $70,$50
* COMBO : "combo!" (20 trames)
        fcb   $26,$14,$45,$B5,$AD,$50,$A5,$B3,$BD,$44,$B9,$B1,$C5,$C4,$BD,$B1
        fcb   $C6,$44,$BD,$D1,$C7,$5E,$BD,$D1,$C6,$DF,$B9,$B0,$BD,$DF,$B5,$8F
        fcb   $4B,$5F,$F9,$8F,$3A,$5F,$F9,$8F,$3A,$5F,$F5,$8F,$3A,$5F,$49,$90
        fcb   $63,$DE,$AD,$8F,$8C,$50,$BD,$B0,$9D,$5A,$BD,$AF,$9D,$40,$BD,$AE
        fcb   $9D,$40,$BD,$AC,$8C,$C0,$BD,$AB,$7B,$C0,$BD,$AB,$7B,$50,$BD,$AB
        fcb   $78,$50
* SUPER : "super combo!" (34 trames)
        fcb   $26,$22,$51,$D7,$FB,$D0,$55,$D7,$FB,$D0,$FD,$95,$63,$C2,$FD,$94
        fcb   $5C,$C0,$FD,$93,$5C,$C1,$BD,$91,$5C,$40,$BD,$8E,$5B,$41,$01,$B9
        fcb   $B3,$50,$65,$93,$8C,$41,$FD,$94,$8C,$C0,$FD,$94,$85,$41,$FD,$75
        fcb   $84,$C1,$55,$75,$82,$50,$09,$B5,$C4,$50,$95,$B4,$B4,$D0,$B9,$B3
        fcb   $C5,$C3,$BD,$D1,$CE,$C1,$BD,$D1,$CE,$C1,$BD,$D1,$CE,$DF,$BD,$D1
        fcb   $C7,$5E,$69,$AF,$A5,$DF,$B5,$90,$3A,$DF,$F9,$B0,$3A,$DF,$F5,$AF
        fcb   $3A,$DF,$F5,$8F,$3A,$5F,$5D,$8F,$7C,$50,$BD,$B0,$9C,$50,$BD,$B0
        fcb   $9E,$58,$BD,$AF,$9D,$40,$BD,$AD,$94,$C0,$BD,$AB,$7B,$C0,$BD,$AB
        fcb   $7B,$40,$55,$AB,$78,$50,$55,$AB,$78,$50
* POWER : "more power!" (24 trames)
        fcb   $26,$18,$B5,$8F,$43,$41,$B5,$AF,$74,$41,$A9,$AA,$8C,$C1,$F9,$AB
        fcb   $94,$C1,$B9,$8D,$95,$41,$FD,$70,$8C,$C1,$A9,$6F,$94,$C0,$99,$4B
        fcb   $9B,$41,$01,$91,$B0,$50,$41,$D9,$DC,$50,$B9,$B1,$CD,$C2,$FD,$B2
        fcb   $D6,$C1,$FD,$B2,$CE,$C1,$FD,$B2,$CF,$5E,$BD,$B1,$C6,$DF,$B9,$AF
        fcb   $AE,$5E,$B9,$92,$94,$D0,$FD,$94,$84,$D0,$FD,$94,$85,$D6,$FD,$93
        fcb   $84,$D0,$FD,$93,$84,$C0,$FD,$73,$84,$C0,$FD,$73,$83,$50,$FD,$73
        fcb   $80,$50
* LIFE : "extra life!" (30 trames)
        fcb   $26,$1E,$FD,$B7,$A7,$41,$FD,$B6,$A6,$CC,$BD,$B6,$AF,$DE,$E9,$B7
        fcb   $AE,$5F,$05,$93,$98,$48,$55,$B8,$A4,$D0,$A5,$D8,$FB,$D0,$A5,$B7
        fcb   $F3,$D0,$55,$B7,$F3,$D0,$05,$FB,$A2,$D0,$55,$B6,$9D,$50,$F5,$70
        fcb   $62,$51,$B5,$93,$96,$5E,$F9,$B3,$96,$5F,$FD,$D3,$6C,$C0,$FD,$D3
        fcb   $75,$5F,$FD,$D2,$AE,$5F,$FD,$B2,$CE,$DF,$FD,$B2,$CD,$D0,$FD,$B3
        fcb   $CD,$D0,$E9,$B5,$BE,$50,$E9,$B7,$96,$50,$F9,$B8,$7D,$50,$F9,$B6
        fcb   $7D,$50,$15,$B5,$E4,$D0,$A5,$B6,$F3,$50,$95,$B6,$FB,$50,$55,$B6
        fcb   $FB,$50,$55,$B6,$F8,$50,$55,$B6,$F8,$50
* STRIKE : "strike!" (20 trames)
        fcb   $26,$14,$95,$D7,$FB,$D0,$A5,$B7,$F3,$D0,$55,$B7,$F4,$50,$05,$B7
        fcb   $95,$50,$55,$B5,$8C,$D0,$F9,$50,$6A,$C3,$F9,$90,$A4,$C2,$FD,$B2
        fcb   $CE,$43,$FD,$B2,$D6,$C3,$FD,$B3,$D5,$D0,$FD,$B4,$CE,$50,$F9,$B6
        fcb   $AE,$50,$FD,$B8,$85,$50,$FD,$B9,$7C,$D0,$E9,$BA,$87,$59,$05,$93
        fcb   $A8,$5E,$15,$9A,$8B,$D0,$11,$B8,$A5,$47,$09,$93,$40,$50,$09,$93
        fcb   $40,$50
* READY : "get ready!" (22 trames)
        fcb   $26,$16,$E9,$B8,$95,$DD,$FD,$B6,$A7,$41,$FD,$B5,$AE,$C1,$FD,$B5
        fcb   $AE,$41,$41,$96,$D0,$4F,$65,$D8,$D3,$D0,$05,$8E,$74,$50,$F5,$51
        fcb   $5B,$5A,$A5,$93,$7D,$C2,$FD,$B7,$A7,$41,$FD,$B6,$A7,$5F,$FD,$B6
        fcb   $A7,$5E,$FD,$B5,$AF,$5E,$BD,$B5,$96,$5F,$D1,$B6,$33,$5B,$E5,$B7
        fcb   $44,$5C,$F9,$B8,$5D,$C0,$FD,$B9,$66,$40,$FD,$B9,$5D,$C0,$FD,$B9
        fcb   $5D,$40,$FD,$B9,$5C,$4B,$FD,$B9,$58,$50
* WARNING : "warning!" (20 trames)
        fcb   $26,$14,$79,$DA,$65,$C0,$FD,$A5,$59,$C3,$F9,$AA,$8B,$C3,$F9,$AC
        fcb   $A4,$C4,$F9,$AC,$A5,$43,$F9,$8E,$9D,$DE,$F9,$70,$8C,$DF,$FD,$71
        fcb   $8C,$DE,$FD,$72,$7C,$DF,$A1,$B5,$4C,$DF,$FD,$B7,$64,$D0,$FD,$B8
        fcb   $77,$58,$FD,$B7,$76,$DF,$FD,$B8,$76,$40,$FD,$BA,$7D,$C0,$AD,$A2
        fcb   $49,$40,$AD,$A2,$49,$40,$9D,$A3,$49,$40,$55,$A3,$48,$50,$55,$A3
        fcb   $48,$50
* BOSS : "boss destroyed!" (34 trames)
        fcb   $26,$22,$B5,$AF,$AD,$41,$F9,$CF,$BD,$C6,$F9,$CF,$BE,$46,$F9,$CF
        fcb   $BE,$DF,$F9,$D0,$BE,$DF,$B9,$B1,$BE,$40,$41,$D7,$FC,$D0,$55,$D7
        fcb   $FC,$50,$55,$D7,$FD,$C7,$A1,$B6,$40,$56,$FD,$B6,$6D,$DF,$FD,$B6
        fcb   $7E,$5F,$B9,$B5,$86,$5F,$A1,$B7,$FB,$D0,$E5,$B7,$EB,$50,$55,$B7
        fcb   $E8,$50,$01,$B8,$9D,$50,$55,$B5,$9C,$D0,$B5,$50,$6A,$DE,$FD,$70
        fcb   $6B,$DF,$B9,$8E,$8C,$C0,$F9,$AD,$A5,$DF,$FD,$AD,$A5,$DF,$B9,$B0
        fcb   $A6,$40,$B9,$B3,$9E,$50,$F9,$B5,$96,$5D,$F5,$B7,$6D,$50,$F9,$D7
        fcb   $5D,$C0,$F5,$D7,$55,$40,$F5,$B7,$33,$C0,$91,$B4,$3A,$C0,$15,$D7
        fcb   $FB,$D0,$29,$D7,$F2,$D0,$29,$D7,$F0,$50
* OVER : "game over!" (25 trames)
        fcb   $26,$19,$E9,$98,$6C,$C1,$F9,$B7,$8E,$C6,$FD,$B7,$8E,$C6,$FD,$B8
        fcb   $87,$5F,$FD,$B9,$6E,$5F,$15,$B7,$CF,$DE,$B5,$8F,$42,$C0,$79,$B1
        fcb   $85,$5F,$BD,$B0,$95,$DF,$BD,$AF,$9D,$C0,$BD,$AE,$9D,$DF,$BD,$AD
        fcb   $95,$5F,$BD,$AB,$84,$DF,$BD,$AA,$73,$DF,$AD,$AC,$6B,$DF,$95,$B5
        fcb   $4B,$DE,$81,$93,$4B,$D0,$BD,$71,$8C,$5C,$FD,$93,$8C,$C0,$FD,$93
        fcb   $85,$40,$FD,$93,$85,$40,$FD,$93,$84,$D0,$FD,$73,$84,$40,$B9,$73
        fcb   $7B,$D0,$B9,$73,$78,$50
* COMPLETE : "mission complete!" (38 trames)
        fcb   $26,$26,$B5,$8F,$43,$40,$55,$FA,$FD,$C5,$FD,$B7,$76,$43,$FD,$B7
        fcb   $6E,$C4,$FD,$B7,$6E,$DF,$D5,$B8,$6D,$C0,$05,$B9,$CC,$D0,$55,$B9
        fcb   $CD,$50,$E9,$B6,$8D,$D0,$F5,$B5,$8D,$DD,$F9,$B4,$8E,$DF,$B5,$B4
        fcb   $65,$C0,$FD,$B7,$65,$DF,$FD,$B7,$65,$C0,$09,$B6,$E8,$50,$09,$B5
        fcb   $BD,$50,$E5,$B6,$8C,$D0,$F5,$B4,$8D,$DF,$B5,$B4,$8E,$40,$F9,$8F
        fcb   $3A,$DF,$F5,$8F,$3A,$DF,$15,$B4,$9C,$D0,$55,$B4,$B4,$D0,$65,$B4
        fcb   $6C,$D0,$F9,$D3,$5C,$DE,$B9,$D6,$65,$DF,$F5,$D8,$66,$40,$F9,$D9
        fcb   $4E,$40,$FD,$DA,$4D,$D0,$F9,$DA,$45,$D0,$F9,$DA,$46,$5C,$F9,$DA
        fcb   $3C,$D0,$F9,$B9,$33,$4D,$41,$B7,$C8,$5F,$65,$D8,$D4,$50,$55,$D8
        fcb   $DE,$42,$55,$B2,$B8,$50,$55,$B2,$B8,$50
