* =============================================================================
* Spacecraft MO6 - page de donnees (page 5, vue en $B000-$EFFF)
* Assemble a part ; ses symboles sont repris par main.asm (build/data.sym).
* (musiques et voix : dans la memoire programme, voir main.asm)
* =============================================================================
        org   $B000
        INCLUDE "gen-tiles.asm"
        INCLUDE "gen-sprites.asm"
DataEnd
