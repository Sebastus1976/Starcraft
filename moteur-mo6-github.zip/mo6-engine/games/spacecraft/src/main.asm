* =============================================================================
* SPACECRAFT pour Thomson MO6, sur le moteur MO6 : jeu complet (16 etapes)
* ou demo jouable (4 etapes) si DEMO_DISK est defini (lwasm -D DEMO_DISK)
* (engine/ : ecran double tampon, sprites, decor en tuiles, Amadeus, MEA8000)
*
* Disquette : programme piste 0 (secteur 2...), page de donnees piste 4,
* image titre piste 8, image titre sans PRESS START piste 12.
* =============================================================================
        INCLUDE "mo6.inc"
        INCLUDE "data.sym"
        INCLUDE "extra.sym"

VS_Y0    equ  16                       ; aire de jeu entre les bandeaux
VS_Y1    equ  184
PLAY_Y0  equ  VS_Y0
PLAY_Y1  equ  VS_Y1

PAGE_TITLE equ 4
PAGE_TOFF  equ 6
PAGE_EXTRA equ 7                       ; ecran d'information et histoire (RLE)

M_READY  equ  1
M_PLAY   equ  2
M_OVER   equ  3
M_CLEAR  equ  4                        ; fin : generique
 IFDEF DEMO_DISK
NB_LEVELS equ 4
 ELSE
NB_LEVELS equ 16
 ENDC
CREDITS_END equ 200+292+24             ; generique : derniere ligne sortie

NB_EN    equ  8                        ; ennemis
EN_SZ    equ  12
ES_SZ    equ  7
MT_SZ    equ  5
NB_SH    equ  10                       ; tirs du joueur
SH_SZ    equ  6
ER_AREA  equ  $0000                    ; listes d'effacement en page 0
ER_MAX   equ  250                      ; (2 x 1000 octets)
STAR_AREA equ $0800                    ; ($0800-$0E3F, apres les listes)
VS_STARS equ  400
NB_ES    equ  6                        ; tirs ennemis
NB_EX    equ  6                        ; explosions
NB_BN    equ  2                        ; capsules
NB_MT    equ  3                        ; meteorites

        org   $2300

Start
        lds   #$2300
        jsr   HwInit
        jsr   SoundMute                ; la carte son peut encore jouer
        ldx   #PalBlack
        jsr   SetPal
        lda   #3                       ; ecran noir pendant le chargement
        jsr   ClearPage
        lda   #3
        jsr   ShowPage
        ldx   #DATA_ADR                ; donnees -> page 5 ($B000, en ecriture)
        lda   #4
        jsr   LoadBlock
        lda   #PAGE_TITLE              ; image titre -> page 4
        ldb   #8
        jsr   LoadPage
        lda   #PAGE_TOFF               ; titre sans PRESS START -> page 6
        ldb   #12
        jsr   LoadPage
        lda   #PAGE_EXTRA+$60          ; ecrans d'information et d'histoire -> page 7
        sta   CART_REG
        ldx   #DATA_ADR
        lda   #16
        jsr   LoadBlock
        lda   #DATA_PAGE+$20           ; page de donnees en lecture seule
        sta   CART_REG
        jsr   SoundInit
        jsr   VoiceInit
        clr   hiscore
        clr   hiscore+1
        clr   hiscore+2

* =============================================================================
* Ecran titre (comme sur TO8 : image, PRESS START qui clignote, option voix)
* =============================================================================
Title
        tst   demo                     ; fin de demo : option des voix rendue
        beq   >
        lda   demo_vm
        sta   vo_mute
!       clr   demo
        jsr   MusicStop
        ldx   #PalBlack
        jsr   SetPal
        lda   #PAGE_TITLE
        ldb   #3
        jsr   CopyPage
        lda   #3
        sta   RAM_REG
        lda   #1
        sta   no_er
        jsr   DrawVoice
        lda   #2                       ; ecran d'information en page 2
        sta   RAM_REG
        ldu   #InfoData
        jsr   UnrleExtra
        jsr   WaitFrame
        lda   #3
        jsr   ShowPage
        ldx   #PalTitle
        jsr   SetPal
        ldx   #SongStage
        jsr   MusicPlay
        clr   t_rel
        lda   #25
        sta   t_blink
        clr   t_off
        clr   t_ph
        ldd   #500                     ; 10 s de titre, 10 s d'informations, demo
        std   t_cnt
@wait   jsr   WaitFrame
        ldd   t_cnt
        subd  #1
        std   t_cnt
        bne   @blk
        tst   t_ph
        lbne  StartDemo
        inc   t_ph                     ; -> informations
        ldd   #500
        std   t_cnt
        lda   #2
        jsr   ShowPage
        ldx   #PalGame
        jsr   SetPal
@blk    tst   t_ph
        bne   @in
        dec   t_blink                  ; PRESS START clignote
        bne   @in
        lda   #25
        sta   t_blink
        com   t_off
        lda   #PAGE_TITLE
        tst   t_off
        beq   >
        lda   #PAGE_TOFF
!       jsr   BlinkBand
@in     jsr   ReadInput
        lda   in_dir                   ; haut / bas ou V : voix oui / non
        anda  #J_UP|J_DOWN
        pshs  a
        ldb   #$54                     ; touche V (ligne 2, colonne 5)
        jsr   KeyDown
        ora   ,s+
        beq   @nov
        tst   t_vk
        bne   @fire
        inc   t_vk
        com   vo_mute
        lda   #3
        sta   RAM_REG
        jsr   DrawVoice
        clr   t_ph                     ; retour au titre, attente relancee
        ldd   #500
        std   t_cnt
        lda   #3
        jsr   ShowPage
        ldx   #PalTitle
        jsr   SetPal
        bra   @fire
@nov    clr   t_vk
@fire   lda   in_fire
        bne   @f
        inc   t_rel                    ; tir relache au moins une fois
        lbra  @wait
@f      tst   t_rel
        lbeq  @wait

* --- histoire de Stan (tir ou 30 s pour passer), avant chaque partie ---
Story
        ldx   #PalBlack
        jsr   SetPal
        lda   #2
        sta   RAM_REG
        ldu   #StoryData
        jsr   UnrleExtra
        lda   #2
        jsr   ShowPage
        ldx   #PalStory
        jsr   SetPal
        clr   t_rel
        ldd   #1500
        std   t_cnt
@w      jsr   WaitFrame
        ldd   t_cnt
        subd  #1
        std   t_cnt
        lbeq  NewGame
        jsr   ReadInput
        lda   in_fire
        bne   >
        inc   t_rel
        bra   @w
!       tst   t_rel
        beq   @w
        lbra  NewGame

StartDemo
        lda   #1
        sta   demo
        lbra  NewGame

* LoadPage : A = page (vue en $6000-$9FFF), B = piste : 64 secteurs (16 Ko)
LoadPage
        sta   RAM_REG
        tfr   b,a
        ldx   #$6000
* LoadBlock : X = adresse, A = piste : 64 secteurs (16 Ko)
LoadBlock
        ldb   #1
        ldy   #64
        jmp   LoadSectors

* UnrleExtra : U = image RLE de la page des ecrans (page 7, vue en $B000),
* decompressee dans la page vue en $6000 (RAM A puis RAM B)
UnrleExtra
        lda   #PAGE_EXTRA+$20
        sta   CART_REG
        ldx   #SCR
        ldy   #SCR+8000
        jsr   Unrle
        ldx   #SCR-$2000
        ldy   #SCR-$2000+8000
        jsr   Unrle
        lda   #DATA_PAGE+$20
        sta   CART_REG
        rts

DrawVoice
        ldx   #SCR+2*40+14
        ldu   #TxtVoiceOn
        tst   vo_mute
        beq   >
        ldu   #TxtVoiceOff
!       lda   #PalTitle_WHITE
        jmp   DrawText

* BlinkBand : A = page source -> lignes 160-199 de la page 3 (tampon $0000)
BlinkBand
        sta   RAM_REG
        ldu   #$6000+160*40
        ldx   #0
        ldy   #1600
        bsr   @cp
        ldu   #$8000+160*40
        ldy   #1600
        bsr   @cp
        lda   #3
        sta   RAM_REG
        ldu   #0
        ldx   #$6000+160*40
        ldy   #1600
        bsr   @cp
        ldx   #$8000+160*40
        ldy   #1600
@cp     ldd   ,u++
        std   ,x++
        tfr   x,d                      ; la musique continue pendant la copie
        andb  #$3F
        bne   >
        jsr   Tick
!       leay  -2,y
        bne   @cp
        jmp   Tick

* =============================================================================
* Partie
* =============================================================================
NewGame
        jsr   MusicStop
        ldx   #PalBlack
        jsr   SetPal
        jsr   ScreenInit
        lda   #2
        jsr   DrawBands
        lda   #3
        jsr   DrawBands
        ldx   #Vars                    ; variables de jeu a zero
@z      clr   ,x+
        cmpx  #VarsEnd
        blo   @z
        lda   #3
        sta   lives
        lda   #1
        sta   weapon
        lda   #76
        sta   ship_x
        lda   #PLAY_Y1-Ship_H-4
        sta   ship_y
        lda   #2
        sta   hud_dirty
        lda   #75                      ; premiere meteorite apres 3 s
        sta   met_t
        lda   #60                      ; premiere escadrille apres 2,4 s
        sta   sq_timer
        lda   #60
        sta   fire_t
        ldx   #Lv1_Rows                ; decor : bas de la carte
        ldy   #Lv1_Tiles
        ldd   #Lv1_PIXH
        jsr   VsInit
        ldd   #Lv1_PIXH-200
        std   vs_cam
        lda   frame
        sta   g_last
        lda   #2
        sta   g_acc
        jsr   StageColors
        ldx   #PalGame
        jsr   SetPal
        ldd   #750
        std   demo_t
 IFDEF FANTEST
        ldd   #$4000                   ; (essais : tir en eventail d'office)
        std   power
 ENDC
        lda   vo_mute                  ; pas de voix pendant la demo
        sta   demo_vm
        tst   demo
        beq   >
        lda   #1
        sta   vo_mute
!       lda   #M_READY
        ldb   #80
        jsr   SetMode
        ldx   #SongStage
        jsr   MusicPlay
        lda   #VOX_READY
        jsr   VoicePlay

GameLoop
        jsr   ScreenBegin
        jsr   VsErase
        jsr   BandRefresh
        tst   hud_dirty
        beq   >
        dec   hud_dirty
        jsr   DrawHud
!       jsr   ReadInput
        tst   demo                     ; demo : le tir ramene au titre,
        beq   >                        ; le vaisseau joue seul
        tst   in_fire
        beq   @pil
        inc   quit
@pil    jsr   DemoPilot
!
* la logique avance d'un pas toutes les 2 images (50 Hz), quelle que soit la
* vitesse d'affichage : le jeu garde le meme rythme que sur TO8
        lda   frame
        suba  g_last
        adda  g_acc
        cmpa  #8
        bls   >
        lda   #8
!       sta   g_acc
        lda   frame
        sta   g_last
@step   lda   g_acc
        cmpa  #2
        blo   @draw
        suba  #2
        sta   g_acc
        jsr   Logic
        jsr   Collide
        ldb   #96                      ; decor : 0,375 ligne par pas
        jsr   VsMove
        bra   @step
@draw
 IFNDEF NOVS
        jsr   VsDraw
 ENDC
        jsr   DrawAll
        jsr   DrawModeText
        lda   #2                       ; 25 images par seconde au plus
        jsr   ScreenEnd
 IFDEF SHOWFPS
        lda   frame                    ; images par tour de boucle (essais)
        suba  dbg_fr
        ldb   frame
        stb   dbg_fr
        cmpa  #9
        bls   >
        lda   #9
!       inc   no_er
        ldx   #SCR+5*40+20
        jsr   DrawDigit
        clr   no_er
 ENDC
        tst   quit
        beq   GameLoop
        jmp   Title

* DrawBands : A = page ; bandeaux de cockpit en haut et en bas (jamais effaces)
DrawBands
        sta   RAM_REG
        ldu   #BandTop
        ldx   #SCR
        bsr   @band
        ldu   #BandBot
        ldx   #SCR+184*40
@band   ldy   #640                     ; RAM A
        pshs  x
@a      lda   ,u+
        sta   ,x+
        leay  -1,y
        bne   @a
        puls  x
        leax  -$2000,x                 ; RAM B
        ldy   #640
@b      lda   ,u+
        sta   ,x+
        leay  -1,y
        bne   @b
        jmp   Tick

* BandRefresh : les bandeaux sont recopies petit a petit dans le tampon de
* dessin (1/8 par image : 320 octets), si jamais un dessin les avait abimes ;
* le score, les vies et l'etape sont redessines a chaque image
BandRefresh
        lda   band_k
        inca
        anda  #7
        sta   band_k
        ldx   #BandRefTab
        lsla
        lsla
        ldu   a,x                      ; source
        leax  2,x
        ldx   a,x                      ; destination
        ldy   #320
@c      ldd   ,u++
        std   ,x++
        leay  -2,y
        bne   @c
        jsr   Tick
        tst   hud_dirty                ; score, vies, etape redessines par-dessus
        bne   >
        inc   hud_dirty
!       rts
BandRefTab                             ; source, destination (320 octets en 2 x 160)
        fdb   BandTop,SCR,BandTop+320,SCR+320
        fdb   BandTop+640,SCR-$2000,BandTop+960,SCR-$2000+320
        fdb   BandBot,SCR+184*40,BandBot+320,SCR+184*40+320
        fdb   BandBot+640,SCR-$2000+184*40,BandBot+960,SCR-$2000+184*40+320

* DrawHud : score (bandeau du haut), vies et etape (bandeau du bas)
DrawHud
        inc   no_er
        ldx   #SCR+5*40+2
        ldu   #score
        ldb   #3
        jsr   DrawBCD
        ldx   #SCR+189*40+2
        lda   #10
        jsr   DrawDigit
        lda   lives
        jsr   DrawDigit
        ldx   #SCR+189*40+35           ; etape 01..16
        lda   level
        inca
        clrb
@dz     cmpa  #10
        blo   >
        suba  #10
        incb
        bra   @dz
!       pshs  a
        tfr   b,a
        jsr   DrawDigit
        puls  a
        jsr   DrawDigit
        clr   no_er
        rts

SetMode                                ; A = mode, B = duree (images de jeu)
        sta   mode
        stb   mode_t
        rts

Sfx     jmp   SfxPlay                  ; A = bruitage

* =============================================================================
* Logique (une fois par image de jeu)
* =============================================================================
Logic
        inc   tick
        tst   demo                     ; demo : 30 s, vies gardees
        beq   >
        lda   #3
        sta   lives
        ldd   demo_t
        subd  #1
        std   demo_t
        bne   >
        inc   quit
!
        tst   combo_t
        beq   >
        dec   combo_t
!       tst   cb_show
        beq   >
        dec   cb_show
!       lda   mode
        cmpa  #M_READY
        bne   @m2
        dec   mode_t
        bne   @ship
        lda   #M_PLAY
        jsr   SetMode
        bra   @ship
@m2     cmpa  #M_PLAY
        beq   @play
        cmpa  #M_CLEAR
        bne   @mo
        ldd   cr_pos                   ; generique : une ligne par pas (25/s)
        addd  #1
        std   cr_pos
        cmpd  #CREDITS_END             ; (jusqu'au bout, comme sur TO8)
        bhs   @q
        bra   @obj
@mo     dec   mode_t                   ; game over : retour au titre
        beq   @q
        lda   mode_t                   ; apres 2 s, le tir fait passer
        cmpa  #150
        bhs   @obj
        tst   in_fire
        beq   @obj
@q      inc   quit
@obj    jsr   MoveShots
        jsr   MoveEnemies
        jsr   MoveEShots
        jsr   MoveMeteors
        jsr   MoveBonus
        jsr   MoveBoss
        jmp   MoveExpl
@play   jsr   Squads
        jsr   FireTick
        jsr   MeteorSpawn
@ship   jsr   MoveShip
        bra   @obj

* --- vaisseau ---
MoveShip
        tst   lives
        bne   >
        rts
!       lda   in_dir
        ldb   ship_x
        bita  #J_LEFT
        beq   >
        subb  #4
        bcc   >
        clrb
!       bita  #J_RIGHT
        beq   >
        addb  #4
        cmpb  #160-Ship_W
        bls   >
        ldb   #160-Ship_W
!       stb   ship_x
        ldb   ship_y
        bita  #J_UP
        beq   >
        subb  #6
        cmpb  #PLAY_Y0+40
        bhs   >
        ldb   #PLAY_Y0+40
!       bita  #J_DOWN
        beq   >
        addb  #6
        cmpb  #PLAY_Y1-Ship_H
        bls   >
        ldb   #PLAY_Y1-Ship_H
!       stb   ship_y
        tst   ship_inv
        beq   >
        dec   ship_inv
!       tst   fire_cd
        beq   >
        dec   fire_cd
        rts
!       lda   mode
        cmpa  #M_PLAY
        bne   @rts
        tst   in_fire
        beq   @rts
        lda   #4
        sta   fire_cd
        ldx   #FirePat5                ; capsule jaune : 5 tirs en eventail
        ldd   power
        bne   @pat
        ldx   #FirePat1                ; sinon selon le nombre de canons
        lda   weapon
        deca
        beq   @pat
        ldx   #FirePat2
        deca
        beq   @pat
        ldx   #FirePat3
@pat    clra                           ; deja assez de tirs a l'ecran ?
        ldy   #Shots
@cnt    tst   ,y
        beq   >
        inca
!       leay  SH_SZ,y
        cmpy  #Shots+SH_SZ*NB_SH
        blo   @cnt
        cmpa  1,x
        bhs   @rts
        ldb   ,x
        stb   tmp
        leax  2,x
@one    ldy   #Shots
@find   tst   ,y
        beq   @got
        leay  SH_SZ,y
        cmpy  #Shots+SH_SZ*NB_SH
        blo   @find
        bra   @snd
@got    lda   #1
        sta   ,y
        lda   ship_x
        adda  ,x
        sta   1,y
        lda   ship_y
        suba  #4
        sta   2,y
        clr   3,y
        ldd   1,x
        std   4,y
        leax  3,x
        dec   tmp
        bne   @one
@snd    lda   #SFX_SHOT
        jsr   Sfx
@rts    rts
* motifs (comme sur TO8) : nombre, tirs max a l'ecran, puis x, vitesse x (8.8)
FirePat1 fcb  1,2,4
         fdb  0
FirePat2 fcb  2,3,0
         fdb  0
         fcb  6
         fdb  0
FirePat3 fcb  3,5,4
         fdb  0
         fcb  0
         fdb  -$0140
         fcb  8
         fdb  $0140
FirePat5 fcb  5,6,4
         fdb  0
         fcb  2
         fdb  -$0120
         fcb  6
         fdb  $0120
         fcb  0
         fdb  -$0260
         fcb  8
         fdb  $0260

MoveShots
        ldy   #Shots
@l      tst   ,y
        beq   @n
        lda   2,y
        suba  #10
        bcs   @out
        cmpa  #PLAY_Y0
        blo   @out
        sta   2,y
        lda   1,y                      ; x (8.8) : tirs en eventail
        ldb   3,y
        addd  4,y
        cmpa  #160-Shot_W
        bhi   @out
        sta   1,y
        stb   3,y
        bra   @n
@out    clr   ,y
@n      leay  SH_SZ,y
        cmpy  #Shots+SH_SZ*NB_SH
        blo   @l
        tst   power                    ; le tir en eventail s'use
        bne   >
        tst   power+1
        beq   @rts
!       ldd   power
        subd  #1
        std   power
@rts    rts

* --- escadrilles, comme sur TO8 : toutes les 1,6 a 3,3 s, 1 a 3 vaisseaux
*     cote a cote (un bomber vient seul), seulement s'il y en a moins de 4 a
*     l'ecran. Ils descendent avec le decor en ondulant doucement et sortent
*     par le bas. Apres 18 escadrilles et quand tout est passe : le boss.
 IFDEF QUICK
SQUADS  equ   1                        ; (essais : boss tout de suite)
 ELSE
SQUADS  equ   18
 ENDC
Squads
        tst   boss_on
        lbne  @rts
        dec   sq_timer
        lbne  @rts
        jsr   Rand
        lda   #42
        mul
        adda  #40
        ldb   level                    ; plus d'ennemis a chaque etape :
        cmpb  #3                       ; 4 par etape jusqu'a la 4e,
        bls   >                        ; puis 2 (comme le TO8, borne)
        addb  #3
        lsrb
!       lslb
        lslb
        pshs  b
        suba  ,s+
        bcs   >
        cmpa  #12
        bhs   @st
!       lda   #12
@st     sta   sq_timer
        lda   sq_count
        cmpa  #SQUADS
        blo   @more
        jsr   CountEn
        tsta
        lbne  @rts
        lda   #1                       ; le boss arrive
        sta   boss_on
        ldx   #SongBoss
        jsr   MusicPlay
        lda   #VOX_WARNING
        jsr   VoicePlay
        lda   #75
        sta   warn_t
        jmp   BossInit
@more   jsr   CountEn                  ; debut de niveau : 2 ennemis au plus
        ldb   sq_count                 ; a l'ecran pendant 6 escadrilles
        cmpb  #6
        bhs   >
        cmpa  #2
        bhs   @rts
!       cmpa  #4
        bhs   @rts
        inc   sq_count
        jsr   Rand                     ; type : bomber, chasseur ou drone
        lda   #2
        cmpb  #60
        blo   >
        lda   #1
        cmpb  #150
        blo   >
        clra
!       sta   sq_type
        jsr   Rand                     ; 1 a 3 vaisseaux (1 ou 2 au debut)
        andb  #3
        bne   >
        incb
!       lda   sq_count
        cmpa  #6
        bhi   >
        cmpb  #2
        bls   >
        ldb   #2
!       lda   sq_type
        cmpa  #2
        bne   >
        ldb   #1
!       stb   sq_left
        ldx   #sq_alive                ; escadrille de 2-3 : STRIKE possible
        lda   sq_count
        cmpb  #2
        bhs   >
        clrb
!       stb   a,x
        jsr   Rand                     ; colonne de depart, loin des bords
        lda   #96
        mul
        adda  #26
        anda  #$FE
        sta   sq_x0
        jsr   Rand
        stb   sq_dir
@spawn  ldx   #Enemies
@f      tst   ,x
        beq   @new
        leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @f
@rts    rts
@new    lda   #1
        sta   ,x
        lda   sq_type
        sta   1,x
        ldb   #1                       ; bomber : 3 impacts
        cmpa  #2
        bne   >
        ldb   #3
!       stb   7,x
        lda   sq_x0
        sta   2,x
        sta   3,x
        lda   #PLAY_Y0
        sta   4,x
        clr   5,x
        lda   sq_left                  ; phases decalees dans le groupe
        lsla
        lsla
        lsla
        sta   6,x
        clr   8,x
        lda   sq_dir
        sta   9,x
        clr   10,x
        lda   sq_count
        sta   11,x
        lda   sq_x0                    ; suivant : 18 points a droite
        adda  #18
        cmpa  #140
        blo   >
        suba  #54
!       sta   sq_x0
        dec   sq_left
        bne   @spawn
        rts

CountEn                                ; A = ennemis a l'ecran
        clra
        ldx   #Enemies
@c      tst   ,x
        beq   >
        inca
!       leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @c
        rts

* ennemi : 0 actif, 1 type (0 drone, 1 chasseur, 2 bomber), 2 x de base,
* 3 x, 4-5 y (8.8), 6 phase, 7 vie, 8 eclair, 9 sens, 10 etat (0 traverse,
* 1 pique), 11 escadrille
EnSpr   fdb   SprSmall,SprEsc,SprChef
EnW     fcb   Small_W,Esc_W,Chef_W
EnH     fcb   Small_H,Esc_H,Chef_H
EnPts   fdb   $0050,$0080,$0150
TravSpeed fdb $0120,$00E0,$00A0        ; lignes par pas (8.8) : ~28, 22, 16 lignes/s
DIVE_VY equ   $0160                    ; pique : ~34 lignes/s

MoveEnemies
        ldx   #Enemies
@l      tst   ,x
        lbeq  @n
        ldb   1,x
        ldu   #EnW
        lda   b,u
        sta   tmp2
        ldd   #DIVE_VY
        tst   10,x
        bne   >
        ldb   1,x
        lslb
        ldu   #TravSpeed
        ldd   b,u
!       addd  4,x                      ; descente
        std   4,x
        ldb   1,x
        ldu   #EnH
        adda  b,u
        bcs   @out
        cmpa  #PLAY_Y1
        bls   @in
@out    clr   ,x
        lbra  @n
@in     lda   6,x                      ; ondulation
        adda  #2
        sta   6,x
        tst   10,x
        bne   >
        lsra                           ; traversee : lente
!       lsra
        anda  #63
        ldu   #SinTab
        ldb   a,u
        tst   9,x
        bpl   >
        negb
!       sex
        addb  2,x
        adca  #0
        beq   >
        clrb
!       lda   #160
        suba  tmp2
        pshs  a
        cmpb  ,s+
        bls   >
        tfr   a,b
!       andb  #$FE
        stb   3,x
        tst   8,x
        beq   @n
        dec   8,x
@n      jsr   Tick
        leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        lblo  @l
        rts

* --- tirs ennemis, comme sur TO8 : toutes les 2,4 s un ennemi bien au-dessus
*     du joueur tire une boule visee (le boss : 3 en eventail) ---
FireTick
        dec   fire_t
        lbne  @rts
        lda   level                    ; tirs plus frequents a chaque etape
        ldb   #4
        mul
        negb
        addb  #60
        cmpb  #18                      ; (au plus vite : 18 pas, TO8 : 10/34)
        bge   >
        ldb   #18
!       stb   fire_t
        clra                           ; deja 6 tirs a l'ecran ?
        ldx   #EShots
@c      tst   ,x
        beq   >
        inca
!       leax  ES_SZ,x
        cmpx  #EShots+ES_SZ*NB_ES
        blo   @c
        cmpa  #6
        bhs   @rts
        lda   boss_on
        cmpa  #1
        bne   @dr
        tst   boss_warp
        bne   @dr
        lda   boss_x
        adda  #7
        ldb   boss_y
        addb  #Boss_H-6
        ldu   #-$0100
        jsr   EShot
        lda   boss_x
        adda  #7
        ldb   boss_y
        addb  #Boss_H-6
        ldu   #0
        jsr   EShot
        lda   boss_x
        adda  #7
        ldb   boss_y
        addb  #Boss_H-6
        ldu   #$0100
        jmp   EShot
@dr     jsr   Rand
        andb  #3
        stb   tmp
        ldx   #Enemies
@l      tst   ,x
        beq   @n
        lda   4,x                      ; seulement s'il est au-dessus du joueur
        adda  #30
        bcs   @n
        cmpa  ship_y
        bhs   @n
        tst   tmp
        beq   @fire
        dec   tmp
@n      leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @l
@rts    rts
@fire   ldb   1,x
        ldu   #EnW
        lda   b,u
        lsra
        adda  3,x
        suba  #2
        ldu   #EnH
        ldb   b,u
        addb  4,x
        ldu   #0
        jmp   EShot

* EShot : A = x, B = y, U = ecart horizontal (8.8 par pas) ; vise le joueur
EShot
        cmpb  #PLAY_Y1-EShot_H
        bhi   @rts
        pshs  x
        anda  #$FE
        ldx   #EShots
@f      tst   ,x
        beq   @got
        leax  ES_SZ,x
        cmpx  #EShots+ES_SZ*NB_ES
        blo   @f
        puls  x,pc
@got    sta   1,x
        clr   2,x
        stb   3,x
        clr   4,x
        stu   5,x
        lda   ship_x                   ; vitesse x : (x joueur - x tir) * 12
        adda  #3
        suba  1,x
        bcc   @pos
        nega
        cmpa  #40
        bls   >
        lda   #40
!       ldb   #12
        mul
        coma
        comb
        addd  #1
        bra   @v
@pos    cmpa  #40
        bls   >
        lda   #40
!       ldb   #12
        mul
@v      addd  5,x
        std   5,x
        lda   #1
        sta   ,x
        puls  x,pc
@rts    rts

* tir ennemi : 0 actif, 1-2 x (8.8), 3-4 y (8.8), 5-6 vitesse x (8.8)
EShotVY equ   $01C0                    ; ~45 lignes/s
MoveEShots
        ldx   #EShots
@l      tst   ,x
        beq   @n
        ldd   3,x
        addd  #EShotVY
        cmpa  #PLAY_Y1-EShot_H
        bhi   @out
        std   3,x
        ldd   1,x
        addd  5,x
        cmpa  #160-EShot_W
        bhi   @out
        std   1,x
        bra   @n
@out    clr   ,x
@n      leax  ES_SZ,x
        cmpx  #EShots+ES_SZ*NB_ES
        blo   @l
        rts

* --- meteorites : 0 actif, 1 x, 2-3 y (8.8), 4 taille (0-2) ---
MetSpr  fdb   SprMet1,SprMet2,SprMet3
MetW    fcb   Met1_W,Met2_W,Met3_W
MetH    fcb   Met1_H,Met2_H,Met3_H
MeteorSpawn
        dec   met_t
        bne   @rts
        lda   #16
        sta   met_t
        clra                           ; debut de niveau : 1 seule meteorite
        ldx   #Meteors
@c      tst   ,x
        beq   >
        inca
!       leax  MT_SZ,x
        cmpx  #Meteors+MT_SZ*NB_MT
        blo   @c
        ldb   sq_count
        cmpb  #6
        bhs   >
        tsta
        bne   @rts
!       ldx   #Meteors
@f      tst   ,x
        beq   @got
        leax  MT_SZ,x
        cmpx  #Meteors+MT_SZ*NB_MT
        blo   @f
@rts    rts
@got    jsr   Rand
        lda   #146
        mul
        adda  #2
        anda  #$FE
        sta   1,x
        lda   #PLAY_Y0
        sta   2,x
        clr   3,x
        jsr   Rand
        andb  #3
        cmpb  #2
        bls   >
        clrb
!       stb   4,x
        inc   ,x
        rts
MoveMeteors
        ldx   #Meteors
@l      tst   ,x
        beq   @n
        ldb   4,x
        ldu   #MetH
        lda   b,u
        nega
        adda  #PLAY_Y1
        sta   tmp
        ldd   2,x
        addd  #$0180                   ; ~37 lignes/s
        cmpa  tmp
        bls   >
        clr   ,x
        bra   @n
!       std   2,x
@n      leax  MT_SZ,x
        cmpx  #Meteors+MT_SZ*NB_MT
        blo   @l
        rts

* --- capsules : 0 actif, 1 type (0 vie, 1 canon), 2 x, 3 y ---
DropBonus
        ldu   #Bonus
@f      tst   ,u
        beq   @got
        leau  4,u
        cmpu  #Bonus+4*NB_BN
        blo   @f
        rts
@got    anda  #$FE
        sta   2,u
        stb   3,u
        lda   bn_cnt                   ; vie, canon, tir multiple, canon (TO8)
        inc   bn_cnt
        anda  #3
        pshs  x
        ldx   #BonusOrder
        lda   a,x
        puls  x
        sta   1,u
        lda   #1
        sta   ,u
        rts
MoveBonus
        ldx   #Bonus
@l      tst   ,x
        beq   @n
        lda   3,x
        adda  #2
        cmpa  #PLAY_Y1-Life_H
        bls   >
        clr   ,x
        bra   @n
!       sta   3,x
@n      leax  4,x
        cmpx  #Bonus+4*NB_BN
        blo   @l
        rts

* --- explosions : 0 actif, 1 x, 2 y, 3 compteur ---
AddExpl
        pshs  x
        ldx   #Expl
@f      tst   ,x
        beq   @got
        leax  4,x
        cmpx  #Expl+4*NB_EX
        blo   @f
        puls  x,pc
@got    anda  #$FE
        cmpa  #160-Expl1_W
        bls   >
        lda   #160-Expl1_W
!       cmpb  #PLAY_Y1-Expl1_H
        bls   >
        ldb   #PLAY_Y1-Expl1_H
!       cmpb  #PLAY_Y0
        bhs   >
        ldb   #PLAY_Y0
!       sta   1,x
        stb   2,x
        clr   3,x
        inc   ,x
        puls  x,pc
MoveExpl
        ldx   #Expl
@l      tst   ,x
        beq   @n
        inc   3,x
        lda   3,x
        cmpa  #9
        blo   @n
        clr   ,x
@n      leax  4,x
        cmpx  #Expl+4*NB_EX
        blo   @l
        rts

* --- boss, comme sur TO8 : apparait en clignotant (invulnerable), se balance
*     de gauche a droite et lache des drones qui piquent ---
BossInit
        lda   #71
        sta   boss_x
        lda   #PLAY_Y0+22
        sta   boss_y
        lda   level                    ; plus resistant a chaque etape
        lsla
        adda  #24
 IFDEF QUICK
        lda   #2
 ENDC
        sta   boss_hp
        clr   boss_fl
        clr   boss_t
        lda   #70
        sta   boss_warp
        sta   boss_launch
        rts
MoveBoss
        lda   boss_on
        cmpa  #1
        bne   @rts
        lda   #PLAY_Y0+22              ; hauteur fixe (garde)
        sta   boss_y
        tst   warn_t
        beq   >
        dec   warn_t
!       tst   boss_fl
        beq   >
        dec   boss_fl
!       lda   boss_t                   ; balancement lent
        adda  #2
        sta   boss_t
        lsra
        anda  #63
        ldu   #BossSin
        lda   a,u
        adda  #80-Boss_W/2-1
        anda  #$FE
        sta   boss_x
        tst   boss_warp
        beq   >
        dec   boss_warp
        rts
!       lda   mode
        cmpa  #M_PLAY
        bne   @rts
        dec   boss_launch              ; lache un drone qui pique
        bne   @rts
        lda   #50
        sta   boss_launch
        jsr   CountEn
        cmpa  #6
        bhs   @rts
        ldx   #Enemies
@f      tst   ,x
        beq   @new
        leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @f
@rts    rts
@new    lda   #1
        sta   ,x
        clr   1,x                      ; petit drone
        sta   7,x                      ; 1 point de vie
        sta   10,x                     ; etat : pique
        lda   boss_x
        adda  #4
        sta   2,x
        sta   3,x
        lda   boss_y
        adda  #12
        sta   4,x
        clr   5,x
        clr   6,x
        clr   8,x
        clr   11,x                     ; pas d'escadrille
        lda   tick
        sta   9,x
        rts

* =============================================================================
* Collisions
* =============================================================================
Overlap
        lda   c_ax
        adda  c_aw
        cmpa  c_bx
        bls   @no
        lda   c_bx
        adda  c_bw
        cmpa  c_ax
        bls   @no
        lda   c_ay
        adda  c_ah
        cmpa  c_by
        bls   @no
        lda   c_by
        adda  c_bh
        cmpa  c_ay
        bls   @no
        orcc  #1
        rts
@no     andcc #$FE
        rts

Collide
        lda   mode
        cmpa  #M_PLAY
        beq   >
        rts
!       lda   #Shot_W
        sta   c_aw
        lda   #Shot_H
        sta   c_ah
        ldy   #Shots
@s      jsr   Tick
        tst   ,y
        lbeq  @sn
        lda   1,y
        sta   c_ax
        lda   2,y
        sta   c_ay
        ldx   #Enemies
@e      tst   ,x
        beq   @en
        lda   3,x
        sta   c_bx
        lda   4,x
        sta   c_by
        ldb   1,x
        ldu   #EnW
        lda   b,u
        sta   c_bw
        ldu   #EnH
        lda   b,u
        sta   c_bh
        jsr   Overlap
        bcc   @en
        clr   ,y
        lda   #4
        sta   8,x
        dec   7,x
        lbne  @sn
        clr   ,x                       ; detruit
        ldb   1,x
        lslb
        ldu   #EnPts
        ldd   b,u
        jsr   AddScore
        lda   3,x
        ldb   4,x
        jsr   AddExpl
        lda   #SFX_EXPLO
        jsr   Sfx
        jsr   KillBonus
        lda   1,x                      ; capsule : bomber toujours, sinon 1 sur 12
        cmpa  #2
        beq   >
        jsr   Rand
        cmpb  #22
        lbhs  @sn
!       lda   3,x
        ldb   4,x
        jsr   DropBonus
        lbra  @sn
@en     leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @e
        ldx   #Meteors
@m      tst   ,x
        beq   @mn
        lda   1,x
        sta   c_bx
        lda   2,x
        sta   c_by
        ldb   4,x
        ldu   #MetW
        lda   b,u
        sta   c_bw
        ldu   #MetH
        lda   b,u
        sta   c_bh
        jsr   Overlap
        bcc   @mn
        clr   ,y
        clr   ,x
        ldd   #$0020
        jsr   AddScore
        lda   1,x
        ldb   2,x
        jsr   AddExpl
        lda   #SFX_EXPLO
        jsr   Sfx
        bra   @sn
@mn     leax  MT_SZ,x
        cmpx  #Meteors+MT_SZ*NB_MT
        blo   @m
        lda   boss_on
        cmpa  #1
        bne   @sn
        tst   boss_warp
        bne   @sn
        lda   boss_x
        sta   c_bx
        lda   boss_y
        sta   c_by
        lda   #Boss_W
        sta   c_bw
        lda   #Boss_H
        sta   c_bh
        jsr   Overlap
        bcc   @sn
        clr   ,y
        lda   #4
        sta   boss_fl
        lda   #SFX_TICK
        jsr   Sfx
        dec   boss_hp
        bne   @sn
        jsr   BossDead
@sn     leay  SH_SZ,y
        cmpy  #Shots+SH_SZ*NB_SH
        lblo  @s

        tst   lives
        bne   >
        rts
!       jsr   Tick                     ; comme sur TO8 : touche si les centres
        lda   #7                       ; sont a moins de 8 points en x et 9
        jsr   ShipBox                  ; lignes en y
        ldx   #Bonus
@b      tst   ,x
        beq   @bn
        lda   2,x
        sta   c_bx
        lda   3,x
        sta   c_by
        lda   #Life_W
        sta   c_bw
        lda   #Life_H
        sta   c_bh
        jsr   ToCenter
        jsr   Overlap
        bcc   @bn
        clr   ,x
        lda   #SFX_BONUS
        jsr   Sfx
        tst   1,x
        bne   @can
        lda   lives
        cmpa  #9
        bhs   >
        inc   lives
        lda   #2
        sta   hud_dirty
!       lda   #VOX_LIFE
        jsr   VoicePlay
        bra   @bn
@can    lda   1,x
        cmpa  #2
        bne   @cn
        ldd   #450                     ; capsule jaune : 5 tirs pendant 18 s
        std   power
        bra   @pw
@cn     lda   weapon
        cmpa  #3
        bhs   @pw
        inc   weapon
@pw     lda   #VOX_POWER
        jsr   VoicePlay
@bn     leax  4,x
        cmpx  #Bonus+4*NB_BN
        blo   @b
        tst   ship_inv
        beq   >
        rts
!       lda   #3                       ; tirs ennemis : 4 points en x
        jsr   ShipBox
        ldx   #EShots
@t      tst   ,x
        beq   @tn
        lda   1,x
        sta   c_bx
        lda   3,x
        sta   c_by
        lda   #EShot_W
        sta   c_bw
        lda   #EShot_H
        sta   c_bh
        jsr   ToCenter
        jsr   Overlap
        bcc   @tn
        clr   ,x
        jmp   ShipHit
@tn     leax  ES_SZ,x
        cmpx  #EShots+ES_SZ*NB_ES
        blo   @t
        lda   #7
        jsr   ShipBox
        ldx   #Enemies
@e2     tst   ,x
        beq   @e2n
        lda   3,x
        sta   c_bx
        lda   4,x
        sta   c_by
        ldb   1,x
        ldu   #EnW
        lda   b,u
        sta   c_bw
        ldu   #EnH
        lda   b,u
        sta   c_bh
        jsr   ToCenter
        jsr   Overlap
        bcc   @e2n
        clr   ,x
        lda   3,x
        ldb   4,x
        jsr   AddExpl
        jmp   ShipHit
@e2n    leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @e2
        ldx   #Meteors
@m2     tst   ,x
        beq   @m2n
        lda   1,x
        sta   c_bx
        lda   2,x
        sta   c_by
        ldb   4,x
        ldu   #MetW
        lda   b,u
        sta   c_bw
        ldu   #MetH
        lda   b,u
        sta   c_bh
        jsr   ToCenter
        jsr   Overlap
        bcc   @m2n
        clr   ,x
        jmp   ShipHit
@m2n    leax  MT_SZ,x
        cmpx  #Meteors+MT_SZ*NB_MT
        blo   @m2
        rts

* KillBonus : ennemis enchaines (moins de 1,2 s) : +50 par ennemi de la serie,
* DOUBLE / TRIPLE / COMBO / SUPER COMBO ; vague entierement detruite : STRIKE
KillBonus                              ; (garde X et Y : Y = tir en cours)
        pshs  x,y
        lda   #30
        ldb   combo_t
        sta   combo_t
        lda   #1
        tstb
        beq   >
        lda   combo_n
        cmpa  #9
        bhs   >
        inca
!       sta   combo_n
        deca
        beq   @strike
        sta   tmp
!       ldd   #$0050
        jsr   AddScore
        dec   tmp
        bne   <
        lda   combo_n
        sta   cb_dig
        ldb   #VOX_COMBO
        cmpa  #4
        blo   >
        beq   @cv
        ldb   #VOX_SUPER
        bra   @cv
!       tfr   a,b                      ; 2 -> DOUBLE, 3 -> TRIPLE
        subb  #2
@cv     lda   #25
        sta   cb_show
        tfr   b,a
        jsr   VoicePlay
@strike ldx   ,s                       ; escadrille entierement abattue ?
        lda   11,x
        ldy   #sq_alive
        tst   a,y
        beq   @out
        dec   a,y
        bne   @out
        ldd   #$0500
        jsr   AddScore
        lda   #$FF
        sta   cb_dig
        lda   #25
        sta   cb_show
        lda   #VOX_STRIKE
        jsr   VoicePlay
@out    puls  x,y,pc

* ShipBox : boite du vaisseau autour de son centre, A = demi-largeur
ShipBox
        pshs  a
        ldb   ship_x
        addb  #Ship_W/2
        subb  ,s
        bcc   >
        clrb
!       stb   c_ax
        lsla
        inca
        sta   c_aw
        puls  a
        lda   ship_y
        adda  #Ship_H/2-8
        sta   c_ay
        lda   #17
        sta   c_ah
        rts
* ToCenter : l'objet (c_bx...) devient son point central
ToCenter
        lda   c_bw
        lsra
        adda  c_bx
        sta   c_bx
        lda   c_bh
        lsra
        adda  c_by
        sta   c_by
        lda   #1
        sta   c_bw
        sta   c_bh
        rts

ShipHit
        lda   ship_x
        ldb   ship_y
        addb  #4
        jsr   AddExpl
        lda   #SFX_HIT
        jsr   Sfx
        lda   #70                      ; 2,8 s comme sur TO8
        sta   ship_inv
        lda   #2
        sta   hud_dirty
        clr   power                    ; on perd le tir multiple
        clr   power+1
        lda   weapon
        cmpa  #1
        bls   >
        dec   weapon
!
 IFDEF GODMODE
        rts
 ENDC
        dec   lives
        bne   @rts
        jsr   HiCheck
        ldx   #SongOver
        jsr   MusicPlay
        lda   #VOX_OVER
        jsr   VoicePlay
        lda   #M_OVER
        ldb   #200
        jmp   SetMode
@rts    rts

BossDead
        lda   #2
        sta   boss_on
        ldd   #$2000
        jsr   AddScore
        lda   boss_x
        ldb   boss_y
        jsr   AddExpl
        lda   boss_x
        adda  #8
        ldb   boss_y
        addb  #10
        jsr   AddExpl
        lda   boss_x
        ldb   boss_y
        addb  #14
        jsr   AddExpl
        lda   #SFX_EXPLO
        jsr   Sfx
        lda   level                    ; derniere etape : generique
        cmpa  #NB_LEVELS-1
        lblo  NextStage
        jsr   HiCheck
        ldx   #SongWin
        jsr   MusicPlay
        lda   #VOX_COMPLETE
        jsr   VoicePlay
        ldd   #0
        std   cr_pos
        lda   #M_CLEAR
        ldb   #1
        jmp   SetMode

* DemoPilot : le vaisseau suit le premier ennemi (avec un decalage qui
* varie), tire sans arret et reste dans le bas de l'ecran (comme sur TO8)
DemoPilot
        lda   tick                     ; decalage -16..+15 qui change lentement
        anda  #$7F
        cmpa  #64
        blo   >
        eora  #$7F
!       suba  #32
        asra
        sta   tmp2
        ldx   #Enemies
@f      tst   ,x
        bne   @got
        leax  EN_SZ,x
        cmpx  #Enemies+EN_SZ*NB_EN
        blo   @f
        lda   #80                      ; personne : le boss ou le centre
        ldb   boss_on
        cmpb  #1
        bne   @tg
        lda   boss_x
        adda  #Boss_W/2
        bra   @tg
@got    ldb   1,x
        ldu   #EnW
        lda   b,u
        lsra
        adda  3,x
@tg     tfr   a,b                      ; cible + decalage, bornee a 8..152
        clra
        pshs  d
        ldb   tmp2
        sex
        addd  ,s++
        cmpd  #8
        bge   >
        ldd   #8
!       cmpd  #152
        ble   >
        ldd   #152
!       lda   ship_x
        adda  #Ship_W/2
        sta   tmp
        clra
        subb  tmp                      ; B = cible - centre du vaisseau
        bvs   @dy
        cmpb  #-3
        bge   >
        lda   #J_LEFT
        bra   @dy
!       cmpb  #3
        ble   @dy
        lda   #J_RIGHT
@dy     ldb   ship_y
        cmpb  #PLAY_Y1-Ship_H-28
        bhs   >
        ora   #J_DOWN
!       cmpb  #PLAY_Y1-Ship_H-8
        bls   >
        ora   #J_UP
!       sta   in_dir
        lda   tick
        anda  #1
        sta   in_fire
        rts

* NextStage : etape suivante (couleur des halos, annonce, musique)
NextStage
        lda   #VOX_BOSS
        jsr   VoicePlay
        inc   level
        jsr   StageColors
        ldx   #PalGame
        jsr   SetPal
        clr   boss_on
        clr   sq_count
        lda   #60
        sta   sq_timer
        lda   #2
        sta   hud_dirty
        ldx   #SongStage
        jsr   MusicPlay
        lda   #M_READY
        ldb   #80
        jmp   SetMode

* StageColors : la couleur 13 (halos des planetes) change a chaque etape
StageColors
        lda   level
        anda  #3
        lsla
        ldx   #HaloColors
        ldd   a,x
        std   PalGame+13*2
        lda   level
        inca
        ldb   #'0'
@d      cmpa  #10
        blo   >
        suba  #10
        incb
        bra   @d
!       adda  #'0'
        exg   a,b                      ; dizaines puis unites
        std   TxtStageN
        rts
HaloColors
        fdb   $2105,$1205,$4104,$1502  ; gris-bleu, mauve, turquoise, rose (TO8)

AddScore                               ; D = points (BCD)
        pshs  d
        lda   score+2
        adda  1,s
        daa
        sta   score+2
        lda   score+1
        adca  ,s
        daa
        sta   score+1
        lda   score
        adca  #0
        daa
        sta   score
        lda   #2
        sta   hud_dirty
        puls  d,pc

HiCheck
        clr   go_new
        tst   demo
        bne   @rts
        ldd   score
        cmpd  hiscore
        bhi   @new
        blo   @rts
        lda   score+2
        cmpa  hiscore+2
        bls   @rts
@new    ldd   score
        std   hiscore
        lda   score+2
        sta   hiscore+2
        inc   go_new
@rts    rts

* =============================================================================
* Affichage des objets
* =============================================================================
DrawAll
        ldy   #Meteors
@m      tst   ,y
        beq   @mn
        ldb   4,y
        lslb
        ldu   #MetSpr
        ldu   b,u
        lda   1,y
        ldb   2,y
        jsr   DrawSpr
@mn     leay  MT_SZ,y
        cmpy  #Meteors+MT_SZ*NB_MT
        blo   @m
        ldy   #Enemies
@e      tst   ,y
        beq   @en
        lda   8,y                      ; touche : clignote
        anda  #2
        bne   @en
        ldb   1,y
        lslb
        ldu   #EnSpr
        ldu   b,u
        lda   3,y
        ldb   4,y
        jsr   DrawSpr
@en     leay  EN_SZ,y
        cmpy  #Enemies+EN_SZ*NB_EN
        blo   @e
        lda   boss_on
        cmpa  #1
        bne   @nob
        lda   boss_fl
        ora   boss_warp
        anda  #2
        bne   @nob
        ldu   #SprBoss
        lda   boss_x
        ldb   boss_y
        jsr   DrawSpr
@nob    ldy   #Bonus
@b      tst   ,y
        beq   @bn
        ldb   1,y
        lslb
        ldu   #CapSpr
        ldu   b,u
        lda   2,y
        ldb   3,y
        jsr   DrawSpr
@bn     leay  4,y
        cmpy  #Bonus+4*NB_BN
        blo   @b
        ldy   #Shots
@s      tst   ,y
        beq   @sn
        ldu   #SprShot
        lda   1,y
        ldb   2,y
        jsr   DrawSpr
@sn     leay  SH_SZ,y
        cmpy  #Shots+SH_SZ*NB_SH
        blo   @s
        ldy   #EShots
@t      tst   ,y
        beq   @tn
        ldu   #SprEShot
        lda   1,y
        ldb   3,y
        jsr   DrawSpr
@tn     leay  ES_SZ,y
        cmpy  #EShots+ES_SZ*NB_ES
        blo   @t
        tst   lives
        beq   @nos
        lda   ship_inv
        anda  #2
        bne   @nos
        ldu   #SprShip                 ; flamme des reacteurs
        lda   tick
        anda  #2
        beq   >
        ldu   #SprShip2
!       lda   ship_x
        ldb   ship_y
        jsr   DrawSpr
@nos    ldy   #Expl
@x      tst   ,y
        beq   @xn
        ldu   #SprExpl1
        lda   3,y
        cmpa  #3
        blo   >
        ldu   #SprExpl2
        cmpa  #6
        blo   >
        ldu   #SprExpl3
!       lda   1,y
        ldb   2,y
        jsr   DrawSpr
@xn     leay  4,y
        cmpy  #Expl+4*NB_EX
        blo   @x
        rts

* --- textes (positions du jeu TO8) ---
DrawModeText
        tst   demo                     ; DEMO qui clignote
        beq   >
        lda   tick
        anda  #8
        beq   >
        ldx   #SCR+172*40+18
        ldu   #TxtDemo
        lda   #$44
        jsr   DrawText
!        tst   cb_show                  ; COMBO xN / STRIKE sous le bandeau
        beq   @nocb
        ldx   #SCR+34*40+15
        ldu   #TxtStrike               ; cb_dig = $FF : STRIKE
        lda   cb_dig
        bmi   >
        cmpa  #9                       ; sinon COMBO X2..X9
        bhi   @nocb
        ldu   #TxtCombo
!       lda   #$44
        jsr   DrawText
        lda   cb_dig
        bmi   @nocb
        jsr   DrawDigitE
@nocb   tst   warn_t                   ; annonce du boss
        beq   @nowarn
        ldx   #SCR+62*40+13
        ldu   #TxtAlert
        lda   #$22
        ldb   tick
        andb  #2
        beq   >
        lda   #$44
!       jsr   DrawTextBig
@nowarn lda   mode
        cmpa  #M_READY
        bne   @m3
        ldx   #SCR+92*40+16
        ldu   #TxtStage
        lda   #$55
        jmp   DrawText
@m3     cmpa  #M_OVER
        bne   @m4
        ldx   #SCR+60*40+11
        ldu   #TxtOver
        lda   #$22
        jsr   DrawTextBig
        ldx   #SCR+94*40+15
        ldu   #TxtYour
        lda   #$55
        jsr   DrawText
        ldx   #SCR+102*40+17
        ldu   #score
        jsr   DrawBCDE
        ldx   #SCR+118*40+15
        ldu   #TxtHigh
        lda   #$55
        jsr   DrawText
        ldx   #SCR+126*40+17
        ldu   #hiscore
        jsr   DrawBCDE
        tst   go_new
        beq   @rts
        lda   tick
        anda  #4
        beq   @rts
        ldx   #SCR+146*40+12
        ldu   #TxtNewHi
        lda   #$44
        jmp   DrawText
@m4     cmpa  #M_CLEAR
        bne   @rts
        jmp   DrawCredits
@rts    rts

* --- generique de fin, comme sur TO8 : textes et vaisseaux qui montent ---
* ligne d'ecran = ligne du generique + 200 - cr_pos
CrLine                                 ; D = ligne du generique -> D a l'ecran
        addd  #200
        subd  cr_pos
        rts
DrawCredits
        ldy   #CreditTable
@l      ldd   ,y
        cmpd  #$FFFF
        beq   @ships
        bsr   CrLine
        cmpd  #PLAY_Y0+2
        blt   @next
        cmpd  #PLAY_Y1-12
        bgt   @next
        lda   #40
        mul
        addd  #SCR
        addb  4,y
        adca  #0
        tfr   d,x
        lda   2,y                      ; nature
        cmpa  #2
        beq   @score
        ldu   5,y
        pshs  y
        lda   3,y
        tst   2,y
        bne   @big
        jsr   DrawText
        bra   @done
@big    jsr   DrawTextBig
@done   puls  y
@next   leay  7,y
        bra   @l
@score  pshs  y
        ldu   #score
        jsr   DrawBCDE
        puls  y
        bra   @next
@ships  ldy   #CreditShips             ; sprite, hauteur, ligne
@s      ldu   ,y
        beq   @rts
        ldd   3,y
        bsr   CrLine
        cmpd  #PLAY_Y0+1
        blt   @sn
        pshs  d
        addb  2,y
        adca  #0
        cmpd  #PLAY_Y1
        puls  d
        bgt   @sn
        lda   #26
        pshs  y
        jsr   DrawSpr
        puls  y
@sn     leay  5,y
        bra   @s
@rts    rts

CreditShips
        fdb   SprSmall
        fcb   Small_H
        fdb   95
        fdb   SprEsc
        fcb   Esc_H
        fdb   113
        fdb   SprChef
        fcb   Chef_H
        fdb   133
        fdb   SprBoss
        fcb   Boss_H
        fdb   153
        fdb   0

* ligne (mot), nature (0 petit, 1 gros, 2 score), couleur, colonne, texte
CreditTable
        fdb   0
        fcb   1,$44,9
        fdb   TxtBravo
        fdb   18
        fcb   0,$11,12
        fdb   TxtWin
        fdb   40
        fcb   0,$55,14
        fdb   TxtScore
        fdb   52
        fcb   2,$11,17
        fdb   0
        fdb   78
        fcb   0,$44,14
        fdb   TxtFoes
        fdb   97
        fcb   0,$11,12
        fdb   TxtFoe1
        fdb   117
        fcb   0,$11,12
        fdb   TxtFoe2
        fdb   137
        fcb   0,$11,12
        fdb   TxtFoe3
        fdb   162
        fcb   0,$22,12
        fdb   TxtFoe4
        fdb   200
        fcb   1,$44,10
        fdb   TxtTitle
        fdb   222
        fcb   0,$11,8
        fdb   TxtCred1
        fdb   236
        fcb   0,$55,12
        fdb   TxtCred2
        fdb   250
        fcb   0,$55,11
        fdb   TxtCred3
        fdb   264
        fcb   0,$55,12
        fdb   TxtCred4
        fdb   292
        fcb   0,$44,10
        fdb   TxtThanks
        fdb   $FFFF
TxtScore  fcc  "FINAL SCORE"
          fcb  0
TxtFoes   fcc  "THE ENEMIES"
          fcb  0
TxtFoe1   fcc  "DRONE         50"
          fcb  0
TxtFoe2   fcc  "FIGHTER       80"
          fcb  0
TxtFoe3   fcc  "BOMBER       150"
          fcb  0
TxtFoe4   fcc  "MOTHERSHIP  2000"
          fcb  0
TxtTitle  fcc  "SPACECRAFT"
          fcb  0
TxtCred1  fcc  "A RETROWORLD GAMING GAME"
          fcb  0
TxtCred2  fcc  "FOR THOMSON MO6"
          fcb  0
TxtCred3  fcc  "AMADEUS SOUND CARD"
          fcb  0
TxtCred4  fcc  "  MEA8000 VOICE"
          fcb  0
TxtThanks
 IFDEF DEMO_DISK
          fcc  "FULL GAME: 16 LEVELS"
 ELSE
          fcc  "THANKS FOR PLAYING !"
 ENDC
          fcb  0

DrawDigitE                             ; chiffre A note pour l'effacement
        pshs  a
        lda   #5
        ldb   #1
        jsr   AddErase
        puls  a
        jmp   DrawDigit
DrawBCDE                               ; 6 chiffres notes pour l'effacement
        lda   #5
        ldb   #3
        jsr   AddErase
        leax  3,x
        lda   #5
        ldb   #3
        jsr   AddErase
        leax  -3,x
        ldb   #3
        jmp   DrawBCD

* =============================================================================
* Moteur et donnees en memoire programme
* =============================================================================
        INCLUDE "hw.asm"
        INCLUDE "screen.asm"
        INCLUDE "text.asm"
        INCLUDE "vscroll.asm"
        INCLUDE "amadeus.asm"
        INCLUDE "mea8000.asm"
        INCLUDE "font.asm"
        INCLUDE "digits.asm"
        INCLUDE "gen-pal.asm"
        INCLUDE "gen-bands.asm"
        INCLUDE "gen-caps.asm"
CapSpr     fdb SprLife,SprCanon,SprMulti
BonusOrder fcb 0,1,2,1
        INCLUDE "music.asm"
        INCLUDE "voice-index.asm"
        INCLUDE "voice-data.asm"

TxtVoiceOn  fcc "V: VOICE ON "
            fcb 0
TxtVoiceOff fcc "V: VOICE OFF"
            fcb 0
TxtStage fcc  "LEVEL "
TxtStageN fcc "01"
         fcb  0
TxtDemo  fcc  "DEMO"
         fcb  0
TxtAlert fcc  "WARNING"
         fcb  0
TxtCombo fcc  "COMBO X"
         fcb  0
TxtStrike fcc "STRIKE +500"
         fcb  0
TxtOver  fcc  "GAME OVER"
         fcb  0
TxtYour  fcc  "YOUR SCORE"
         fcb  0
TxtHigh  fcc  "HIGH SCORE"
         fcb  0
TxtNewHi fcc  "NEW HIGH SCORE !"
         fcb  0
TxtBravo fcc  "WELL DONE !"
         fcb  0
TxtWin
 IFDEF DEMO_DISK
         fcc  " END OF THE DEMO"
 ELSE
         fcc  "MISSION COMPLETE"
 ENDC
         fcb  0

SinTab                                 ; ondulation des ennemis (+-28, TO8)
        fcb   0,2,6,8,10,14,16,18,20,22,24,24,26,26,28,28,28,28,28,26,26,24,24,22,20,18,16,14,10,8,6,2
        fcb   0,-2,-6,-8,-10,-14,-16,-18,-20,-22,-24,-24,-26,-26,-28,-28,-28,-28,-28,-26,-26,-24,-24,-22,-20,-18,-16,-14,-10,-8,-6,-2
BossSin                                ; balancement du boss (+-40, TO8)
        fcb   0,4,8,12,16,18,22,26,28,30,34,36,36,38,40,40,40,40,40,38,36,36,34,30,28,26,22,18,16,12,8,4
        fcb   0,-4,-8,-12,-16,-18,-22,-26,-28,-30,-34,-36,-36,-38,-40,-40,-40,-40,-40,-38,-36,-36,-34,-30,-28,-26,-22,-18,-16,-12,-8,-4

t_rel    fcb  0
t_vk     fcb  0
t_blink  fcb  0
t_off    fcb  0
t_ph     fcb  0
band_k   fcb  0
t_cnt    fdb  0
demo     fcb  0
demo_vm  fcb  0
demo_t   fdb  0
hiscore  fcb  0,0,0
tmp      fcb  0
tmp2     fcb  0
dbg_fr   fcb  0
g_last   fcb  0
g_acc    fcb  0

Vars
quit     fcb  0
cr_pos   fdb  0
mode     fcb  0
mode_t   fcb  0
tick     fcb  0
hud_dirty fcb 0
score    fcb  0,0,0
power    fdb  0
level    fcb  0
go_new   fcb  0
lives    fcb  0
weapon   fcb  0
ship_x   fcb  0
ship_y   fcb  0
ship_inv fcb  0
fire_cd  fcb  0
sq_timer fcb  0
sq_count fcb  0
sq_type  fcb  0
sq_left  fcb  0
sq_x0    fcb  0
sq_dir   fcb  0
sq_alive fill 0,SQUADS+1
fire_t   fcb  0
met_t    fcb  0
bn_cnt   fcb  0
boss_on  fcb  0
boss_x   fcb  0
boss_y   fcb  0
boss_t   fcb  0
boss_warp fcb 0
boss_launch fcb 0
boss_hp  fcb  0
boss_fl  fcb  0
warn_t   fcb  0
combo_t  fcb  0
combo_n  fcb  0
cb_show  fcb  0
cb_dig   fcb  0
c_ax     fcb  0
c_ay     fcb  0
c_aw     fcb  0
c_ah     fcb  0
c_bx     fcb  0
c_by     fcb  0
c_bw     fcb  0
c_bh     fcb  0
Shots    fill 0,SH_SZ*NB_SH
EShots   fill 0,ES_SZ*NB_ES
Enemies  fill 0,EN_SZ*NB_EN
Meteors  fill 0,MT_SZ*NB_MT
Bonus    fill 0,4*NB_BN
Expl     fill 0,4*NB_EX
VarsEnd
CodeEnd
