* genere par tools/gen-voice.py

VOX_DOUBLE    equ 0
VOX_TRIPLE    equ 1
VOX_COMBO     equ 2
VOX_SUPER     equ 3
VOX_POWER     equ 4
VOX_LIFE      equ 5
VOX_STRIKE    equ 6
VOX_READY     equ 7
VOX_WARNING   equ 8
VOX_BOSS      equ 9
VOX_OVER      equ 10
VOX_COMPLETE  equ 11

VoiceOffsets
        fdb   0
        fdb   58
        fdb   124
        fdb   206
        fdb   344
        fdb   442
        fdb   564
        fdb   646
        fdb   736
        fdb   818
        fdb   956
        fdb   1058
