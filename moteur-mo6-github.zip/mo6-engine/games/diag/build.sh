#!/bin/sh
# Diagnostic MO6 : disquette qui teste balayage, pages, DKCO et palette
set -e
cd "$(dirname "$0")"
E=$(cd ../../engine && pwd)
T=$(cd ../../tools && pwd)
LWASM=${LWASM:-$(command -v lwasm || echo "$T/lwasm")}
mkdir -p build
cd src
$LWASM -f raw -I$E -o ../build/main.bin main.asm
N=$(( ($(stat -c%s ../build/main.bin)+255)/256 ))
$LWASM -f raw -D NSECT=$N -o ../build/boot.bin $E/boot.asm
cd ..
python3 $T/mkdisk.py build/boot.bin build/diag_mo6.fd build/main.bin@0:2
