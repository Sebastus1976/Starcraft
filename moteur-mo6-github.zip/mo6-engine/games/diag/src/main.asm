* =============================================================================
* Diagnostic MO6 : verifie sur la vraie machine ce que le moteur suppose
* (balayage $A7E7, pages par $A7E5 vues en $6000, pages cartouche par $A7E6
* vues en $B000, lecture DKCO dans ces pages, palette). Affiche en mode MO5
* (ecran du BASIC, page 0) sans rien demander au moniteur.
* =============================================================================
SYS1     equ  $A7E7
RAM_REG  equ  $A7E5
CART_REG equ  $A7E6
VID_MODE equ  $A7DC
VID_PAGE equ  $A7DD
PAL_DAT  equ  $A7DA
PAL_IDX  equ  $A7DB
PIA_A    equ  $A7C0

        org   $2300
Start
        orcc  #$50
        lds   #$2300
        lda   SYS1                     ; etat laisse par le BASIC
        sta   o_sys
        lda   CART_REG
        sta   o_cart
        lda   RAM_REG
        sta   o_ram
        clr   VID_MODE                 ; mode MO5, page 0, cadre vert
        lda   #$02
        sta   VID_PAGE
        jsr   Cls
        ldu   #T0
        jsr   Line
        ldu   #T1                      ; registres lus au depart
        jsr   Str
        lda   o_sys
        jsr   Hex
        ldu   #T1b
        jsr   Str
        lda   o_cart
        jsr   Hex
        ldu   #T1c
        jsr   Str
        lda   o_ram
        jsr   Hex
        ldu   #T1d
        jsr   Str
        lda   $2081
        jsr   Hex
        jsr   Nl

* --- 1 : balayage (bit 7 de $A7E7) ---
        ldu   #T2
        jsr   Str
        ldx   #0
        ldy   #20000
        lda   SYS1
        anda  #$80
        sta   tmp
@t      lda   SYS1
        anda  #$80
        cmpa  tmp
        beq   >
        sta   tmp
        leax  1,x
!       leay  -1,y
        bne   @t
        tfr   x,d
        jsr   Hex
        tfr   b,a
        jsr   Hex
        ldu   #T2b
        jsr   Str
        jsr   Nl

* --- 2 : pages vues en $6000 par $A7E5 (SYS1 = $10) ---
        ldu   #T3
        jsr   Line
        lda   $2081                    ; image de $A7E7 + bit 4
        ora   #$10
        sta   SYS1
        lda   #2
@w      sta   RAM_REG
        tfr   a,b
        orb   #$A0
        stb   $6000
        eorb  #$10                     ; $Bp
        stb   $8000
        inca
        cmpa  #8
        blo   @w
        lda   #2
@r      sta   tmp
        ldu   #TP
        jsr   Str
        lda   tmp
        jsr   Hex1
        lda   #':'
        jsr   Chr
        lda   tmp
        sta   RAM_REG
        lda   $6000
        jsr   Hex
        lda   #' '
        jsr   Chr
        lda   $8000
        jsr   Hex
        lda   tmp
        anda  #1
        beq   >
        jsr   Nl
!       lda   tmp
        inca
        cmpa  #8
        blo   @r
        ldu   #T3b
        jsr   Line

* --- 3 : les memes pages vues en $B000 par $A7E6 (SYS1 = $50) ---
        ldu   #T4
        jsr   Line
        lda   $2081                    ; image + bits 4 et 6
        ora   #$50
        sta   SYS1
        lda   #2
@c      sta   tmp
        ldu   #TP
        jsr   Str
        lda   tmp
        jsr   Hex1
        lda   #':'
        jsr   Chr
        lda   tmp
        adda  #$20                     ; RAM, lecture
        sta   CART_REG
        lda   $B000
        jsr   Hex
        lda   #' '
        jsr   Chr
        lda   $D000
        jsr   Hex
        lda   tmp
        anda  #1
        beq   >
        jsr   Nl
!       lda   tmp
        inca
        cmpa  #8
        blo   @c
        ldu   #T4c                     ; page cartouche 5 ecrite : ou est-elle
        jsr   Str                      ; vue en $6000 ?
        lda   #$65
        sta   CART_REG
        lda   #$C5
        sta   $B000
        lda   #$D5
        sta   $D000
        lda   #2
@s      sta   tmp
        sta   RAM_REG
        lda   $6000
        cmpa  #$C5
        bne   >
        lda   #'A'
        jsr   Chr
        lda   tmp
        jsr   Hex1
!       lda   $8000
        cmpa  #$D5
        bne   >
        lda   #'B'
        jsr   Chr
        lda   tmp
        jsr   Hex1
!       lda   tmp
        inca
        cmpa  #8
        blo   @s
        jsr   Nl

* --- 4 : DKCO (piste 4 secteur 1) vers $6000 page 4 puis $B000 page 5 ---
        ldu   #T5
        jsr   Str
        lda   #4
        sta   RAM_REG
        ldx   #$6000
        jsr   Read
        ldu   #T5b
        jsr   Str
        lda   #$65
        sta   CART_REG
        ldx   #$B000
        jsr   Read
        jsr   Nl
        lda   o_cart                   ; cartouche et SYS1 d'origine
        sta   CART_REG
        lda   $2081
        sta   SYS1
        ldu   #T5c
        jsr   Str
        lda   #4
        sta   RAM_REG
        ldx   #$6000
        jsr   Read
        jsr   Nl

* --- 5 : palette (couleur 7 = celle du texte) ---
        ldu   #T6
        jsr   Line
        ldu   #T6b
        jsr   Line
        ldu   #T6c
        jsr   Line
        jsr   Wait
        lda   #14                      ; couleur 7 seule (index ecrit) : rouge
        sta   PAL_IDX
        lda   #$0F                     ; vert 0, rouge 15
        sta   PAL_DAT
        lda   #$00
        sta   PAL_DAT
        jsr   Wait
        lda   #0                       ; 16 couleurs d'affilee (auto-increment)
        sta   PAL_IDX
        ldx   #PalTest
        ldb   #32
@p      lda   ,x+
        sta   PAL_DAT
        decb
        bne   @p
        jsr   Wait
        ldu   #T7                      ; 6 : page 2 affichee en 160x200 16 c.
        jsr   Line
        jsr   Wait
        lda   $2081
        ora   #$10
        sta   SYS1
        lda   #2
        sta   RAM_REG
        ldx   #$6000
@f      lda   #$34                     ; RAM B : couleurs 3 et 4
        cmpx  #$8000
        blo   >
        lda   #$12                     ; RAM A : couleurs 1 et 2
!       sta   ,x+
        cmpx  #$A000
        blo   @f
        lda   #0                       ; palette de base
        sta   PAL_IDX
        ldx   #PalBase
        ldb   #32
@pb     lda   ,x+
        sta   PAL_DAT
        decb
        bne   @pb
        lda   #$7B
        sta   VID_MODE
        lda   #$80                     ; page 2, cadre 0
        sta   VID_PAGE
        jsr   Wait
        jsr   Wait
        clr   VID_MODE                 ; retour : mode MO5, page 0
        lda   #$02
        sta   VID_PAGE
        clr   $A7CE                    ; 7 : manettes (reglage du jeu)
        clr   $A7CC
        lda   #$04
        sta   $A7CE
        clr   $A7CF
        lda   #$3F
        sta   $A7CD
        lda   #$04
        sta   $A7CF
        ldu   #T8
        jsr   Line
        lda   row
        sta   tmp2
        ldy   #1500                    ; ~20 s d'affichage en direct
@j      lda   tmp2
        sta   row
        clr   col
        ldu   #T8b
        jsr   Str
        lda   $A7CC
        jsr   Hex
        ldu   #T8c
        jsr   Str
        lda   $A7CD
        jsr   Hex
        ldx   #1500
@d      leax  -1,x
        bne   @d
        leay  -1,y
        bne   @j
        jsr   Nl
        ldu   #TEnd
        jsr   Line
Halt    bra   Halt

* Read : X = tampon ; lit piste 4 secteur 1, affiche C (0/1), $204E, 1er octet
Read
        stx   $204F
        clr   $2049
        clr   $204A
        lda   #4
        sta   $204B
        lda   #1
        sta   $204C
        clr   ,x
        lda   #2
        sta   $2048
        jsr   $A004
        lda   #0
        rola
        pshs  x
        jsr   Hex1
        lda   #'/'
        jsr   Chr
        lda   $204E
        jsr   Hex
        lda   #'/'
        jsr   Chr
        puls  x
        lda   ,x
        jmp   Hex

Wait    ldx   #0                       ; ~3 s
@w      leax  -1,x
        nop
        nop
        nop
        nop
        bne   @w
        ldx   #0
@w2     leax  -1,x
        nop
        nop
        nop
        nop
        bne   @w2
        rts

* --- texte en mode MO5 : $A7C0 bit 0 = 1 forme, 0 couleur ---
Cls     lda   PIA_A
        anda  #$FE                     ; couleurs : texte 7 sur fond 0
        sta   PIA_A
        ldx   #0
        lda   #$70
@c      sta   ,x+
        cmpx  #8000
        blo   @c
        lda   PIA_A
        ora   #1
        sta   PIA_A
        ldx   #0
@f      clr   ,x+
        cmpx  #8000
        blo   @f
        clr   row
        clr   col
        rts
Line    bsr   Str
Nl      clr   col
        inc   row
        rts
Str     lda   ,u+
        beq   @r
        bsr   Chr
        bra   Str
@r      rts
Hex     pshs  a
        lsra
        lsra
        lsra
        lsra
        bsr   Hex1
        puls  a
Hex1    anda  #$0F
        adda  #'0'
        cmpa  #'9'
        bls   Chr
        adda  #7
Chr     pshs  a,b,x,y,u
        ldb   col
        cmpb  #40
        bhs   @out
        suba  #32
        ldb   #5
        mul
        ldy   #Font
        leay  d,y
        lda   row                      ; X = row*320 + col + 40
        ldb   #160
        mul
        lslb
        rola
        addb  col
        adca  #0
        addd  #40
        tfr   d,x
        lda   #5
        sta   cn
@l      ldb   ,y+
        clra
        bitb  #4
        beq   >
        ora   #$C0
!       bitb  #2
        beq   >
        ora   #$30
!       bitb  #1
        beq   >
        ora   #$0C
!       sta   ,x
        leax  40,x
        dec   cn
        bne   @l
        inc   col
@out    puls  a,b,x,y,u,pc

T0      fcc   "DIAGNOSTIC MO6 - SPACECRAFT"
        fcb   0
T1      fcc   "SYS1="
        fcb   0
T1b     fcc   " CA="
        fcb   0
T1d     fcc   " IMG="
        fcb   0
T1c     fcc   " RAM="
        fcb   0
T2      fcc   "1 BALAYAGE: "
        fcb   0
T2b     fcc   " (ATTENDU 0020-0050)"
        fcb   0
T3      fcc   "2 PAGES EN 6000 (ATTENDU AP BP)"
        fcb   0
T3b     fcc   " "
        fcb   0
T4      fcc   "3 PAGES EN B000 (ATTENDU AP BP)"
        fcb   0
T4b     fcc   " "
        fcb   0
T4c     fcc   "  CART P5 VUE EN 6000: "
        fcb   0
TP      fcc   "  P"
        fcb   0
T5      fcc   "4 DKCO 6000:"
        fcb   0
T5b     fcc   " B000:"
        fcb   0
T5c     fcc   "  BASIC 6000:"
        fcb   0
T6      fcc   "5 PALETTE: CE TEXTE DEVIENT ROUGE"
        fcb   0
T6b     fcc   "  PUIS VERT. NOTE LES COULEURS."
        fcb   0
T6c     fcc   " "
        fcb   0
T7      fcc   "6 FINES RAYURES ROUGE VERT JAUNE BLEU ?"
        fcb   0
T8      fcc   "7 MANETTE: BOUGE-LA, APPUIE SUR LE BOUTON"
        fcb   0
T8b     fcc   "  PA(A7CC)="
        fcb   0
T8c     fcc   "  PB(A7CD)="
        fcb   0
TEnd    fcc   "FIN - PHOTO DE L'ECRAN SVP"
        fcb   0

PalTest                                ; 0 noir, 7 vert, le reste gris
        fdb   $0000,$5505,$5505,$5505,$5505,$5505,$5505,$F000
        fdb   $5505,$5505,$5505,$5505,$5505,$5505,$5505,$5505

PalBase                                ; 0 noir 1 rouge 2 vert 3 jaune 4 bleu 7 vert
        fdb   $0000,$0F00,$F000,$FF00,$000F,$0F0F,$F00F,$F000
        fdb   $5505,$5505,$5505,$5505,$5505,$5505,$5505,$5505
o_sys   fcb   0
o_cart  fcb   0
o_ram   fcb   0
tmp     fcb   0
tmp2    fcb   0
row     fcb   0
col     fcb   0
cn      fcb   0

        INCLUDE "font.asm"
