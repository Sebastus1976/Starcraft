# Moteur MO6 – jeux pour Thomson MO6 avec carte son Amadeus

Moteur de jeu en assembleur 6809 pour **Thomson MO6** (128 Ko), avec :

- **Écran** : mode 160×200 en 16 couleurs, double tampon (pages vidéo 2 et 3), sprites masqués qui ne clignotent pas, listes d'effacement.
- **Décor** : fond en tuiles qui défile verticalement. Seules les tuiles non vides sont dessinées, ce qui garde les fonds étoilés rapides.
- **Son** : carte **Amadeus** (YM2413 en `$A7FC/$A7FD`, SN76489 en `$A7F7`) avec un lecteur de musique 3 voies et des bruitages.
- **Voix** : synthétiseur vocal **MEA8000** (`$A7FE/$A7FF`), facultatif.
- **Rythme sans interruption** : 50 images par seconde, tirées du balayage vidéo. Le jeu ne dépend pas du moniteur ni de l'émulateur.
- **Entrées** : manette 1 et clavier (flèches, ESPACE, ENTRÉE, et toute touche avec `KeyDown`).
- **Textes** : police 3×5 et chiffres de bandeau.
- **Disquette** : secteur d'amorçage, chargement de secteurs, fabrication des images `.fd` (disquette) et `.sd` (SDDRIVE).

```
engine/      le moteur (à inclure dans le jeu)
tools/       mo6gfx.py (images -> données), mkdisk.py (disquette), lwasm
games/
  exemple/     le plus petit jeu possible : un vaisseau qui bouge, une musique
  spacecraft/  démo jouable de Spacecraft (le jeu TO8, adapté)
```

## Démarrer un jeu sur MO6

Mettre la disquette (ou choisir le fichier `.sd` dans le menu SDDRIVE), allumer, puis choisir **1 BASIC 128**. Le secteur d'amorçage charge le programme et le lance.

## Construire

Il faut **Python 3** avec Pillow et l'assembleur **lwasm** de [LWTOOLS](http://www.lwtools.ca/). `lwasm` peut être dans le PATH, dans `tools/lwasm`, ou donné par la variable `LWASM`.

```sh
games/exemple/build.sh       # -> games/exemple/build/exemple.fd / .sd
games/spacecraft/build.sh    # jeu complet -> games/spacecraft/build/spacecraft_mo6.fd / .sd
DEFS="-D DEMO_DISK" games/spacecraft/build.sh   # demo 4 etapes -> spacecraft_mo6_demo.fd / .sd
python3 games/spacecraft/print/gen-print.py   # livret CD, jaquette arriere, etiquettes HERMA -> games/spacecraft/build/print/
```

## Carte mémoire

| Zone | Usage |
|---|---|
| `$0000-$1FFF` | fenêtre vidéo de la page 0, sert de tampon de copie (`CopyPage`) |
| `$2000-$20FF` | variables du moniteur, utilisées par la lecture disquette |
| `$2100-$22FF` | pile (`S = $2300`) ; le secteur d'amorçage est chargé en `$2200` |
| `$2300-$5FFF` | **programme** : moteur, jeu et petites données (environ 15,6 Ko) |
| `$6000-$9FFF` | espace données : **tampon de dessin**. RAM A (points 0-1 de chaque groupe de 4) en `$8000`, RAM B (points 2-3) en `$6000` |
| `$B000-$EFFF` | espace cartouche : **page de données** du jeu (page 5, 16 Ko) |
| pages 4, 6, 7 | libres (images plein écran, données en plus…) |

## Utilisation

Le jeu commence en `$2300` (`org $2300`). Il inclut `mo6.inc` en tête, puis les modules du moteur. Le chemin d'inclusion est passé à lwasm avec `-I engine`.

```asm
        INCLUDE "mo6.inc"
        org   $2300
Start   lds   #$2300
        jsr   HwInit            ; interruptions masquees, mode 160x200, manettes
        jsr   SoundInit
        jsr   VoiceInit
        jsr   ScreenInit        ; pages 2 et 3 effacees
        ...
Loop    jsr   ScreenBegin       ; tampon cache visible en $6000, ancien dessin efface
        jsr   ReadInput         ; in_dir, in_fire
        ...                     ; logique, VsDraw, DrawSpr, DrawText...
        lda   #2                ; au plus 25 images de jeu par seconde
        jsr   ScreenEnd         ; montre le tampon dessine, echange
        bra   Loop
        INCLUDE "hw.asm"
        INCLUDE "screen.asm"
        INCLUDE "text.asm"
        INCLUDE "vscroll.asm"   ; si decor en tuiles
        INCLUDE "amadeus.asm"
        INCLUDE "mea8000.asm"
        INCLUDE "font.asm"
        INCLUDE "digits.asm"
```

Le jeu doit fournir `VoiceOffsets` et `VoiceData`. Ces deux étiquettes peuvent rester vides s'il n'y a pas de voix.

### hw.asm – matériel

| Routine | Rôle |
|---|---|
| `HwInit` | Configuration du MO6 : interruptions masquées pour toujours, pages données et cartouche commandées par registre, page 5 en `$B000` (en écriture), mode 160×200, ports des manettes. |
| `Tick` | **Rythme.** Le bit 7 de `$A7E7` vaut 1 pendant les 200 lignes utiles. À chaque passage à 0 : `frame` augmente, la musique et les voix avancent d'une image. Le moteur l'appelle souvent (chaque sprite, tuile, effacement). Dans une longue boucle de votre jeu, ajoutez un `jsr Tick` (au moins toutes les 6 ms). |
| `WaitFrame` / `WaitFrames` | Attendre 1 image, ou A images. |
| `SetPal` | X → 16 couleurs (mot : vert×16 + rouge, puis bleu). `PalBlack` = tout noir. |
| `ClearPage` | Remettre à zéro la page A. |
| `CopyPage` | Copier la page A dans la page B. |
| `ShowPage` | Afficher la page A (0-3). |
| `LoadSectors` | Lire Y secteurs depuis la piste A, secteur B, vers l'adresse X. |
| `ReadInput` | Remplit `in_dir` (`J_UP`, `J_DOWN`, `J_LEFT`, `J_RIGHT`) et `in_fire`. |
| `KeyDown` | B = ligne×2 + colonne×16 de la matrice du clavier → Z = 0 si la touche est enfoncée (V = `$54`, ESPACE = `$40`). |
| `Rand` | B = nombre pseudo-aléatoire. |
| `Unrle` | Décompresse une image RLE : U = données, X = destination, Y = fin. |

### screen.asm – double tampon et sprites

| Routine | Rôle |
|---|---|
| `ScreenInit` | Effacer les pages 2 et 3 ; le dessin commence en page 2. |
| `ScreenBegin` | Rendre visible le tampon caché en `$6000-$9FFF` et effacer ce qui y avait été dessiné. |
| `ScreenEnd` | Attendre A images depuis la dernière, puis montrer le tampon et échanger. Si le dessin prend plus de temps, faites avancer la logique selon les images écoulées (`frame`), comme Spacecraft : le jeu garde alors sa vitesse. |
| `DrawSpr` | U = sprite, A = x (pair, 0-158), B = y. Le sprite doit tenir dans l'écran. |
| `AddErase` | X = adresse, A = lignes, B = paires → zone effacée la prochaine fois. Mettre `no_er` ≠ 0 pour dessiner sans effacement (bandeaux, décor fixe). |
| `ScrAddr` | A = x, B = y → X = adresse RAM A. |

### vscroll.asm – décor en tuiles

| Routine | Rôle |
|---|---|
| `VsInit` | X = `<nom>_Rows`, Y = `<nom>_Tiles`, D = `<nom>_PIXH`. |
| `vs_cam` | Ligne de la carte affichée en haut de l'écran. |
| `VsMove` | B = défilement en 1/256 de ligne. |
| `VsDraw` | Dessine les lignes `VS_Y0` à `VS_Y1` de l'écran (à définir avant l'inclusion). |
| `VsErase` | Efface les étoiles dessinées la fois précédente ; à appeler juste après `ScreenBegin`. Les octets isolés du décor (étoiles) sont dessinés et effacés un par un, ce qui est bien plus rapide que des tuiles. |

### text.asm – textes

| Routine | Rôle |
|---|---|
| `DrawText` | X = adresse, U = texte (fin = 0), A = couleur doublée (`$44`). |
| `DrawTextBig` | Même chose, lettres doublées. |
| `DrawDigit` | Un chiffre du bandeau. |
| `DrawBCD` | Nombre en BCD. |

### amadeus.asm – musique et bruitages

| Routine | Rôle |
|---|---|
| `SoundInit` | Préparer la carte son. |
| `MusicPlay` | X → morceau : 3 pointeurs (mélodie, basse, nappe) vers des suites (note MIDI ou 0 = silence, durée en images ; `$FF` reboucle, `$FE` arrête). |
| `MusicStop` | Arrêter la musique. |
| `SfxPlay` | A = `SFX_SHOT`, `SFX_EXPLO`, `SFX_BONUS`, `SFX_HIT` ou `SFX_TICK`. |

### mea8000.asm – voix

| Routine | Rôle |
|---|---|
| `VoicePlay` | A = numéro de phrase. Une phrase plus importante (numéro plus grand) coupe la phrase en cours. |
| `vo_mute` | ≠ 0 : voix coupées. |

Les phrases (`VoiceOffsets`, `VoiceData`) sont produites par l'outil `gen-voice.py` du jeu TO8 : espeak-ng → MEA8000.

## Outils

`tools/mo6gfx.py` convertit les images. Les PNG sont en couleurs indexées : index 0 = transparent, index k = couleur k-1 (la même convention que le moteur wide-dot du TO8). Un point = un point TO.

```sh
mo6gfx.py sprites sortie.asm Nom=image.png ...      # sprites (2 phases) + Nom_W / Nom_H
mo6gfx.py palette sortie.asm Nom=palette.png ...    # palettes 16 couleurs + Nom_WHITE
mo6gfx.py page image.png sortie.bin                 # écran 160x200 -> page de 16 Ko
mo6gfx.py tiles Nom tuiles.png carte.stm sortie.asm # décor en tuiles 8x16
mo6gfx.py bands sortie.asm haut.png bas.png         # bandeaux 160x16
```

`tools/mkdisk.py boot.bin sortie.fd fichier@piste:secteur ...` fabrique la disquette (`.fd`, 2 faces) et l'image SDDRIVE (`.sd`).

`tools/emu/mo6emu.py disque.fd main.lst secondes [--play] var ...` est un banc d'essai sans écran : un 6809 (paquet Python `MC6809`) et un MO6 réduit (pages, DKCO, balayage `$A7E7`). Il fait tourner le jeu, en démo ou avec des commandes au hasard (`--play`), note chaque écriture sur les variables données avec l'adresse de l'instruction, signale toute écriture dans le code, et sait sauver l'écran en PNG (`DUMPON=var:valeur:délai`).

**Secteur d'amorçage MO** (piste 0, secteur 1, chargé en `$2200`) :

- octets 0 à 119 : code, chaque octet en complément à 2 ;
- octets 120 à 125 : `BASIC2` en clair ;
- octet 127 : `$55` + somme des 127 octets une fois décodés.

Le secteur d'amorçage met sa pile en `$2280-$22FF` (la fin de son propre secteur) et garde ses compteurs en `$227E-$227F` : le vrai contrôleur et SDDRIVE ont leurs variables dans la page `$20` et au-dessus, il ne faut rien y écrire d'autre que les registres DKCO. En cas d'erreur de lecture (4 essais par secteur), l'écran du BASIC reste affiché avec un cadre rouge.

La lecture d'un secteur se fait par `jsr $A004` (DKCO). Ses registres sont `$2048` (opération), `$2049` (lecteur), `$204B` (piste), `$204C` (secteur) et `$204F` (adresse).
