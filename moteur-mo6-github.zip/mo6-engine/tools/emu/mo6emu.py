#!/usr/bin/env python3
"""Banc d'essai sans ecran : 6809 + memoire MO6 minimale (pages, DKCO,
balayage $A7E7), pour faire tourner un jeu du moteur et surveiller la memoire.

  mo6emu.py disque.fd main.lst [secondes] [--watch nom ...]

Le jeu demarre en $2300 (comme apres le secteur de boot), la demo tourne
toute seule. Chaque ecriture sur une variable surveillee est notee avec le PC.
"""
import re
import sys
from MC6809.components.cpu6809 import CPU
from MC6809.core.configs import BaseConfig

FRAME = 20000            # cycles par image (1 MHz, 50 Hz)
USEFUL = 12800           # 200 lignes de 64 us


class Mem:
    def __init__(self, fd):
        self.flat = bytearray(0x10000)
        self.pages = [bytearray(0x4000) for _ in range(32)]
        self.fd = fd
        self.ram_reg = 0
        self.cart = 0
        self.vid = 0
        self.pal = bytearray(32)
        self.pal_i = 0
        self.dumps = []
        self.trig = []
        self.watch = {}
        self.log = []
        self.cpu = None
        self.bad = []
        self.play = False
        self.live = True
        self.in_fr = -1
        self.in_dir = 0
        self.in_fire = False
        import random
        import os
        self.rng = random.Random(int(os.environ.get("SEED", "1")))

    def _map(self, a):
        if 0x6000 <= a < 0xA000:
            return self.pages[self.ram_reg & 31], a - 0x6000
        if 0xB000 <= a < 0xF000:
            return self.pages[self.cart & 31], a - 0xB000
        return self.flat, a

    def read_byte(self, a):
        a &= 0xFFFF
        if a == 0xA7E7:
            return 0x80 if (self.cpu.cycles % FRAME) < USEFUL else 0
        if a == 0xA7CC or a == 0xA7CD:
            if self.play:
                fr = self.cpu.cycles // FRAME
                if fr // 8 != self.in_fr:
                    self.in_fr = fr // 8
                    self.in_dir = self.rng.choice((0, 1, 2, 4, 8, 5, 9, 6, 10, 4, 8))
                    self.in_fire = self.rng.random() < 0.8
                if a == 0xA7CC:
                    return ~self.in_dir & 0xFF
                return 0xBF if self.in_fire else 0xFF
            return 0xFF
        if a == 0xA7C1:
            return 0x80
        m, o = self._map(a)
        return m[o]

    def read_word(self, a):
        return (self.read_byte(a) << 8) | self.read_byte(a + 1)

    def write_byte(self, a, v):
        a &= 0xFFFF
        v &= 0xFF
        if a == 0xA7E5:
            self.ram_reg = v
        elif a == 0xA7E6:
            self.cart = v
        elif a == 0xA7DD:
            self.vid = v >> 6
        elif a == 0xA7DB:
            self.pal_i = v & 31
        elif a == 0xA7DA:
            self.pal[self.pal_i] = v
            self.pal_i = (self.pal_i + 1) & 31
        if a in self.watch:
            pc = self.cpu.last_op_address
            self.log.append((self.cpu.cycles // FRAME, pc, self.watch[a], v))
            for nm, val, dl in self.trig:
                if nm == self.watch[a] and val == v and len(self.dumps) < 6:
                    self.dumps.append(self.cpu.cycles // FRAME + dl)
                    self.dumps.sort()
            if self.live:
                print('frame %6d  %-8s <- %02X  pc=%04X' % (self.cpu.cycles // FRAME, self.watch[a], v, pc), flush=True)
        if a in self.code:
            self.bad.append((self.cpu.cycles // FRAME, self.cpu.last_op_address, a, v))
        if 0xB000 <= a < 0xF000 and not (self.cart & 0x40):
            return
        if 0xA000 <= a < 0xB000 or a >= 0xF000:
            return
        m, o = self._map(a)
        m[o] = v

    def write_word(self, a, v):
        self.write_byte(a, v >> 8)
        self.write_byte(a + 1, v & 255)

    def dkco(self):
        f = self.flat
        t, s = f[0x204B], f[0x204C]
        adr = (f[0x204F] << 8) | f[0x2050]
        off = (t * 16 + s - 1) * 256
        for i in range(256):
            self.write_byte(adr + i, self.fd[off + i])


def dump(mem, fr):
    from PIL import Image
    lv = [0, 97, 122, 143, 158, 171, 184, 194, 204, 212, 219, 227, 235, 242, 250, 255]
    pal = []
    for i in range(16):
        g, r, b = mem.pal[2 * i] >> 4, mem.pal[2 * i] & 15, mem.pal[2 * i + 1] & 15
        pal += [lv[r], lv[g], lv[b]]
    vp = mem.vid
    pg = mem.pages[vp]
    im = Image.new('P', (160, 200))
    im.putpalette(pal)
    for y in range(200):
        for c in range(40):
            a, b = pg[0x2000 + y * 40 + c], pg[y * 40 + c]
            for k, v in enumerate((a >> 4, a & 15, b >> 4, b & 15)):
                im.putpixel((c * 4 + k, y), v)
    im = im.resize((320, 200), Image.NEAREST)
    im.save('dump%d.png' % fr)
    print('image', fr, 'page', vp, flush=True)


def main():
    fd = open(sys.argv[1], 'rb').read()
    lst = open(sys.argv[2]).read()
    secs = float(sys.argv[3]) if len(sys.argv) > 3 else 60
    sym = {}
    for m in re.finditer(r'^([0-9A-F]{4}) .*?\):\d+ {9}(\w+)', lst, re.M):
        sym.setdefault(m.group(2), int(m.group(1), 16))
    mem = Mem(fd)
    code = set()                        # octets d'instructions (pas fcb/fdb/fill)
    for m in re.finditer(r'^([0-9A-F]{4}) ([0-9A-F]+) +\(.*?\):\d+ +(?:[@\w!]+ +)?(\w+)', lst, re.M):
        if m.group(3).lower() not in ('fcb', 'fdb', 'fill', 'fcc', 'rmb', 'zmb', 'equ'):
            a = int(m.group(1), 16)
            code.update(range(a, a + len(m.group(2)) // 2))
    mem.code = code
    args = sys.argv[4:]
    if '--play' in args:
        args.remove('--play')
        mem.play = True
    for name in args:
        if name in sym:
            mem.watch[sym[name]] = name
            mem.watch[sym[name] + 1] = name + '+1'
    cpu = CPU(mem, BaseConfig({"trace": False, "verbosity": 0}))
    mem.cpu = cpu
    cpu.last_op_address = 0
    # chargement comme le secteur de boot : programme en $2300 (piste 0, secteur 2)
    nsect = 61
    for i in range(nsect * 256):
        mem.flat[0x2300 + i] = fd[256 + i]
    cpu.program_counter.set(0x2300)
    cpu.system_stack_pointer.set(0x2300)
    import os
    dumps = mem.dumps
    dumps += [int(x) for x in os.environ.get('DUMP', '').split(',') if x]
    dumps.sort()
    for t in os.environ.get('DUMPON', '').split(','):
        if t:
            nm, val, dl = t.split(':')
            mem.trig.append((nm, int(val, 16), int(dl)))
    rsym = sorted((v, k) for k, v in sym.items())
    end = secs * 50 * FRAME
    nextrep = 0
    pc = cpu.program_counter
    while cpu.cycles < end:
        a = pc.value
        if a == 0xA004:                         # DKCO
            mem.dkco()
            cpu.C = 0
            pc.set(cpu.pull_word(cpu.system_stack_pointer))
            continue
        cpu.last_op_address = a
        cpu.get_and_call_next_op()
        if dumps and cpu.cycles >= dumps[0] * FRAME:
            dump(mem, dumps.pop(0))
        if cpu.cycles >= nextrep:
            nextrep += 50 * FRAME * 5
            print('t=%5.1fs pc=%04X' % (cpu.cycles / FRAME / 50, pc.value), flush=True)

    def where(x):
        best = None
        for v, k in rsym:
            if v <= x:
                best = (k, x - v)
        return '%s+%d' % best if best else '?'
    for fr, p, n, v in mem.log:
        print('frame %6d  %-8s <- %02X  pc=%04X %s' % (fr, n, v, p, where(p)))
    print('ecritures dans le code :', len(mem.bad))
    for fr, p, a, v in mem.bad[:40]:
        print('frame %6d  [%04X %s] <- %02X  pc=%04X %s' % (fr, a, where(a), v, p, where(p)))


if __name__ == '__main__':
    main()
