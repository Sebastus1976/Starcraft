#!/usr/bin/env python3
"""Moteur MO6 - conversion des images pour le moteur.

Convention des PNG (la meme que le moteur wide-dot du TO8) : images en
couleurs indexees, index 0 = transparent, index k = couleur k-1 de la palette.
Un point de l'image = un point TO (2 pixels de large a l'ecran), 160 x 200.

  mo6gfx.py sprites  sortie.asm  Nom=image.png ...
      sprites masques, 2 phases (x multiple de 4, x = 4n+2) ; Nom_W, Nom_H
  mo6gfx.py palette  sortie.asm  Nom=palette.png ...
      palettes 16 couleurs (PNG 16 x 1) au format MO6/TO8 ; Nom_WHITE = la
      couleur la plus claire, doublee (pour les textes)
  mo6gfx.py page     image.png sortie.bin
      ecran 160x200 -> 16 Ko pour une page video chargee en $6000-$9FFF
      ($6000 = RAM B, $8000 = RAM A)
  mo6gfx.py tiles    Nom tuiles.png carte.stm sortie.asm
      decor en tuiles 8x16 (formats wide-dot : colonne de tuiles, carte STMP)
      pour engine/vscroll.asm
  mo6gfx.py bands    sortie.asm haut.png bas.png
      bandeaux 160x16 deja au format ecran (RAM A puis RAM B, 640 octets)
"""
import struct
import sys
from PIL import Image

LEVELS = [0, 97, 122, 143, 158, 171, 184, 194, 204, 212, 219, 227, 235, 242, 250, 255]


def fcb(vals, ind='        '):
    return [ind + 'fcb   ' + ','.join('$%02X' % v for v in vals[i:i + 16])
            for i in range(0, len(vals), 16)]


def pixels(path):
    im = Image.open(path)
    return im.size, list(im.get_flattened_data() if hasattr(im, 'get_flattened_data') else im.getdata())


def sprites(out, specs):
    lines = ['* genere par tools/mo6gfx.py sprites']
    for spec in specs:
        name, path = spec.split('=')
        (w, h), px = pixels(path)
        lines += ['%s_W equ %d' % (name, w), '%s_H equ %d' % (name, h),
                  'Spr%s fdb Spr%s_0,Spr%s_1' % (name, name, name)]
        for ph in (0, 1):
            off = 2 * ph
            p = (w + off + 3) // 4
            data = [h, p]
            for y in range(h):
                for j in range(p):
                    g = []
                    for k in range(4):
                        x = j * 4 + k - off
                        g.append(px[y * w + x] if 0 <= x < w else 0)
                    for a, b in ((g[0], g[1]), (g[2], g[3])):
                        m = (0 if a else 0xF0) | (0 if b else 0x0F)
                        v = ((a - 1 if a else 0) << 4) | (b - 1 if b else 0)
                        data += [m, v]
            lines.append('Spr%s_%d' % (name, ph))
            lines += fcb(data)
    open(out, 'w').write('\n'.join(lines) + '\n')


def level(v):
    return min(range(16), key=lambda i: abs(LEVELS[i] - v))


def palette(out, specs):
    lines = ['* genere par tools/mo6gfx.py palette']
    for spec in specs:
        name, path = spec.split('=')
        im = Image.open(path).convert('RGB')
        cols = [im.getpixel((i, 0)) for i in range(16)]
        ws = [(level(g) << 12) | (level(r) << 8) | level(b) for r, g, b in cols]
        wi = max(range(16), key=lambda i: sum(cols[i]))
        lines.append('%s_WHITE equ $%X%X' % (name, wi, wi))
        lines.append(name)
        for i in range(0, 16, 8):
            lines.append('        fdb   ' + ','.join('$%04X' % v for v in ws[i:i + 8]))
    open(out, 'w').write('\n'.join(lines) + '\n')


def page(src, out):
    (w, h), px = pixels(src)
    assert (w, h) == (160, 200), (w, h)
    a, b = bytearray(8192), bytearray(8192)
    for y in range(200):
        for c in range(40):
            p = [max(0, px[y * 160 + c * 4 + k] - 1) for k in range(4)]
            a[y * 40 + c] = (p[0] << 4) | p[1]
            b[y * 40 + c] = (p[2] << 4) | p[3]
    open(out, 'wb').write(bytes(b) + bytes(a))


def tiles(name, tpng, stm, out):
    (tw, th), px = pixels(tpng)
    assert tw == 8
    n = th // 16
    raw = open(stm, 'rb').read()
    assert raw[:4] == b'STMP'
    mw, mh = struct.unpack('<HH', raw[4:8])
    m = struct.unpack('<%dI' % (mw * mh), raw[8:8 + 4 * mw * mh])
    used = sorted(set(m))
    lines = ['* genere par tools/mo6gfx.py tiles : %s, carte %d x %d' % (name, mw, mh),
             '%s_W equ %d' % (name, mw), '%s_H equ %d' % (name, mh),
             '%s_PIXH equ %d' % (name, mh * 16)]
    tiledata = {}
    stars = {}
    for t in used:
        cols = [[max(0, px[(t * 16 + y) * 8 + x] - 1) for x in range(8)] for y in range(16)]
        rows = [y for y in range(16) if any(cols[y])]
        if not rows:
            continue
        pairs = [j for j in range(2) if any(any(cols[y][j * 4:j * 4 + 4]) for y in rows)]
        y0, y1 = rows[0], rows[-1] + 1
        j0, j1 = pairs[0], pairs[-1] + 1
        off = y0 * 40 + j0
        data = [off >> 8, off & 255, y1 - y0, j1 - j0, y0, j0]
        for y in range(y0, y1):
            for j in range(j0, j1):
                p = cols[y][j * 4:j * 4 + 4]
                data += [(p[0] << 4) | p[1], (p[2] << 4) | p[3]]
        tiledata[t] = data
        nz = []                                  # octets utiles (etoiles)
        for y in range(16):
            for j in range(2):
                p = cols[y][j * 4:j * 4 + 4]
                va, vb = (p[0] << 4) | p[1], (p[2] << 4) | p[3]
                if va:
                    nz.append((y, j, 0, va))
                if vb:
                    nz.append((y, j, 1, vb))
        if len(nz) <= 4:                         # tuile clairsemee : octets seuls
            stars[t] = nz
    for t in stars:                              # (dessinees comme etoiles)
        tiledata.pop(t, None)
    ids = {t: i for i, t in enumerate(sorted(tiledata))}
    lines.append('%s_Tiles' % name)
    for t in sorted(tiledata):
        lines.append('        fdb   %s_T%d' % (name, ids[t]))
    for t in sorted(tiledata):
        lines.append('%s_T%d' % (name, ids[t]))
        lines += fcb(tiledata[t])
    lines.append('%s_Rows' % name)
    for r in range(mh):
        lines.append('        fdb   %s_R%d' % (name, r))
    total = nst = 0
    for r in range(mh):
        st, ent = [], []
        for c in range(mw):
            t = m[r * mw + c]
            if t in stars:
                for y, j, b, v in stars[t]:
                    off = (y * 40 + c * 2 + j - (0x2000 if b else 0)) & 0xFFFF
                    st += [off >> 8, off & 255, v]
            elif t in ids:
                ent += [c, ids[t]]
        total += len(ent) // 2
        nst += len(st) // 3
        lines.append('%s_R%d' % (name, r))
        lines += fcb([len(st) // 3] + st + [len(ent) // 2] + ent)
    open(out, 'w').write('\n'.join(lines) + '\n')
    print('%s : %d tuiles, %d poses de tuiles, %d etoiles' % (name, len(tiledata), total, nst))


def bands(out, top, bot):
    lines = ['* genere par tools/mo6gfx.py bands : RAM A puis RAM B (640 octets)']
    for name, path in (('BandTop', top), ('BandBot', bot)):
        (w, h), px = pixels(path)
        assert (w, h) == (160, 16)
        a, b = [], []
        for y in range(16):
            for c in range(40):
                p = [max(0, px[y * 160 + c * 4 + k] - 1) for k in range(4)]
                a.append((p[0] << 4) | p[1])
                b.append((p[2] << 4) | p[3])
        lines.append(name)
        lines += fcb(a + b)
    open(out, 'w').write('\n'.join(lines) + '\n')


if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'sprites':
        sprites(sys.argv[2], sys.argv[3:])
    elif cmd == 'palette':
        palette(sys.argv[2], sys.argv[3:])
    elif cmd == 'page':
        page(sys.argv[2], sys.argv[3])
    elif cmd == 'tiles':
        tiles(*sys.argv[2:6])
    elif cmd == 'bands':
        bands(*sys.argv[2:5])
    else:
        sys.exit(__doc__)
