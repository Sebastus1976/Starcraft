#!/usr/bin/env python3
"""Image disquette MO6 (.fd 655360 octets, 2 faces) + .sd (SDDRIVE).
usage : mkdisk.py boot.bin out.fd [fichier@piste:secteur ...]
Le secteur d'amorcage MO : octets 0..126 codes par complement a 2,
octet 127 = $55 + somme des octets decodes."""
import sys
def boot_sector(code):
    """code (<= 120 octets) code par complement a 2, "BASIC2" en clair en
    120..125 (signature verifiee par le BASIC 128), octet 127 = somme de
    controle : $55 + somme des 127 octets une fois decodes (complement a 2)."""
    assert len(code) <= 120, len(code)
    s = bytearray(256)
    raw = bytes(code) + bytes(120 - len(code))
    for i, b in enumerate(raw):
        s[i] = (256 - b) & 255
    s[120:126] = b'BASIC2'
    s[127] = (0x55 + sum((256 - v) & 255 for v in s[:127])) & 255
    return s


def main():
    boot, out = sys.argv[1], sys.argv[2]
    fd = bytearray(655360)
    fd[0:256] = boot_sector(open(boot, 'rb').read())
    for spec in sys.argv[3:]:
        f, pos = spec.split('@')
        t, sct = map(int, pos.split(':'))
        data = open(f, 'rb').read()
        off = (t * 16 + sct - 1) * 256
        fd[off:off + len(data)] = data
        print('%s : %d octets, %d secteurs, piste %d secteur %d' % (f, len(data), (len(data) + 255) // 256, t, sct))
    open(out, 'wb').write(fd)
    sd = bytearray()
    for i in range(0, len(fd), 256):
        sd += fd[i:i + 256] + b'\xff' * 256
    open(out[:-3] + '.sd', 'wb').write(sd)
main()
