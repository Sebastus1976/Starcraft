* =============================================================================
* Moteur MO6 - decor en tuiles a defilement vertical (fond)
*
* Donnees (tools/gen-tiles.py) : carte de MAP_W x MAP_H tuiles de 8 points x
* 16 lignes. Seules les tuiles non vides sont dessinees, et seulement leur
* partie utile (cadre englobant) : un fond noir avec des etoiles et des
* planetes coute peu. Le decor est dessine a chaque image (opaque), puis
* les sprites par-dessus ; tout est efface par les listes d'effacement.
*
*   <nom>_Rows  : MAP_H mots -> rangee : ne, ne x etoile (decalage mot depuis
*                 le haut de la rangee, RAM B = -$2000, valeur), puis nt, nt x (colonne,
*                 tuile). Une "etoile" est un octet isole, dessine tres vite.
*   <nom>_Tiles : mots -> tuile : decalage (mot : ligne de depart*40 + paire
*                 de depart), lignes, paires, ligne de depart, paire de depart,
*                 puis lignes x paires x (octet RAM A, octet RAM B)
*
* VsInit : X = <nom>_Rows, Y = <nom>_Tiles, D = hauteur de la carte (lignes)
* vs_cam : ligne de la carte montree a la ligne 0 de l'ecran (0..hauteur-1)
* VsMove : B = deplacement vers le haut de la carte, en 1/256 de ligne
* VsDraw : dessine le decor entre les lignes VS_Y0 et VS_Y1 de l'ecran
* VsErase: efface les etoiles (a appeler juste apres ScreenBegin)
* =============================================================================
 IFNDEF VS_Y0
VS_Y0   equ   0
 ENDC
 IFNDEF VS_Y1
VS_Y1   equ   200
 ENDC
 IFNDEF VS_STARS
VS_STARS equ  240                     ; etoiles au plus par tampon
 ENDC

VsInit
        stx   vs_rows
        sty   vs_tiles
        std   vs_maph
        lsra                           ; nombre de rangees = hauteur / 16
        rorb
        lsra
        rorb
        lsra
        rorb
        lsra
        rorb
        stb   vs_nrow
        clr   vs_frac
        ldx   #StarEr2+2*VS_STARS      ; listes d'etoiles vides
        stx   vs_se2
        ldx   #StarEr3+2*VS_STARS
        stx   vs_se3
        rts

VsMove
        pshs  b
        lda   vs_frac
        suba  ,s+
        sta   vs_frac
        bcc   @rts
        ldd   vs_cam
        subd  #1
        bpl   >
        addd  vs_maph
!       std   vs_cam
@rts    rts

VsDraw
        ldd   vs_cam                   ; rangee de la ligne VS_Y0
        addd  #VS_Y0
        cmpd  vs_maph
        blo   >
        subd  vs_maph
!       pshs  d
        andb  #$F0                     ; debut de cette rangee
        std   vs_ty
        puls  d
        lsra
        rorb
        lsra
        rorb
        lsra
        rorb
        lsra
        rorb
        stb   vs_tr
        ldd   vs_ty                    ; y a l'ecran du haut de la rangee
        subd  vs_cam                   ; = debut - cam (peut etre < 0)
        bpl   >
        cmpd  #-$100                   ; (carte qui reboucle)
        bge   >
        addd  vs_maph
!       std   vs_ty
        ldx   #StarEr2+2*VS_STARS      ; liste d'effacement des etoiles
        lda   back                     ; (pile descendante, une par tampon)
        cmpa  #2
        beq   >
        ldx   #StarEr3+2*VS_STARS
!       stx   vs_sp
        leax  -2*VS_STARS+2*80,x       ; (une rangee : 80 etoiles au plus)
        stx   vs_slim
@rowlp  jsr   Tick
        ldd   vs_ty
        cmpd  #VS_Y1
        lbge  @end
        lslb                           ; base = SCR + ty*40 (signe)
        rola
        lslb
        rola
        lslb
        rola
        std   vs_base
        lslb
        rola
        lslb
        rola
        addd  vs_base
        addd  #SCR
        std   vs_base
        clr   vs_full                  ; rangee entierement visible ?
        ldd   vs_ty
        cmpd  #VS_Y0
        blt   >
        cmpd  #VS_Y1-16
        bgt   >
        inc   vs_full
!       ldb   vs_tr
        clra
        lslb
        rola
        ldu   vs_rows
        ldu   d,u                      ; liste de la rangee
* --- etoiles : octets isoles (decalage, valeur, ligne dans la rangee) ---
        lda   ,u+
        lbeq  @tiles
        sta   vs_n
        ldx   vs_sp
        cmpx  vs_slim
        bhs   >
        ldb   #3                       ; liste pleine : on saute ces etoiles
        mul
        leau  d,u
        bra   @tiles
!       ldy   vs_base
        tst   vs_full
        beq   @sslow
        sts   vs_ss
        lds   vs_sp
@sf     ldd   ,u++
        leax  d,y
        lda   ,u+
        sta   ,x
        pshs  x
        dec   vs_n
        bne   @sf
        sts   vs_sp
        lds   vs_ss
        bra   @tiles
@sslow  ldd   ,u                       ; rangee coupee : ligne de l'etoile
        bpl   >                        ; = (decalage, RAM B ramenee) / 40
        addd  #$2000
!       clr   vs_h
!       subd  #40
        bmi   >
        inc   vs_h
        bra   <
!       ldb   vs_h
        clra
        addd  vs_ty
        cmpd  #VS_Y0
        blt   @skip
        cmpd  #VS_Y1
        bge   @skip
        ldd   ,u
        leax  d,y
        lda   2,u
        sta   ,x
        ldd   vs_sp
        subd  #2
        std   vs_sp
        tfr   d,y
        stx   ,y
        ldy   vs_base
@skip   leau  3,u
        dec   vs_n
        lbne  @sslow
* --- tuiles ---
@tiles  tfr   u,x
        ldb   ,x+
        lbeq  @next
        stb   vs_n
        tst   vs_full
        lbeq  @tile
@fast   ldd   ,x++                     ; A = colonne, B = tuile
        pshs  x
        ldx   vs_base
        lsla
        leax  a,x
        clra
        lslb
        rola
        ldu   vs_tiles
        ldu   d,u
        ldd   ,u++                     ; decalage dans la tuile
        leax  d,x
        ldd   ,u++                     ; A = lignes, B = paires
        leau  2,u
        tst   no_er
        bne   @noer
        ldy   er_ptr                   ; zone a effacer (comme AddErase)
        cmpy  er_lim
        bhs   @noer
        stx   ,y
        std   2,y
        leay  4,y
        sty   er_ptr
@noer   decb
        bne   @f2
@f1     ldb   ,u+                      ; une paire par ligne
        stb   ,x
        ldb   ,u+
        stb   -$2000,x
        leax  40,x
        deca
        bne   @f1
        bra   @fn
@f2     sta   vs_h
        jsr   Tick                     ; (tuile pleine : plus longue)
@f2l    ldd   ,u++
        sta   ,x
        stb   -$2000,x
        ldd   ,u++
        sta   1,x
        stb   -$2000+1,x
        leax  40,x
        dec   vs_h
        bne   @f2l
@fn     puls  x
        dec   vs_n
        bne   @fast
        bra   @next
@tile   jsr   Tick
        lda   ,x+                      ; colonne (0..19)
        lsla
        sta   vs_col
        ldb   ,x+                      ; tuile
        pshs  x
        clra
        lslb
        rola
        ldu   vs_tiles
        ldu   d,u
        bsr   VsTile
        puls  x
        dec   vs_n
        bne   @tile
@next   ldd   vs_ty
        addd  #16
        std   vs_ty
        lda   vs_tr
        inca
        cmpa  vs_nrow
        blo   >
        clra
!       sta   vs_tr
        lbra  @rowlp
@end    ldx   vs_sp                    ; fin de la liste des etoiles
        lda   back
        cmpa  #2
        bne   >
        stx   vs_se2
        rts
!       stx   vs_se3
        rts

* VsErase : efface les etoiles dessinees la derniere fois dans ce tampon
* (apres ScreenBegin)
VsErase
        ldu   vs_se2
        ldx   #StarEr2+2*VS_STARS
        lda   back
        cmpa  #2
        beq   >
        ldu   vs_se3
        ldx   #StarEr3+2*VS_STARS
!       stx   vs_etop
@e      cmpu  vs_etop
        bhs   @rts
        pulu  x
        cmpx  #SCR-$2000               ; (garde : jamais hors ecran)
        blo   @e
        clr   ,x
        bra   @e
@rts    jmp   Tick

* VsTile : U = donnees de la tuile, vs_ty = haut de la rangee, vs_col
VsTile
        leau  2,u                      ; (decalage inutile ici)
        ldb   2,u                      ; haut = vs_ty + ligne de depart
        clra
        addd  vs_ty
        std   vs_top
        ldb   ,u                       ; bas = haut + lignes
        clra
        addd  vs_top
        cmpd  #VS_Y1
        ble   >
        ldd   #VS_Y1
!       std   vs_bot
        ldd   vs_top                   ; debut = max(haut, VS_Y0)
        cmpd  #VS_Y0
        bge   >
        ldd   #VS_Y0
!       std   vs_y
        ldd   vs_bot
        subd  vs_y
        ble   @rts                     ; rien a l'ecran
        stb   vs_h
        lda   1,u                      ; paires
        sta   vs_p
        lda   3,u                      ; paire de depart dans la tuile
        sta   vs_x0
        ldd   vs_y                     ; lignes sautees en haut de la tuile
        subd  vs_top
        lda   vs_p
        lsla                           ; octets par ligne = 2 x paires
        mul
        leau  4,u
        leau  d,u
        lda   vs_y+1                   ; adresse : SCR + y*40 + colonne + paire
        ldb   #40
        mul
        addd  #SCR
        addb  vs_col
        adca  #0
        addb  vs_x0
        adca  #0
        tfr   d,x
        bra   @go
@rts    rts
@go     lda   vs_h
        ldb   vs_p
        jsr   AddErase
        lda   vs_p
        cmpa  #2
        beq   @two
@one    lda   ,u+                      ; une paire par ligne
        sta   ,x
        lda   ,u+
        sta   -$2000,x
        leax  40,x
        dec   vs_h
        bne   @one
        rts
@two    ldd   ,u++                     ; deux paires : A0 B0 A1 B1
        sta   ,x
        stb   -$2000,x
        ldd   ,u++
        sta   1,x
        stb   -$2000+1,x
        leax  40,x
        dec   vs_h
        bne   @two
        rts

vs_rows  fdb  0
vs_tiles fdb  0
vs_maph  fdb  0
vs_nrow  fcb  0
vs_cam   fdb  0
vs_frac  fcb  0
vs_ty    fdb  0
vs_tr    fcb  0
vs_n     fcb  0
vs_col   fcb  0
vs_top   fdb  0
vs_bot   fdb  0
vs_y     fdb  0
vs_h     fcb  0
vs_p     fcb  0
vs_x0    fcb  0
vs_base  fdb  0
vs_full  fcb  0
vs_sp    fdb  0
vs_slim  fdb  0
vs_ss    fdb  0
vs_etop  fdb  0
vs_se2   fdb  StarEr2+2*VS_STARS
vs_se3   fdb  StarEr3+2*VS_STARS
 IFDEF STAR_AREA
StarEr2  equ  STAR_AREA
StarEr3  equ  STAR_AREA+2*VS_STARS
 ELSE
StarEr2  fill 0,2*VS_STARS
StarEr3  fill 0,2*VS_STARS
 ENDC
