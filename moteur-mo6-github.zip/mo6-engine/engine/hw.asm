* =============================================================================
* Moteur MO6 - materiel : initialisation, rythme 50 Hz sans interruption,
* palettes, pages, disquette, entrees, hasard
* =============================================================================

* HwInit : a appeler en premier (interruptions masquees pour toute la suite)
HwInit
        orcc  #$50
        lda   SYS_IMG                  ; image lisible de $A7E7 (comme $6081
        ora   #$50                     ; sur TO8). Bit 4 : pages donnees par
        sta   SYS_IMG                  ; RAM_REG ; bit 6 : RAM en $B000 par
        sta   SYS1                     ; CART_REG. Autres bits gardes (vrai MO6)
        lda   #DATA_PAGE+$60           ; page de donnees en $B000, en ecriture
        sta   CART_REG
        lda   #$7B                     ; 160x200 16 couleurs
        sta   VID_MODE
        clr   $A7CE                    ; manettes : port A en entree
        clr   PIA_JOY_A
        lda   #$04
        sta   $A7CE
        clr   $A7CF                    ; port B : bits 0-5 sortie (son), 6-7 entree
        lda   #$3F
        sta   PIA_JOY_B
        lda   #$04
        sta   $A7CF
        rts

* Tick : rythme sans interruption. Le bit 7 de SYS1 vaut 1 pendant les 200
* lignes utiles ; a chaque passage a 0 (bordure basse) : une image (frame),
* musique et voix avancent. A appeler souvent (au moins toutes les 6 ms) :
* le moteur l'appelle a chaque sprite, effacement, tuile...
* Ne modifie aucun registre (sauf CC).
Tick
        pshs  a
        lda   SYS1
        anda  #$80
        cmpa  vbl_prev
        bne   @chg
        puls  a,pc
@chg    sta   vbl_prev
        bne   @out
        inc   frame
        pshs  b,x,y,u
        jsr   SoundTick
        jsr   VoiceTick
        puls  b,x,y,u
@out    puls  a,pc

* WaitFrame : attend l'image suivante
WaitFrame
        pshs  a
        lda   frame
@w      bsr   Tick
        cmpa  frame
        beq   @w
        puls  a,pc

* WaitFrames : A = nombre d'images
WaitFrames
        bsr   WaitFrame
        deca
        bne   WaitFrames
        rts

* SetPal : X -> 16 couleurs (mot : vert*16+rouge, bleu)
SetPal
        clr   PAL_IDX
        ldb   #16
@c      lda   ,x+
        sta   PAL_DAT
        lda   ,x+
        sta   PAL_DAT
        decb
        bne   @c
        rts
PalBlack fill 0,32

* ClearPage : A = page video (mise a zero)
ClearPage
        sta   RAM_REG
        ldx   #$6000
@c      bsr   Tick
        ldb   #64
@c2     clr   ,x+
        clr   ,x+
        clr   ,x+
        clr   ,x+
        decb
        bne   @c2
        cmpx  #$A000
        blo   @c
        rts

* CopyPage : A = page source, B = page destination (16 Ko, par la fenetre
* video $0000-$1FFF qui sert de tampon de 8 Ko)
CopyPage
        sta   cp_src
        stb   cp_dst
        ldy   #$6000
@half   lda   cp_src
        sta   RAM_REG
        tfr   y,u
        ldx   #0
        bsr   @copy
        lda   cp_dst
        sta   RAM_REG
        tfr   y,x
        ldu   #0
        bsr   @copy
        leay  $2000,y
        cmpy  #$A000
        blo   @half
        rts
@copy   ldb   #32                      ; U -> X, 8 Ko
        stb   cp_n
@blk    jsr   Tick
        ldb   #64
@w      lda   ,u+
        sta   ,x+
        lda   ,u+
        sta   ,x+
        lda   ,u+
        sta   ,x+
        lda   ,u+
        sta   ,x+
        decb
        bne   @w
        dec   cp_n
        bne   @blk
        rts
cp_src  fcb   0
cp_dst  fcb   0
cp_n    fcb   0

* LoadSectors : X = adresse, A = piste, B = secteur (1-16), Y = nombre de
* secteurs (lecteur 0). La page voulue doit etre visible a l'adresse X.
* Compteurs en memoire (pas dans les registres ni la page $20), 4 essais par
* secteur ; echec : cadre rouge, arret (LoadError).
LoadSectors
        sty   ls_n
        stx   $204F
        clr   $2049
        clr   $204A
        sta   $204B
        stb   $204C
@rd     lda   #4
        sta   ls_try
@try    lda   #2
        sta   $2048
        jsr   DKCO
        bcc   @ok
        dec   ls_try
        bne   @try
        bra   LoadError
@ok     inc   $204F
        inc   $204C
        lda   $204C
        cmpa  #17
        blo   >
        lda   #1
        sta   $204C
        inc   $204B
!       ldy   ls_n
        leay  -1,y
        sty   ls_n
        bne   @rd
        rts
LoadError                              ; page 0 affichee, cadre rouge
        lda   #$01
        sta   VID_PAGE
        bra   LoadError
ls_n    fdb   0
ls_try  fcb   0

* ReadInput : manettes (les deux prises) et clavier (fleches, ESPACE / ENTREE)
*   in_dir : J_UP, J_DOWN, J_LEFT, J_RIGHT ; in_fire : 0 ou non nul
ReadInput                              ; les 2 prises manette : directions
        lda   PIA_JOY_A                ; PA0-3 / PA4-7, boutons PB6 / PB7
        coma                           ; (actifs a 0)
        tfr   a,b
        lsrb
        lsrb
        lsrb
        lsrb
        pshs  b
        ora   ,s+
        anda  #$0F
        sta   in_dir
        clr   in_fire
        lda   PIA_JOY_B
        coma
        anda  #$C0
        beq   >
        inc   in_fire
!       ldx   #KeyTab
@k      ldb   ,x+
        beq   @rts
        stb   PIA_SYS_B                ; ligne*2 + colonne*16
        lda   ,x+
        tst   PIA_SYS_B                ; bit 7 a 0 : touche enfoncee
        bmi   @k
        tsta
        beq   @sp
        ora   in_dir
        sta   in_dir
        bra   @k
@sp     inc   in_fire
        bra   @k
@rts    rts
KeyTab  fcb   $62,J_UP
        fcb   $42,J_DOWN
        fcb   $52,J_LEFT
        fcb   $32,J_RIGHT
        fcb   $40,0                    ; espace
        fcb   $68,0                    ; entree
        fcb   0

* KeyDown : B = code ligne*2+colonne*16 -> Z = 0 si la touche est enfoncee
KeyDown
        stb   PIA_SYS_B
        lda   PIA_SYS_B
        coma
        anda  #$80
        rts

* Rand : B = nombre pseudo-aleatoire (A modifie)
Rand
        lda   rnd
        ldb   #5
        mul
        addb  #$3B
        eorb  frame
        stb   rnd
        rts

frame    fcb  0
vbl_prev fcb  0
rnd      fcb  $5A
in_dir   fcb  0
in_fire  fcb  0

* Unrle : decompresse un flux RLE, U = donnees, X = destination, Y = fin
*   octet c < $80 : c+1 octets copies ; c >= $80 : l'octet suivant repete
*   (c-$80)+2 fois (format de tools/gen-info.py du jeu TO8)
Unrle
        sty   rle_end
@c      jsr   Tick
        ldb   ,u+
        bmi   @run
        incb
@lit    lda   ,u+
        sta   ,x+
        decb
        bne   @lit
        bra   @chk
@run    andb  #$7F
        addb  #2
        lda   ,u+
@r      sta   ,x+
        decb
        bne   @r
@chk    cmpx  rle_end
        blo   @c
        rts
rle_end fdb   0
