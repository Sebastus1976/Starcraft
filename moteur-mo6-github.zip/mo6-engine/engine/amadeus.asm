* =============================================================================
* Moteur MO6 - carte son Amadeus
*   YM2413 ($A7FC adresse / $A7FD donnee) : musique sur 3 voies (0 melodie,
*   1 basse, 2 nappe) et bruitages (voies 3 a 5 + batterie)
*   SN76489 ($A7F7) : coupe a l'arret
* SoundTick est appele a chaque image (50 Hz) par Tick.
* Morceau : 3 pointeurs (melodie, basse, nappe) vers des suites de notes :
*   note MIDI (0 = silence), duree en images ; $FF reboucle, $FE arrete.
* =============================================================================
YM_A    equ $A7FC
YM_D    equ $A7FD
SN_D    equ $A7F7

* --- YmWrite : A = registre, B = valeur (delais pour la puce) ---
YmWrite                                ; YM2413 : 3,4 us apres l'adresse,
        sta   YM_A                     ; 23,5 us apres la donnee (sinon la
        nop                            ; vraie puce perd l'ecriture suivante :
        nop                            ; une note peut rester tenue)
        stb   YM_D
        nop
        nop
        nop
        nop
        nop
        nop
        nop
        nop
        nop
        nop
        rts

* SoundMute : silence total, a appeler tout au debut. La carte Amadeus
* n'est pas remise a zero avec l'ordinateur : une note (ou des registres
* aleatoires a l'allumage) peut sonner jusqu'a ce qu'on la fasse taire.
SoundMute
        lda   #$1A                     ; MEA8000 : arret
        sta   $A7FF
        lda   #$0E                     ; YM : batterie arretee, mode melodique
        clrb
        jsr   YmWrite
        lda   #6                       ; instrument maison : relachement
        ldb   #$FF                     ; le plus rapide
        jsr   YmWrite
        lda   #7
        ldb   #$FF
        jsr   YmWrite
        lda   #$20                     ; 9 voies : touche relachee
@k      clrb
        pshs  a
        jsr   YmWrite
        puls  a
        inca
        cmpa  #$29
        blo   @k
        lda   #$30                     ; 9 voies : volume au minimum
@v      ldb   #$0F
        pshs  a
        jsr   YmWrite
        puls  a
        inca
        cmpa  #$39
        blo   @v
        lda   #$9F                     ; SN : 4 voies muettes
        sta   SN_D
        lda   #$BF
        sta   SN_D
        lda   #$DF
        sta   SN_D
        lda   #$FF
        sta   SN_D
        rts

SoundInit
        jsr   SoundMute
        jsr   SoundOff

        lda   #$30                     ; voie 0 : synthe, volume fort
        ldb   #$A4
        jsr   YmWrite
        lda   #$31                     ; voie 1 : synthe basse
        ldb   #$D3
        jsr   YmWrite
        lda   #$32                     ; voie 2 : orgue, plus doux
        ldb   #$88
        jsr   YmWrite
        lda   #$33                     ; voie 3 (tir) : synthe, un peu moins fort
        ldb   #$A1
        jsr   YmWrite
        ldx   #YmPatch                 ; instrument maison -> registres 0 a 7
        clra
@patch  ldb   ,x+
        pshs  a
        jsr   YmWrite
        puls  a
        inca
        cmpa  #8
        blo   @patch
        lda   #$34                     ; voie 4 (explosion) : instrument maison
        ldb   #$00
        jsr   YmWrite
        lda   #$35                     ; voie 5 (bonus) : vibraphone
        ldb   #$C1
        jsr   YmWrite
        ldx   #YmDrumInit              ; batterie : hauteurs et volumes
@drum   lda   ,x+
        beq   @drumok
        ldb   ,x+
        jsr   YmWrite
        bra   @drum
@drumok lda   #$0E                     ; mode rythme (voies 6-8 = batterie)
        ldb   #$20
        jsr   YmWrite
        lda   #$9F                     ; SN : 4 voies muettes
        sta   SN_D
        lda   #$BF
        sta   SN_D
        lda   #$DF
        sta   SN_D
        lda   #$FF
        sta   SN_D
        clr   mus_on
        rts

* --- MusicPlay : X = morceau (3 pointeurs de pistes) ---
MusicPlay
        pshs  cc,d,x,y,u
        orcc  #$10                     ; pas d'IRQ pendant le changement
        clr   mus_on
        lda   #3
        ldy   #mus_ch
@ch     ldu   ,x++
        stu   ,y                       ; pointeur courant
        stu   2,y                      ; debut (pour reboucler)
        ldb   #1
        stb   4,y                      ; compte a rebours : note au prochain tick
        leay  MUS_CH_SIZE,y
        deca
        bne   @ch
        lda   #1
        sta   mus_on
        puls  cc,d,x,y,u,pc

MusicStop
* SoundOff : musique et bruitages arretes, toutes les voies de la YM
* relachees (sinon une note peut rester tenue jusque dans la partie suivante)
SoundOff
        clr   mus_on
        ldd   #0
        std   sfx_seq
        std   sfx_seq+2
        std   sfx_seq+4
        lda   #$20
@k      clrb
        pshs  a
        jsr   YmWrite
        puls  a
        inca
        cmpa  #$29
        blo   @k
        lda   #$0E                     ; batterie : toutes les frappes relachees
        ldb   #$20
        jsr   YmWrite
        lda   #$9F                     ; SN : 4 voies muettes
        sta   SN_D
        lda   #$BF
        sta   SN_D
        lda   #$DF
        sta   SN_D
        lda   #$FF
        sta   SN_D
        rts

YmDrumInit
        fcb   $16,$20,$17,$50,$18,$C0,$26,$05,$27,$05,$28,$01
        fcb   $36,$00,$37,$00,$38,$00,0
MUS_CH_SIZE equ 5                      ; pointeur, debut, compte a rebours
mus_ch  fill  0,3*MUS_CH_SIZE
mus_on  fcb   0
mus_v   fcb   0

* --- SoundTick : musique puis bruitages ---
SoundTick
        tst   mus_on
        beq   SfxTick
        clr   mus_v
        ldy   #mus_ch
@ch     dec   4,y
        bne   @next
        ldx   ,y
@read   lda   ,x+
        cmpa  #$FF                     ; reboucler
        bne   >
        ldx   2,y
        bra   @read
!       cmpa  #$FE                     ; fin du morceau : la voie se tait
        bne   >
        leax  -1,x
        stx   ,y
        lda   #1
        sta   4,y
        lda   mus_v
        adda  #$20
        clrb
        jsr   YmWrite
        bra   @next
!       ldb   ,x+                      ; duree
        stb   4,y
        stx   ,y
        tsta
        bne   @note
        lda   mus_v                    ; silence : touche relachee
        adda  #$20
        clrb
        jsr   YmWrite
        bra   @next
@note   suba  #YmNoteBase
        lsla
        ldx   #YmNotes
        ldd   a,x                      ; A = bloc/bit8, B = F-number bas
        pshs  a
        lda   mus_v                    ; relache, F-number, puis touche enfoncee
        adda  #$20
        pshs  b
        clrb
        jsr   YmWrite
        puls  b
        lda   mus_v
        adda  #$10
        jsr   YmWrite
        puls  b
        orb   #$10                     ; key on
        lda   mus_v
        adda  #$20
        jsr   YmWrite
@next   leay  MUS_CH_SIZE,y
        inc   mus_v
        lda   mus_v
        cmpa  #3
        bne   @ch

* --- bruitages sur la YM2413 (la puce de la musique, toujours entendue) ---
*   voie 3 : tir (son "synthe" qui glisse vers le grave, sans re-attaque)
*   voie 4 : explosion (instrument maison bruite, grave qui s'eteint)
*   voie 5 : bonus (petit arpege de vibraphone)
*   batterie de la YM (voies 6 a 8) : coup de grosse caisse sous les explosions
* sequence : une valeur par trame. 1..127 = note MIDI (attaque),
*   $80+note = la note glisse sans nouvelle attaque, 0 = relache, $FF = fin
SfxTick
        lda   #3
        ldy   #sfx_seq
        bsr   SfxVoice
        lda   #4
        ldy   #sfx_seq+2
        bsr   SfxVoice
        lda   #5
        ldy   #sfx_seq+4
SfxVoice                               ; A = voie YM, Y -> pointeur de sequence
        ldx   ,y
        beq   @rts
        sta   sfx_v
        ldb   ,x+
        cmpb  #$FF
        bne   >
        clr   ,y
        clr   1,y
        rts
!       stx   ,y
        tstb
        bne   @note
        lda   sfx_v                    ; relache
        adda  #$20
        jmp   YmWrite
@note   clr   sfx_glide
        bitb  #$80
        beq   >
        inc   sfx_glide
        andb  #$7F
!       subb  #YmNoteBase
        lslb
        ldx   #YmNotes
        abx
        tst   sfx_glide
        bne   >
        lda   sfx_v                    ; nouvelle note : relache d'abord
        adda  #$20
        clrb
        jsr   YmWrite
!       lda   sfx_v                    ; F-number puis touche enfoncee
        adda  #$10
        ldb   1,x
        jsr   YmWrite
        lda   sfx_v
        adda  #$20
        ldb   ,x
        orb   #$10
        jmp   YmWrite
@rts    rts
sfx_seq   fdb   0,0,0
sfx_v     fcb   0
sfx_glide fcb   0

* --- SfxPlay : A = numero du bruitage ---
SFX_SHOT  equ 0
SFX_EXPLO equ 1
SFX_BONUS equ 2
SFX_HIT   equ 3
SFX_TICK  equ 4
SfxPlay
        pshs  d,x
        cmpa  #SFX_SHOT
        bne   >
        ldx   #SeqShot
        stx   sfx_seq
        bra   @end
!       cmpa  #SFX_BONUS
        bne   >
        ldx   #SeqBonus
        stx   sfx_seq+4
        bra   @end
!       cmpa  #SFX_TICK
        bne   >
        ldb   #$21                     ; boss touche : charleston seul
        bra   @drum
!       ldx   #SeqExplo                ; explosion ou vaisseau touche
        ldb   #$28                     ; + caisse claire (plus de grosse caisse)
        cmpa  #SFX_HIT
        bne   >
        ldx   #SeqHit
        ldb   #$32                     ; + cymbale
!       stx   sfx_seq+2
@drum   pshs  b
        lda   #$0E                     ; relache la batterie puis frappe
        ldb   #$20
        jsr   YmWrite
        puls  b
        lda   #$0E
        jsr   YmWrite
@end    puls  d,x,pc

SeqShot  fcb  81,$80+78,$80+75,$80+72,$80+69,$80+66,$80+63,0,$FF
SeqExplo fcb  57,$80+57,$80+56,$80+55,$80+54,$80+53,$80+52,$80+51
         fcb  $80+50,$80+49,$80+48,$80+47,$80+46,$80+45,0,$FF
SeqHit   fcb  52,$80+52,$80+51,$80+51,$80+50,$80+50,$80+49,$80+49
         fcb  $80+48,$80+48,$80+47,$80+47,$80+46,$80+46,$80+45,$80+45
         fcb  $80+44,$80+44,$80+43,$80+43,0,$FF
SeqBonus fcb  72,72,76,76,79,79,84,84,84,0,$FF

* instrument maison (n. 0) pour les explosions : modulation forte et
* reinjectee (son bruite), attaque immediate, extinction progressive
YmPatch  fcb  $0F,$01,$00,$1F,$F3,$F3,$03,$F4

        INCLUDE "ymnotes.asm"
