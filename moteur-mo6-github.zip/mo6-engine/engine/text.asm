* =============================================================================
* Moteur MO6 - textes (police 3x5) et chiffres
*   DrawText    : X = adresse RAM A, U = texte (0 = fin), A = couleur doublee
*                 ($44 = couleur 4) ; une lettre = 1 octet RAM A + 1 octet RAM B
*   DrawTextBig : lettres doublees (8 points x 10 lignes)
*   DrawDigit   : A = chiffre (0-9, 10 = petit x), X = adresse (avance)
*   DrawBCD     : U -> octets BCD, B = nombre d'octets, X = adresse
* Les zones dessinees sont notees pour l'effacement (sauf si no_er <> 0).
* =============================================================================
DrawText
        sta   tx_col
        anda  #$F0
        sta   tx_hi
        lda   tx_col
        anda  #$0F
        sta   tx_lo
@char   lda   ,u+
        beq   @rts
        suba  #32
        ldb   #5
        mul
        ldy   #Font
        leay  d,y
        lda   #5
        ldb   #1
        jsr   AddErase
        pshs  x
        lda   #5
        sta   tx_n
@row    ldb   ,y+
        clra
        bitb  #4
        beq   >
        ora   tx_hi
!       bitb  #2
        beq   >
        ora   tx_lo
!       sta   ,x
        clra
        bitb  #1
        beq   >
        lda   tx_hi
!       sta   -$2000,x
        leax  40,x
        dec   tx_n
        bne   @row
        puls  x
        leax  1,x
        bra   @char
@rts    rts

DrawTextBig
        sta   tx_col
@char   lda   ,u+
        beq   @rts
        suba  #32
        ldb   #5
        mul
        ldy   #Font
        leay  d,y
        lda   #10
        ldb   #2
        jsr   AddErase
        pshs  x
        lda   #5
        sta   tx_n
@row    ldb   ,y+
        lda   #2
        sta   tx_lo
@twice  clra
        bitb  #4
        beq   >
        lda   tx_col
!       sta   ,x
        clra
        bitb  #2
        beq   >
        lda   tx_col
!       sta   -$2000,x
        clra
        bitb  #1
        beq   >
        lda   tx_col
!       sta   1,x
        clr   -$2000+1,x
        leax  40,x
        dec   tx_lo
        bne   @twice
        dec   tx_n
        bne   @row
        puls  x
        leax  2,x
        bra   @char
@rts    rts

DrawDigit
        ldb   #10
        mul
        ldy   #Digits
        leay  b,y
        lda   #5
        sta   tx_n
        pshs  x
!       ldd   ,y++
        sta   ,x
        stb   -$2000,x
        leax  40,x
        dec   tx_n
        bne   <
        puls  x
        leax  1,x
        rts

DrawBCD
        stb   tx_cnt
@b      lda   ,u
        lsra
        lsra
        lsra
        lsra
        bsr   DrawDigit
        lda   ,u+
        anda  #$0F
        bsr   DrawDigit
        dec   tx_cnt
        bne   @b
        rts

tx_col  fcb   0
tx_hi   fcb   0
tx_lo   fcb   0
tx_n    fcb   0
tx_cnt  fcb   0
