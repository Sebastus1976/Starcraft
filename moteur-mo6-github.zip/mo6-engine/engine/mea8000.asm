* =============================================================================
* Moteur MO6 - synthetiseur vocal MEA8000 ($A7FE donnees, $A7FF commande)
* Le jeu fournit VoiceOffsets (mots : debut de chaque phrase dans VoiceData)
* et VoiceData (hauteur, nombre de trames, trames de 4 octets).
* Methode : arret, hauteur, 2 trames d'avance, puis une trame toutes les
* 30,72 ms (credit de temps a chaque image), pause apres chaque octet.
* =============================================================================
MEA_D     equ $A7FE
MEA_C     equ $A7FF
MEA_STOP  equ $1A


VoiceInit
        clr   vo_req
        clr   vo_on
        lda   #MEA_STOP
        sta   MEA_C
        rts

* VoicePlay : A = phrase. Une phrase en cours n'est coupee que par une plus
* importante (numero plus grand).
VoicePlay
        pshs  cc,d
        tst   vo_mute                  ; voix coupees (option du jeu)
        bne   @out
        orcc  #$50
        tst   vo_on
        beq   @go
        cmpa  vo_cur
        bls   @out
@go     sta   vo_cur
        inca
        sta   vo_req
@out    puls  cc,d,pc

* VoiceTick (IRQ 50 Hz)
VoiceTick
        ldb   vo_req
        bne   @new
        tst   vo_on
        beq   @rts
        ldd   vo_acc
        addd  #1997
        std   vo_acc
        bmi   @rts
        subd  #3072
        std   vo_acc
        ldx   vo_ptr
        bsr   VoiceFrame
        stx   vo_ptr
        dec   vo_left
        bne   @rts
        clr   vo_on
        ldx   #VoxVolOn
        bra   VoiceVol
@rts    rts
@new    clr   vo_req
        pshs  b
        ldx   #VoxVolDuck
        bsr   VoiceVol
        puls  b
        decb
        lslb
        ldx   #VoiceOffsets
        ldd   b,x
        addd  #VoiceData
        tfr   d,x
        lda   #MEA_STOP
        sta   MEA_C
        bsr   VoiceDly
        lda   ,x+
        sta   MEA_D
        bsr   VoiceDly
        lda   ,x+
        suba  #2
        sta   vo_left
        bsr   VoiceFrame
        bsr   VoiceFrame
        stx   vo_ptr
        ldd   #-3072-250
        std   vo_acc
        lda   #1
        sta   vo_on
        rts

VoiceVol                               ; X -> volumes des voies 0-2 de la musique
        lda   #$30
@v      ldb   ,x+
        pshs  a
        jsr   YmWrite
        puls  a
        inca
        cmpa  #$33
        blo   @v
        rts
VoxVolOn   fcb $A4,$D3,$88
VoxVolDuck fcb $A8,$D7,$8C

VoiceFrame
        ldb   #4
@b      lda   ,x+
        sta   MEA_D
        bsr   VoiceDly
        decb
        bne   @b
        rts
VoiceDly
        pshs  b
        ldb   #20
@d      decb
        bne   @d
        puls  b,pc

vo_mute fcb  0                         ; <> 0 : voix coupees
vo_cur  fcb  0
vo_req  fcb  0
vo_on   fcb  0
vo_left fcb  0
vo_ptr  fdb  0
vo_acc  fdb  0
