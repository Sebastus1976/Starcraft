* Moteur MO6 - secteur d'amorcage (piste 0, secteur 1), charge en $2200 par
* le controleur. Lit NSECT secteurs (piste 0, secteur 2...) en $2300 et y saute.
        org   $2200
* Pile en $2280-$22FF (fin du secteur d'amorcage, a nous) : rien en $2100-$21FF
* ni dans la page $20 en dehors des registres du controleur (le vrai
* controleur et SDDRIVE y ont leurs variables). 4 essais par secteur.
        orcc  #$50
        lds   #$2300
        lda   #$20
        tfr   a,dp
        setdp $20
        ldd   #$2300
        std   <$4F                     ; DK.BUF
        clr   <$49                     ; DK.DRV
        clr   <$4A                     ; DK.TRK
        clr   <$4B
        lda   #2
        sta   <$4C                     ; DK.SEC
        lda   #NSECT
        sta   CNT
@rd     lda   #4
        sta   TRY
@try    lda   #2
        sta   <$48                     ; DK.OPC lecture
        jsr   $A004                    ; DKCO
        bcc   @ok
        dec   TRY
        bne   @try
@err    lda   #$01                     ; erreur : page 0 (ecran du BASIC),
        sta   $A7DD                    ; cadre rouge
        bra   @err
@ok     inc   <$4F                     ; +256
        inc   <$4C
        lda   <$4C
        cmpa  #17
        blo   >
        lda   #1
        sta   <$4C
        inc   <$4B
!       dec   CNT
        bne   @rd
        jmp   $2300
CNT     equ   $227E                    ; (octets 126-127 du secteur, libres
TRY     equ   $227F                    ;  une fois l'amorce lancee)
