* =============================================================================
* Moteur MO6 - ecran : double tampon (pages video 2 et 3), sprites masques,
* listes d'effacement
*
* Une image de jeu :
*     jsr  ScreenBegin     ; tampon cache en $6000-$9FFF, efface ce qui y
*                          ; avait ete dessine la fois precedente
*     ... dessins (DrawSpr, DrawText, VsDraw...) : chacun note sa zone
*     jsr  ScreenEnd       ; attend la cadence voulue et montre le tampon
*
* Format d'un sprite (genere par tools/gen-sprites.py) : 2 mots (phase 0 :
* x multiple de 4, phase 1 : x = 4n+2), chaque phase : H, P (paires d'octets
* par ligne), puis H*P groupes : masque RAM A, valeur RAM A, masque RAM B,
* valeur RAM B. Les x sont pairs (un point TO = 2 pixels a l'ecran).
* =============================================================================
 IFNDEF ER_MAX
ER_MAX  equ   120                      ; zones a effacer par tampon
 ENDC

* ScreenInit : efface les pages 2 et 3, dessin dans la page 2
ScreenInit
        lda   #2
        jsr   ClearPage
        lda   #3
        jsr   ClearPage
        lda   #2
        sta   back
        ldx   #ErList2
        stx   er_end2
        ldx   #ErList3
        stx   er_end3
        clr   no_er
        lda   frame
        sta   last_fr
        rts

* ScreenBegin : tampon cache visible en $6000-$9FFF, ancien dessin efface
ScreenBegin
        lda   back
        sta   RAM_REG
        ldy   #ErList2
        ldu   er_end2
        cmpa  #2
        beq   >
        ldy   #ErList3
        ldu   er_end3
!       sty   er_ptr
        leax  4*ER_MAX,y
        stx   er_lim
        pshs  u
@e      cmpy  ,s
        bhs   @done
        jsr   Tick
        ldx   ,y
        cmpx  #SCR                     ; garde : une zone hors ecran
        bhs   >                        ; n'est jamais effacee
        leay  4,y
        bra   @e
!       ldd   2,y
        sta   bl_h
        cmpb  #2                       ; 2 paires (tuiles du decor) : deroule
        bne   @row
@two    clr   ,x
        clr   1,x
        clr   -$2000,x
        clr   -$2000+1,x
        leax  40,x
        deca
        bne   @two
        leay  4,y
        bra   @e
@row    ldb   3,y
        pshs  x
@p      clr   ,x+
        clr   -$2001,x
        decb
        bne   @p
        puls  x
        leax  40,x
        dec   bl_h
        bne   @row
        leay  4,y
        bra   @e
@done   puls  u,pc

* ScreenEnd : A = images minimum par image de jeu (2 = 25 i/s), puis on montre
* le tampon dessine et on echange les tampons
ScreenEnd
        sta   bl_h
        ldx   er_ptr                   ; fin de la liste de ce tampon
        lda   back
        cmpa  #2
        bne   >
        stx   er_end2
        bra   @w
!       stx   er_end3
@w      jsr   Tick
        lda   frame
        suba  last_fr
        cmpa  bl_h
        blo   @w
        lda   frame
        sta   last_fr
        lda   back                     ; page affichee : bits 7-6
        lsla
        lsla
        lsla
        lsla
        lsla
        lsla
        sta   VID_PAGE
        lda   back
        eora  #1
        sta   back
        rts

* ShowPage : A = page a afficher (0-3), cadre noir
ShowPage
        lsla
        lsla
        lsla
        lsla
        lsla
        lsla
        sta   VID_PAGE
        rts

* ScrAddr : A = x (pair, 0-158), B = y -> X = adresse RAM A ; A garde x
ScrAddr
        pshs  a
        lda   #40
        mul
        addd  #SCR
        tfr   d,x
        lda   ,s
        lsra
        lsra
        leax  a,x
        puls  a,pc

* DrawSpr : U = sprite, A = x, B = y (le sprite doit tenir dans l'ecran)
DrawSpr
        bsr   ScrAddr
        bita  #2
        beq   >
        ldu   2,u
        bra   @go
!       ldu   ,u
@go     ldd   ,u++
        pshs  d
        bsr   AddErase
        puls  d
        sta   bl_h
        stb   bl_p
@row    ldb   bl_p
        pshs  x
@pair   lda   ,x
        anda  ,u+
        ora   ,u+
        sta   ,x+
        lda   -$2001,x
        anda  ,u+
        ora   ,u+
        sta   -$2001,x
        decb
        bne   @pair
        puls  x
        leax  40,x
        dec   bl_h
        bne   @row
        rts

* AddErase : X = adresse, A = lignes, B = paires -> zone effacee au prochain
* passage dans ce tampon (rien si no_er <> 0)
AddErase
        jsr   Tick
        tst   no_er
        bne   @rts
        pshs  y
        ldy   er_ptr
        cmpy  er_lim
        bhs   @full
        stx   ,y
        std   2,y
        leay  4,y
        sty   er_ptr
@full   puls  y,pc
@rts    rts

back     fcb  2
last_fr  fcb  0
no_er    fcb  1
bl_h     fcb  0
bl_p     fcb  0
er_ptr   fdb  ErList2
er_lim   fdb  ErList2+4*ER_MAX
er_end2  fdb  ErList2
er_end3  fdb  ErList3
 IFDEF ER_AREA                         ; listes hors de la memoire programme
ErList2  equ  ER_AREA                  ; (par ex. $0000 : page 0, inutilisee
ErList3  equ  ER_AREA+4*ER_MAX         ;  pendant le jeu)
 ELSE
ErList2  fill 0,4*ER_MAX
ErList3  fill 0,4*ER_MAX
 ENDC
